# IPTV Player (Phase 1)
Android phone + Android TV project (Kotlin, Compose, Media3, Room, encrypted credentials).

## Build the APK without a PC
1. Create a free GitHub repo, upload this folder's contents.
2. Open the Actions tab -> "Build APK" -> run it (it also runs on every push).
3. When it finishes, download the `IPTV-debug-apk` artifact and install the APK.

## Build with Android Studio
Open this folder, let Gradle sync, press Run.

## Included
Home, Add Subscription (Xtream / M3U URL+file / Stalker MAC / Single URL, validated),
Switch Subscription, Live TV list + search, ExoPlayer, Arabic/English, D-pad focus glow.
Next phase: Movies, Series, EPG, Favorites, Downloads, Settings, Stalker playback.
