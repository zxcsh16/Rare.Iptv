package com.iptv.player.ui

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/** Parental lock: when on, categories with adult names are hidden everywhere. The PIN is stored only as a salted hash. */
object Parental {
    private val adult = Regex("(?i)(\\bxxx\\b|\\badults?\\b|18\\s*\\+|\\+\\s*18|21\\s*\\+|\\+\\s*21|\\bporn|erotic|\\bsex\\b|للكبار|اباح|إباح)")
    private fun hash(pin: String) = MessageDigest.getInstance("SHA-256").digest(("rare-iptv:$pin").toByteArray()).joinToString("") { "%02x".format(it) }
    fun on(p: SharedPreferences) = p.getBoolean("parental", false) && !p.getString("pin_hash", "").isNullOrEmpty()
    fun setPin(p: SharedPreferences, pin: String) { p.edit().putString("pin_hash", hash(pin)).putBoolean("parental", true).apply() }
    fun check(p: SharedPreferences, pin: String) = hash(pin) == p.getString("pin_hash", "")
    fun disable(p: SharedPreferences) { p.edit().putBoolean("parental", false).remove("pin_hash").apply() }
    fun isAdult(name: String) = adult.containsMatchIn(name)
    /** Ids of the categories to hide (empty when the lock is off). */
    fun hidden(p: SharedPreferences, cats: Map<String, String>?): Set<String> =
        if (!on(p) || cats == null) emptySet() else cats.filter { isAdult(it.value) }.keys
}

@Composable fun PinDialog(title: String, error: String?, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onCancel, title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(pin, { if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                if (error != null) Text(error, color = Err, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onOk(pin) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onCancel) { Text(stringResource(R.string.cancel)) } })
}

@Composable private fun ResRow(cover: String, name: String, ar: Float, onClick: () -> Unit) {
    Fx(onClick, Modifier.fillMaxWidth(), pad = 6.dp) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AsyncImage(cover, null, Modifier.height(44.dp).aspectRatio(ar).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Crop)
            Text(name, maxLines = 1, modifier = Modifier.weight(1f))
        }
    }
}

/** One search box over live channels, movies and series (loads and caches whatever is not loaded yet). */
@Composable fun SearchScreen(sub: Sub?, onLive: (Ch) -> Unit, onMovie: (Vod) -> Unit, onSeries: (Vod) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val kL = "${sub?.id}|live"; val kM = "${sub?.id}|movie"; val kS = "${sub?.id}|series"
    var live by remember(kL) { mutableStateOf(Mem.live[kL]) }
    var movies by remember(kM) { mutableStateOf(Mem.m[kM]) }
    var series by remember(kS) { mutableStateOf(Mem.m[kS]) }
    var loading by remember(kL) { mutableStateOf(sub != null) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(kL) {
        if (sub == null) { loading = false; return@LaunchedEffect }
        val p = withContext(Dispatchers.IO) { Secure.get(ctx, sub.id) }
        if (live == null) try {
            val d = withContext(Dispatchers.IO) {
                when (sub.type) {
                    "xtream" -> Xt.live(sub.url, sub.user, p)
                    "m3u" -> Xt.m3uLive(ctx, sub.url)
                    "single" -> LiveData(emptyMap(), listOf(Ch(sub.name, sub.url)))
                    else -> null
                }
            }
            if (d != null) { Mem.live[kL] = d; live = d }
        } catch (_: Exception) { }
        if (sub.type == "xtream") {
            if (movies == null) try { val d = withContext(Dispatchers.IO) { Xt.movies(sub.url, sub.user, p) }; Mem.m[kM] = d; movies = d } catch (_: Exception) { }
            if (series == null) try { val d = withContext(Dispatchers.IO) { Xt.seriesList(sub.url, sub.user, p) }; Mem.m[kS] = d; series = d } catch (_: Exception) { }
        }
        loading = false
    }
    val query = q.trim()
    val liveR = remember(live, query) {
        if (query.length < 2) emptyList() else {
            val h = Parental.hidden(prefs, live?.cats)
            live?.items.orEmpty().filter { it.cat !in h && it.name.contains(query, true) }.take(40)
        }
    }
    val movieR = remember(movies, query) {
        if (query.length < 2) emptyList() else {
            val h = Parental.hidden(prefs, movies?.cats)
            movies?.items.orEmpty().filter { it.cat !in h && it.name.contains(query, true) }.take(40)
        }
    }
    val seriesR = remember(series, query) {
        if (query.length < 2) emptyList() else {
            val h = Parental.hidden(prefs, series?.cats)
            series?.items.orEmpty().filter { it.cat !in h && it.name.contains(query, true) }.take(40)
        }
    }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BackBtn(onBack)
            SmallSearch(q, { q = it }, stringResource(R.string.search_all_hint), Modifier.weight(1f))
            if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = Acc, strokeWidth = 2.dp)
        }
        if (sub == null) Text(stringResource(R.string.no_active), color = Dim)
        else if (query.length < 2) Text(stringResource(R.string.search_all_hint), color = Dim)
        else if (liveR.isEmpty() && movieR.isEmpty() && seriesR.isEmpty()) { if (!loading) Text(stringResource(R.string.no_results), color = Dim) }
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (liveR.isNotEmpty()) {
                item { Text(stringResource(R.string.live), fontWeight = FontWeight.Bold, color = Acc) }
                items(liveR) { c -> ResRow(c.logo, c.name, 1f) { onLive(c) } }
            }
            if (movieR.isNotEmpty()) {
                item { Text(stringResource(R.string.movies), fontWeight = FontWeight.Bold, color = Acc) }
                items(movieR) { v -> ResRow(v.cover, v.name, 0.68f) { onMovie(v) } }
            }
            if (seriesR.isNotEmpty()) {
                item { Text(stringResource(R.string.series), fontWeight = FontWeight.Bold, color = Acc) }
                items(seriesR) { v -> ResRow(v.cover, v.name, 0.68f) { onSeries(v) } }
            }
        }
    }
}
