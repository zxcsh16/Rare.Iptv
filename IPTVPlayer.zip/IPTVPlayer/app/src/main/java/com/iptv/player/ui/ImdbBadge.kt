package com.iptv.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iptv.player.data.Imdb

/** Small "IMDb 7.8" (with OMDb key) or "TMDB 7.5" tag. Hidden until a real rating is found. */
@Composable fun ImdbBadge(title: String, series: Boolean, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var r by remember(title, series) { mutableStateOf(Imdb.cached(ctx, title, series)) }
    LaunchedEffect(title, series) { if (r == null) r = Imdb.rating(ctx, title, series).takeIf { Imdb.cached(ctx, title, series) != null } }
    val src = r.orEmpty().substringBefore(':', "")
    val v = r.orEmpty().substringAfter(':', "")
    if (v.isNotBlank()) {
        Row(modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xCC000000)).padding(end = 5.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(if (src == "I") "IMDb" else "TMDB", fontSize = 9.sp, lineHeight = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black,
                modifier = Modifier.clip(RoundedCornerShape(5.dp)).background(if (src == "I") Color(0xFFF5C518) else Color(0xFF01B4E4)).padding(horizontal = 4.dp, vertical = 2.dp))
            Text(v, fontSize = 11.sp, lineHeight = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
