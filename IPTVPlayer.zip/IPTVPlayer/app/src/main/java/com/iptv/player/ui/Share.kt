package com.iptv.player.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.iptv.player.R

/** Shares only the title (never the stream link, which contains account credentials). */
fun shareText(ctx: Context, text: String) {
    try {
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null))
    } catch (_: Exception) {}
}

@Composable fun CastSheet(url: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val firstFr = rememberFocusReq()
    AutoFocus(firstFr, ms = 150)
    Dialog(onDismissRequest = onClose) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.cast_title), fontWeight = FontWeight.Bold)
            Fx({
                try { ctx.startActivity(Intent("android.settings.CAST_SETTINGS")) }
                catch (_: Exception) { Toast.makeText(ctx, ctx.getString(R.string.cast_na), Toast.LENGTH_SHORT).show() }
                onClose()
            }, Modifier.fillMaxWidth().focusIf(true, firstFr), pad = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Filled.Cast, null); Text(stringResource(R.string.cast_screen)) }
            }
            Fx({
                try { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*"), null)) }
                catch (_: Exception) { Toast.makeText(ctx, ctx.getString(R.string.cast_na), Toast.LENGTH_SHORT).show() }
                onClose()
            }, Modifier.fillMaxWidth(), pad = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Filled.PlayArrow, null); Text(stringResource(R.string.cast_app)) }
            }
            Text(stringResource(R.string.cast_hint), color = Dim, fontSize = 11.sp)
        }
    }
}
