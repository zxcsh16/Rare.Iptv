package com.iptv.player.data

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

/** File access helpers (works on phones and TV boxes without the system file picker). */
object StoragePerm {
    fun has(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun request(a: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                a.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + a.packageName)))
            } else {
                a.requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 77)
            }
        } catch (e: Exception) {
            try { a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) {}
        }
    }

    fun root(): File = Environment.getExternalStorageDirectory()
    fun downloads(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    /** Folder used for backups when the user does not pick one. */
    fun appBackupDir(c: Context): File = (c.getExternalFilesDir("backup") ?: File(c.filesDir, "backup")).also { it.mkdirs() }
}
