package com.iptv.player.data

import android.content.Context
import android.content.Intent
import android.os.Build
import com.iptv.player.DownloadService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class DlReq(val id: String, val title: String, val grp: String, val url: String, val ext: String)

/** Resumable downloads (HTTP Range). Links are stored without passwords and resolved only when a download starts. */
object Downloader {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = HashMap<String, Job>()
    private val gate = Semaphore(2)
    val active = MutableStateFlow(0)

    fun dir(c: Context): File = (c.getExternalFilesDir("downloads") ?: File(c.filesDir, "downloads")).also { it.mkdirs() }

    fun enqueue(c: Context, s: Sub, reqs: List<DlReq>) {
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        scope.launch {
            for (r in reqs) {
                val old = dao.dl(r.id)
                if (old != null && old.status == "done" && File(old.path).exists()) continue
                val ext = r.ext.filter { it.isLetterOrDigit() }.take(5).ifBlank { "mp4" }
                val f = File(dir(app), "${s.id}_${r.id.hashCode().toLong() and 0xffffffffL}.$ext")
                dao.putDl(Dl(r.id, s.id, r.title, r.grp, r.url, f.path, "queued", old?.done ?: 0L, old?.total ?: 0L, System.currentTimeMillis()))
                start(app, s, r.id)
            }
        }
    }

    @Synchronized fun start(c: Context, s: Sub, id: String) {
        if (jobs[id]?.isActive == true) return
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        active.update { it + 1 }
        try {
            val i = Intent(app, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i)
        } catch (_: Exception) {}
        val j = scope.launch { gate.withPermit { run(app, s, id, dao) } }
        j.invokeOnCompletion { active.update { it - 1 } }
        jobs[id] = j
    }

    private suspend fun run(c: Context, s: Sub, id: String, dao: StoreDao) {
        val d = dao.dl(id) ?: return
        try {
            dao.setSt(id, "running")
            val f = File(d.path)
            var have = if (f.exists()) f.length() else 0L
            val con = URL(resolve(c, s, d.url)).openConnection() as HttpURLConnection
            con.connectTimeout = 15000; con.readTimeout = 30000
            if (have > 0) con.setRequestProperty("Range", "bytes=$have-")
            val code = con.responseCode
            if (code == 416) { dao.prog(id, have, have, "done"); return }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            if (code == 200) have = 0L
            val len = con.contentLengthLong
            val total = if (len > 0) len + have else 0L
            var done = have
            var last = 0L
            con.inputStream.use { input ->
                FileOutputStream(f, have > 0).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 700) { last = now; dao.prog(id, done, total, "running") }
                        currentCoroutineContext().ensureActive()
                    }
                }
            }
            dao.prog(id, done, if (total > 0) total else done, "done")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            dao.setSt(id, "error")
        }
    }

    fun pause(c: Context, id: String) {
        val dao = Store.get(c.applicationContext).dao()
        scope.launch {
            jobs[id]?.cancelAndJoin()
            val d = dao.dl(id) ?: return@launch
            dao.prog(id, File(d.path).length(), d.total, "paused")
        }
    }

    fun remove(c: Context, id: String) {
        val dao = Store.get(c.applicationContext).dao()
        scope.launch {
            jobs[id]?.cancelAndJoin()
            dao.dl(id)?.let { File(it.path).delete() }
            dao.delDl(id)
        }
    }
}
