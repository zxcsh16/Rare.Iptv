package com.iptv.player.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import com.iptv.player.DownloadService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

data class DlReq(val id: String, val kind: String, val grp: String, val title: String, val cover: String,
                 val base: String, val url: String, val ext: String)

/** Resumable downloads (HTTP Range) into the app folder or a folder chosen by the user (SAF). */
object Downloader {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = HashMap<String, Job>()
    private val mutex = Mutex()
    private val running = MutableStateFlow(0)
    val active = MutableStateFlow(0)
    val bytes = AtomicLong(0)

    private fun prefs(c: Context) = c.getSharedPreferences("app", 0)
    fun limit(c: Context): Int = prefs(c).getInt("dl_limit", 2).coerceIn(1, 5)
    fun dir(c: Context): File = (c.getExternalFilesDir("downloads") ?: File(c.filesDir, "downloads")).also { it.mkdirs() }
    private fun tree(c: Context): Uri? = prefs(c).getString("dl_tree", null)?.let { Uri.parse(it) }
    fun clean(n: String): String = n.replace(Regex("[\\\\/:*?\"<>|]"), " ").replace(Regex("\\s+"), " ").trim().take(120).ifBlank { "file" }

    private fun create(c: Context, base: String, ext: String): String {
        val name = clean(base) + "." + ext
        val t = tree(c)
        if (t != null) {
            try {
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "application/octet-stream"
                val f = DocumentFile.fromTreeUri(c, t)?.createFile(mime, name)
                if (f != null) return f.uri.toString()
            } catch (_: Exception) {}
        }
        var f = File(dir(c), name)
        var i = 1
        while (f.exists()) { f = File(dir(c), clean(base) + " (" + i + ")." + ext); i++ }
        return f.path
    }
    private fun isUri(p: String) = p.startsWith("content:")
    fun sizeOf(c: Context, p: String): Long = if (isUri(p)) (DocumentFile.fromSingleUri(c, Uri.parse(p))?.length() ?: 0L) else File(p).length()
    fun exists(c: Context, p: String): Boolean = if (isUri(p)) (DocumentFile.fromSingleUri(c, Uri.parse(p))?.exists() == true) else File(p).exists()
    private fun open(c: Context, p: String, append: Boolean): OutputStream =
        if (isUri(p)) c.contentResolver.openOutputStream(Uri.parse(p), if (append) "wa" else "wt")!! else FileOutputStream(File(p), append)
    private fun delete(c: Context, p: String) { try { if (isUri(p)) DocumentFile.fromSingleUri(c, Uri.parse(p))?.delete() else File(p).delete() } catch (_: Exception) {} }
    fun playUri(p: String): String = if (isUri(p)) p else Uri.fromFile(File(p)).toString()

    fun enqueue(c: Context, s: Sub, reqs: List<DlReq>) {
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        scope.launch {
            for (r in reqs) {
                val old = dao.dl(r.id)
                if (old != null && old.status == "done" && exists(app, old.path)) continue
                val ext = r.ext.filter { it.isLetterOrDigit() }.take(5).ifBlank { "mp4" }
                val path = if (old != null && exists(app, old.path)) old.path else create(app, r.base, ext)
                dao.putDl(Dl(r.id, s.id, r.kind, r.grp, r.title, r.cover, r.url, path, "queued", old?.done ?: 0L, old?.total ?: 0L, System.currentTimeMillis()))
                start(app, s, r.id)
            }
        }
    }

    fun startService(c: Context, action: String?) {
        try {
            val i = Intent(c, DownloadService::class.java)
            if (action != null) i.action = action
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        } catch (_: Exception) {}
    }

    @Synchronized fun start(c: Context, s: Sub, id: String) {
        if (jobs[id]?.isActive == true) return
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        active.update { it + 1 }
        startService(app, null)
        val j = scope.launch {
            acquire(app)
            try { run(app, s, id, dao) } finally { running.update { it - 1 } }
        }
        j.invokeOnCompletion { active.update { it - 1 } }
        jobs[id] = j
    }

    private suspend fun acquire(c: Context) {
        while (true) {
            mutex.withLock { if (running.value < limit(c)) { running.update { it + 1 }; return } }
            delay(500)
        }
    }

    private suspend fun run(c: Context, s: Sub, id: String, dao: StoreDao) {
        val d = dao.dl(id) ?: return
        try {
            dao.setSt(id, "running")
            var have = sizeOf(c, d.path)
            val con = URL(resolve(c, s, d.url)).openConnection() as HttpURLConnection
            con.connectTimeout = 15000; con.readTimeout = 30000
            if (have > 0) con.setRequestProperty("Range", "bytes=$have-")
            val code = con.responseCode
            if (code == 416) { dao.prog(id, have, have, "done"); return }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            if (code == 200) have = 0L
            val len = con.contentLengthLong
            val total = if (len > 0) len + have else 0L
            var done = have
            var last = 0L
            con.inputStream.use { input ->
                open(c, d.path, have > 0).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        bytes.addAndGet(n.toLong())
                        val now = System.currentTimeMillis()
                        if (now - last > 700) { last = now; dao.prog(id, done, total, "running") }
                        currentCoroutineContext().ensureActive()
                    }
                }
            }
            dao.prog(id, done, if (total > 0) total else done, "done")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            dao.setSt(id, "error")
        }
    }

    fun pause(c: Context, id: String) {
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        scope.launch {
            jobs[id]?.cancelAndJoin()
            val d = dao.dl(id) ?: return@launch
            dao.prog(id, sizeOf(app, d.path), d.total, "paused")
        }
    }
    fun remove(c: Context, id: String) {
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        scope.launch {
            jobs[id]?.cancelAndJoin()
            dao.dl(id)?.let { delete(app, it.path) }
            dao.delDl(id)
        }
    }
    fun pauseAll(c: Context) {
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        scope.launch { for (d in dao.activeDl()) { jobs[d.id]?.cancelAndJoin(); dao.prog(d.id, sizeOf(app, d.path), d.total, "paused") } }
    }
    fun resumeAll(c: Context) {
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        scope.launch {
            val sdao = Db.get(app).dao()
            for (d in dao.pausedDl()) { val s = sdao.byId(d.subId) ?: continue; start(app, s, d.id) }
        }
    }
    fun cancelAll(c: Context) {
        val app = c.applicationContext
        val dao = Store.get(app).dao()
        scope.launch {
            for (d in dao.activeDl() + dao.pausedDl()) { jobs[d.id]?.cancelAndJoin(); delete(app, d.path); dao.delDl(d.id) }
        }
    }
}
