package com.iptv.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.text.format.Formatter
import com.iptv.player.data.Downloader
import com.iptv.player.data.Store
import kotlinx.coroutines.*

/** Foreground service: keeps downloads alive and shows speed/progress with pause, resume and cancel actions. */
class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun pi(code: Int, action: String): PendingIntent {
        val i = Intent(this, DownloadService::class.java).setAction(action)
        val fl = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, code, i, fl) else PendingIntent.getService(this, code, i, fl)
    }

    @Suppress("DEPRECATION")
    private fun act(icon: Int, t: String, p: PendingIntent): Notification.Action = Notification.Action.Builder(icon, t, p).build()

    @Suppress("DEPRECATION")
    private fun note(title: String, text: String, pct: Int, paused: Boolean): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "dl") else Notification.Builder(this)
        b.setSmallIcon(if (paused) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_sys_download)
            .setContentTitle(title).setContentText(text).setOnlyAlertOnce(true).setOngoing(!paused)
        if (!paused) {
            b.setProgress(100, pct, pct <= 0)
            b.addAction(act(android.R.drawable.ic_media_pause, getString(R.string.dl_pause), pi(1, "pause")))
        } else {
            b.addAction(act(android.R.drawable.ic_media_play, getString(R.string.dl_resume), pi(2, "resume")))
        }
        b.addAction(act(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.cancel), pi(3, "cancel")))
        return b.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 26) nm().createNotificationChannel(NotificationChannel("dl", getString(R.string.down), NotificationManager.IMPORTANCE_LOW))
        nm().cancel(8)
        when (intent?.action) {
            "pause" -> Downloader.pauseAll(this)
            "resume" -> Downloader.resumeAll(this)
            "cancel" -> Downloader.cancelAll(this)
        }
        startForeground(7, note(getString(R.string.dl_running), "", 0, false))
        if (loop?.isActive != true) loop = scope.launch { watch() }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private suspend fun watch() {
        val dao = Store.get(this).dao()
        var last = Downloader.bytes.get()
        var idle = 0
        while (true) {
            delay(1000)
            val list = dao.activeDl()
            val b = Downloader.bytes.get()
            val speed = b - last
            last = b
            if (list.isEmpty() && Downloader.active.value == 0) {
                idle++
                if (idle < 2) continue
                val paused = dao.pausedDl().size
                stopForeground(true)
                if (paused > 0) nm().notify(8, note(getString(R.string.dl_paused_n, paused), "", 0, true))
                stopSelf()
                return
            }
            idle = 0
            val done = list.sumOf { it.done }
            val total = list.sumOf { it.total }
            val pct = if (total > 0) (done * 100 / total).toInt() else 0
            nm().notify(7, note(getString(R.string.dl_running) + " (" + list.size + ")", Formatter.formatFileSize(this, speed) + "/s · " + pct + "%", pct, false))
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
