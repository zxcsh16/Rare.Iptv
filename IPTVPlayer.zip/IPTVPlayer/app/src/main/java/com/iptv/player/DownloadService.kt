package com.iptv.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.iptv.player.data.Downloader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Keeps the process alive while downloads run; stops itself when none are active. */
class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("dl", getString(R.string.down), NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "dl") else Notification.Builder(this)
        startForeground(7, b.setContentTitle(getString(R.string.dl_running)).setSmallIcon(android.R.drawable.stat_sys_download).build())
        CoroutineScope(Dispatchers.Default).launch {
            Downloader.active.first { it == 0 }
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
