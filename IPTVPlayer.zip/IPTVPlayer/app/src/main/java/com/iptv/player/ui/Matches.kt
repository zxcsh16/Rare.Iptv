package com.iptv.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.iptv.player.R
import com.iptv.player.data.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Match(val league: String, val home: String, val homeLogo: String, val away: String, val awayLogo: String,
                 val time: Long, val state: String, val clock: String, val hs: String, val aws: String)

/** Football fixtures from ESPN's public scoreboard feed (no key needed). */
object Sports {
    private val leagues = listOf("uefa.champions", "uefa.europa", "eng.1", "esp.1", "ita.1", "ger.1", "fra.1", "ksa.1", "fifa.world", "usa.1")

    private fun parseTime(s: String): Long {
        for (p in listOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")) {
            try {
                val f = SimpleDateFormat(p, Locale.US)
                f.timeZone = TimeZone.getTimeZone("UTC")
                return f.parse(s)!!.time
            } catch (_: Exception) {}
        }
        return 0L
    }

    private fun one(slug: String, range: String): List<Match> {
        val j = JSONObject(Net.get("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard?dates=$range&limit=200"))
        val league = j.optJSONArray("leagues")?.optJSONObject(0)?.optString("name").orEmpty()
        val ev = j.optJSONArray("events") ?: return emptyList()
        val out = ArrayList<Match>()
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            val cs = e.optJSONArray("competitions")?.optJSONObject(0)?.optJSONArray("competitors") ?: continue
            var h: JSONObject? = null
            var a: JSONObject? = null
            for (k in 0 until cs.length()) {
                val c = cs.getJSONObject(k)
                if (c.optString("homeAway") == "home") h = c else a = c
            }
            if (h == null || a == null) continue
            val st = e.optJSONObject("status")
            out.add(Match(league.ifBlank { slug },
                h.optJSONObject("team")?.optString("displayName").orEmpty(), h.optJSONObject("team")?.optString("logo").orEmpty(),
                a.optJSONObject("team")?.optString("displayName").orEmpty(), a.optJSONObject("team")?.optString("logo").orEmpty(),
                parseTime(e.optString("date")), st?.optJSONObject("type")?.optString("state").orEmpty(),
                st?.optString("displayClock").orEmpty(), h.optString("score"), a.optString("score")))
        }
        return out
    }

    suspend fun load(): List<Match> = coroutineScope {
        val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -1); val from = fmt.format(c.time)
        c.add(Calendar.DAY_OF_YEAR, 9); val to = fmt.format(c.time)
        leagues.map { s -> async(Dispatchers.IO) { try { one(s, "$from-$to") } catch (_: Exception) { emptyList<Match>() } } }
            .awaitAll().flatten().sortedBy { it.time }
    }
}

@Composable fun MatchRow(m: Match, tf: SimpleDateFormat) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(.07f)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(m.home, Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 2, fontSize = 13.sp)
        AsyncImage(m.homeLogo, null, Modifier.size(30.dp), contentScale = ContentScale.Fit)
        Column(Modifier.width(84.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            when (m.state) {
                "pre" -> Text(tf.format(Date(m.time)), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                "in" -> { Text(m.hs + " - " + m.aws, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ok); Text(m.clock, fontSize = 11.sp, color = Err) }
                else -> { Text(m.hs + " - " + m.aws, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("FT", fontSize = 11.sp, color = Dim) }
            }
        }
        AsyncImage(m.awayLogo, null, Modifier.size(30.dp), contentScale = ContentScale.Fit)
        Text(m.away, Modifier.weight(1f), maxLines = 2, fontSize = 13.sp)
    }
}

@Composable fun MatchesScreen(onBack: () -> Unit) {
    var all by remember { mutableStateOf<List<Match>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var day by remember { mutableIntStateOf(0) }
    val dayFmt = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val labelFmt = remember { SimpleDateFormat("EEE d", Locale.getDefault()) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val days = remember { (0..6).map { d -> val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, d); c.time } }
    LaunchedEffect(reload) {
        all = null; failed = false
        try { all = Sports.load() } catch (_: Exception) { failed = true }
    }
    val key = dayFmt.format(days[day])
    val shown = all.orEmpty().filter { dayFmt.format(Date(it.time)) == key }.groupBy { it.league }.entries.toList()
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            Text(stringResource(R.string.matches), fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Fx({ reload += 1 }, pad = 8.dp) { Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp)) }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(days) { i, d -> Chip(if (i == 0) stringResource(R.string.today) else labelFmt.format(d), i == day) { day = i } }
        }
        when {
            failed -> Text(stringResource(R.string.match_err), color = Err)
            all == null -> CircularProgressIndicator(color = Acc)
            shown.isEmpty() -> Text(stringResource(R.string.match_none), color = Dim)
            else -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                shown.forEach { e ->
                    item { Text(e.key, fontWeight = FontWeight.Bold, color = Acc, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                    items(e.value) { m -> MatchRow(m, timeFmt) }
                }
            }
        }
    }
}
