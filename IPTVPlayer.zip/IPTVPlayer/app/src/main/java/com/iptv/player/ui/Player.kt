package com.iptv.player.ui

import android.app.Activity
import android.app.PictureInPictureParams
import android.net.Uri
import android.os.Build
import android.util.Rational
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.unit.Dp
import kotlin.math.roundToInt
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.iptv.player.R
import kotlinx.coroutines.delay
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Date

private val Glass = Brush.horizontalGradient(listOf(Color(0x44FFFFFF), Color(0x44FFFFFF)))

private fun tfmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val ss = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, ss) else "%d:%02d".format(m, ss)
}

@Composable private fun RoundBtn(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) =
    Fx(onClick, modifier, brush = Glass, pad = 9.dp, round = true, content = content)

/** LibVLC based player: plays almost every IPTV/VOD format, with custom TV-friendly controls. */
/** True while the player screen is shown (lets the activity switch to picture-in-picture on Home). */
@Volatile var playerOn = false

fun enterPip(a: Activity) {
    if (Build.VERSION.SDK_INT >= 26) try {
        a.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    } catch (_: Exception) { }
}

/** Shared LibVLC engine. [get] is cheap after the first call; MainActivity calls it on a background thread at launch. */
object VlcHolder {
    @Volatile private var inst: LibVLC? = null
    fun get(ctx: android.content.Context): LibVLC = inst ?: synchronized(this) {
        inst ?: LibVLC(ctx.applicationContext, arrayListOf("--no-stats", "--no-sub-autodetect-file", "--no-video-title-show",
            "--no-snapshot-preview", "--clock-jitter=0")).also { inst = it }
    }
}

@Composable fun PlayerScreen(url: String, title: String, startMs: Long, onProgress: (Long, Long) -> Unit, onBack: () -> Unit, onCast: () -> Unit, onEnded: () -> Unit = {}, onRestart: () -> Unit = {}, onNext: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    var playing by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf(false) }
    var ended by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var time by remember { mutableLongStateOf(0L) }
    var length by remember { mutableLongStateOf(0L) }
    var show by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var rate by remember { mutableFloatStateOf(1f) }
    var aspect by remember { mutableIntStateOf(prefs.getInt("aspect", 0)) }
    var dlg by remember { mutableIntStateOf(0) }
    var ask by remember(url, reload) { mutableStateOf(false) }          // "resume or start over" prompt, shown inside the player
    var gest by remember { mutableStateOf<String?>(null) }              // brightness / volume indicator
    var gestTick by remember { mutableIntStateOf(0) }
    val activity = ctx as? Activity
    val am = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(3).toFloat() / am.getStreamMaxVolume(3).coerceAtLeast(1)) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var held by remember { mutableStateOf(false) }          // a remote key is being held for fast seeking
    var seekAcc by remember { mutableLongStateOf(-1L) }
    var lastSeekAt by remember { mutableLongStateOf(0L) }
    var seeked by remember(url, reload) { mutableStateOf(false) }
    val scales = remember {
        listOf(MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FIT_SCREEN, MediaPlayer.ScaleType.SURFACE_FILL,
            MediaPlayer.ScaleType.SURFACE_16_9, MediaPlayer.ScaleType.SURFACE_4_3, MediaPlayer.ScaleType.SURFACE_ORIGINAL)
    }
    val rates = remember { listOf(1f, 1.25f, 1.5f, 2f, 0.75f) }
    val root = remember { FocusRequester() }
    val playFocus = remember { FocusRequester() }
    // frame dropping stays on so weak TV boxes keep up
    // One shared engine for the whole app (created once, already warmed up at launch): building a new LibVLC for every
    // video was the biggest part of the slow start. Only the lightweight MediaPlayer is created per video.
    val vlc = remember { VlcHolder.get(ctx) }
    val mp = remember(url, reload) { MediaPlayer(vlc) }
    val layout = remember(mp) { VLCVideoLayout(ctx) }

    DisposableEffect(mp) {
        mp.attachViews(layout, null, false, false)
        val media = Media(vlc, Uri.parse(url))
        media.setHWDecoderEnabled(prefs.getBoolean("hw", true), false)
        media.addOption(":network-caching=" + prefs.getInt("cache", 1500))
        media.addOption(":http-reconnect")
        mp.media = media
        media.release()
        mp.setEventListener { e ->
            when (e.type) {
                MediaPlayer.Event.Playing -> {
                    playing = true; buffering = false
                    if (!seeked) { seeked = true; if (startMs > 5000) ask = true }
                }
                MediaPlayer.Event.Paused -> playing = false
                MediaPlayer.Event.Buffering -> buffering = e.buffering < 100f
                MediaPlayer.Event.TimeChanged -> time = e.timeChanged
                MediaPlayer.Event.LengthChanged -> length = e.lengthChanged
                MediaPlayer.Event.EncounteredError -> { err = true; buffering = false }
                MediaPlayer.Event.EndReached -> { playing = false; ended = true }
            }
        }
        mp.play()
        onDispose {
            try { onProgress(mp.time, mp.length) } catch (_: Exception) {}
            mp.setEventListener(null)
            mp.stop(); mp.detachViews(); mp.release()
        }
    }
    LaunchedEffect(ended) {
        if (ended) { try { onProgress(length, length) } catch (_: Exception) {}; onEnded() }   // mark watched, then jump to the next episode
    }
    LaunchedEffect(ask) { if (ask) { mp.setTime(startMs); mp.pause() } }   // park on the saved frame until the viewer chooses
    LaunchedEffect(gestTick) { if (gest != null) { delay(800); gest = null } }
    DisposableEffect(Unit) {
        playerOn = true
        onDispose {
            playerOn = false
            activity?.window?.let { w -> val lp = w.attributes; lp.screenBrightness = -1f; w.attributes = lp }
        }
    }
    LaunchedEffect(aspect, mp) { mp.setVideoScale(scales[aspect % scales.size]) }
    LaunchedEffect(rate, mp) { mp.setRate(rate) }
    LaunchedEffect(show, tick, playing) { if (show && playing) { delay(5000); show = false } }
    LaunchedEffect(show, ask) {
        delay(60)
        if (!ask) try { if (show) playFocus.requestFocus() else root.requestFocus() } catch (_: Exception) {}
    }
    LaunchedEffect(Unit) { while (true) { delay(10000); onProgress(time, length) } }

    fun seek(d: Long) { mp.setTime((mp.time + d).coerceIn(0L, if (length > 0) length else Long.MAX_VALUE)) }
    fun toggle() { if (mp.isPlaying) mp.pause() else mp.play() }
    /** Holding a key scrubs through the video, faster the longer it is held. */
    fun holdSeek(dir: Int, rc: Int) {
        held = true
        val now = System.currentTimeMillis()
        if (seekAcc < 0) seekAcc = mp.time
        if (now - lastSeekAt < 180) return
        lastSeekAt = now
        seekAcc = (seekAcc + dir * (10_000L + rc.coerceAtMost(30) * 1_000L)).coerceIn(0L, if (length > 0) length else Long.MAX_VALUE)
        mp.setTime(seekAcc)
        time = seekAcc
        gest = (if (dir > 0) "⏩  " else "⏪  ") + tfmt(seekAcc) + (if (length > 0) " / " + tfmt(length) else "")
        tick++
    }
    fun endHold() { held = false; seekAcc = -1L; gestTick++ }
    BackHandler { if (ask) onBack() else if (show) show = false else onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(root).focusable()
        .pointerInput(Unit) { detectTapGestures(onTap = { show = !show; tick++ }) }
        .pointerInput(Unit) {
            // swipe up/down: left half = brightness, right half = volume
            var left = true
            detectVerticalDragGestures(
                onDragStart = { left = it.x < size.width / 2f },
                onDragEnd = { gestTick++ }, onDragCancel = { gestTick++ },
                onVerticalDrag = { ch, dy ->
                    ch.consume()
                    if (!ask) {
                        val d = -dy / size.height * 1.4f
                        if (left) {
                            val w = activity?.window
                            val cur = w?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f
                            val nv = (cur + d).coerceIn(0.02f, 1f)
                            w?.let { val lp = it.attributes; lp.screenBrightness = nv; it.attributes = lp }
                            gest = "☀  " + (nv * 100).roundToInt() + "%"
                        } else {
                            vol = (vol + d).coerceIn(0f, 1f)
                            am.setStreamVolume(3, (vol * am.getStreamMaxVolume(3)).roundToInt(), 0)
                            gest = "🔊  " + (vol * 100).roundToInt() + "%"
                        }
                    }
                })
        }
        .onPreviewKeyEvent { ev ->
            val nk = ev.nativeKeyEvent
            if (ask) false
            else if (ev.type == KeyEventType.KeyUp && held) { endHold(); true }
            else if (ev.type != KeyEventType.KeyDown) false
            else {
                tick++
                when (ev.key) {
                    Key.MediaPlayPause, Key.Spacebar -> { toggle(); show = true; true }
                    Key.MediaPlay -> { if (!mp.isPlaying) mp.play(); show = true; true }
                    Key.MediaPause -> { if (mp.isPlaying) mp.pause(); show = true; true }
                    Key.MediaStop -> { onBack(); true }
                    Key.MediaNext -> { onEnded(); true }
                    Key.MediaPrevious -> { mp.setTime(0L); true }
                    Key.MediaFastForward -> if (nk.repeatCount > 0) { holdSeek(1, nk.repeatCount); true } else { seek(10000); show = true; true }
                    Key.MediaRewind -> if (nk.repeatCount > 0) { holdSeek(-1, nk.repeatCount); true } else { seek(-10000); show = true; true }
                    Key.MediaAudioTrack -> { dlg = 2; true }
                    Key.Info -> { show = !show; true }
                    // Left / Right: tap = ±10 s (controls hidden) or move focus (controls shown); HOLD = scrub, accelerating, in both cases
                    Key.DirectionLeft -> if (length > 0 && nk.repeatCount > 0) { holdSeek(-1, nk.repeatCount); true }
                        else if (!show) { seek(-10000); gest = "⏪  10s"; gestTick++; true } else false
                    Key.DirectionRight -> if (length > 0 && nk.repeatCount > 0) { holdSeek(1, nk.repeatCount); true }
                        else if (!show) { seek(10000); gest = "⏩  10s"; gestTick++; true } else false
                    Key.ChannelUp -> if (length > 0) { seek(60000); gest = "⏩  60s"; gestTick++; true } else false
                    Key.ChannelDown -> if (length > 0) { seek(-60000); gest = "⏪  60s"; gestTick++; true } else false
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.DirectionUp, Key.DirectionDown, Key.Menu -> if (!show) { show = true; true } else false
                    else -> false
                }
            }
        }) {
        AndroidView({ layout }, Modifier.fillMaxSize())
        if (buffering && !err) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Acc)
        if (err) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.playback_error), color = Err)
            Fx({ err = false; buffering = true; reload += 1 }, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.retry)) }
        }
        AnimatedVisibility(show && !ask, Modifier.fillMaxSize(), enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xCC000000)))))
                RoundBtn(onBack, Modifier.align(Alignment.TopStart).padding(14.dp)) { Icon(Icons.Filled.ArrowBack, null, Modifier.size(18.dp)) }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.weight(1f))
                        RoundBtn({ dlg = 2 }) { Icon(Icons.Filled.VolumeUp, null, Modifier.size(16.dp)) }
                        RoundBtn({ aspect = (aspect + 1) % scales.size; prefs.edit().putInt("aspect", aspect).apply() }) { Icon(Icons.Filled.AspectRatio, null, Modifier.size(16.dp)) }
                        RoundBtn({ rate = rates[(rates.indexOf(rate) + 1) % rates.size] }) { Text(if (rate % 1f == 0f) rate.toInt().toString() + "×" else rate.toString() + "×", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        if (url.startsWith("http")) RoundBtn(onCast) { Icon(Icons.Filled.Cast, null, Modifier.size(16.dp)) }
                        if (Build.VERSION.SDK_INT >= 26 && activity != null) RoundBtn({ enterPip(activity) }) { Icon(Icons.Filled.PictureInPictureAlt, null, Modifier.size(16.dp)) }
                    }
                    if (length > 0) {
                        Slider(value = drag ?: (time.toFloat() / length).coerceIn(0f, 1f),
                            onValueChange = { drag = it; tick++ },
                            onValueChangeFinished = { drag?.let { mp.setTime((it * length).toLong()) }; drag = null },
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Acc, inactiveTrackColor = Color(0x55FFFFFF)),
                            modifier = Modifier.fillMaxWidth().height(20.dp))
                        Row(Modifier.fillMaxWidth()) {
                            Text(tfmt(time), fontSize = 11.sp)
                            Spacer(Modifier.weight(1f))
                            val remain = (length - time).coerceAtLeast(0)
                            val fmt = remember { android.text.format.DateFormat.getTimeFormat(ctx) }
                            Text(stringResource(R.string.ends_at) + " " + fmt.format(Date(System.currentTimeMillis() + remain)) + "   -" + tfmt(remain), fontSize = 11.sp)
                        }
                    } else Text("● " + stringResource(R.string.live_badge), color = Err, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Box(Modifier.fillMaxWidth()) {
                        if (length > 0) RoundBtn({ mp.setTime(0L) }, Modifier.align(Alignment.CenterStart)) { Text(stringResource(R.string.start_over), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        // series only: jump to the next episode (bottom right)
                        if (onNext != null) RoundBtn(onNext, Modifier.align(Alignment.CenterEnd)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(stringResource(R.string.next_episode), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Icon(Icons.Filled.SkipNext, null, Modifier.size(18.dp))
                            }
                        }
                        Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (length > 0) RoundBtn({ seek(-10000) }) { Text("-10", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            RoundBtn({ toggle() }, Modifier.focusRequester(playFocus)) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(22.dp)) }
                            if (length > 0) RoundBtn({ seek(10000) }) { Text("+10", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
        gest?.let { g ->
            Text(g, Modifier.align(Alignment.Center).clip(RoundedCornerShape(14.dp)).background(Color(0x99000000)).padding(horizontal = 18.dp, vertical = 10.dp),
                fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        if (ask) Box(Modifier.fillMaxSize().background(Color(0xB3000000)).pointerInput(Unit) { detectTapGestures { } }, Alignment.Center) {
            val rf = remember { FocusRequester() }
            LaunchedEffect(Unit) { delay(120); try { rf.requestFocus() } catch (_: Exception) {} }
            Column(Modifier.clip(RoundedCornerShape(22.dp)).background(Side).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2)
                Text(stringResource(R.string.resume_ask, tfmt(startMs)), color = Dim, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Fx({ ask = false; mp.play() }, Modifier.focusRequester(rf), brush = Grad, pad = 12.dp) {
                        Text(stringResource(R.string.resume_from, tfmt(startMs)), fontWeight = FontWeight.Bold)
                    }
                    Fx({ ask = false; onRestart(); mp.setTime(0L); mp.play() }, pad = 12.dp) { Text(stringResource(R.string.start_over)) }
                }
            }
        }
        // clock: visible only together with the controls
        AnimatedVisibility(show && !ask, Modifier.align(Alignment.TopEnd).padding(18.dp), enter = fadeIn(), exit = fadeOut()) { ClockText(16.sp) }
    }

    if (dlg == 1 || dlg == 2) {
        val tr: Array<MediaPlayer.TrackDescription> = (if (dlg == 1) mp.spuTracks else mp.audioTracks) ?: emptyArray()
        val curId = if (dlg == 1) mp.spuTrack else mp.audioTrack
        Dialog(onDismissRequest = { dlg = 0 }) {
            Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(if (dlg == 1) R.string.subtitles else R.string.audio_track), fontWeight = FontWeight.Bold)
                if (tr.isEmpty()) Text(stringResource(R.string.no_tracks), color = Dim, fontSize = 12.sp)
                tr.forEach { t ->
                    Fx({ if (dlg == 1) mp.setSpuTrack(t.id) else mp.setAudioTrack(t.id); dlg = 0 }, Modifier.fillMaxWidth(), brush = if (t.id == curId) Grad else null, pad = 10.dp) {
                        Text(t.name, maxLines = 1, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
