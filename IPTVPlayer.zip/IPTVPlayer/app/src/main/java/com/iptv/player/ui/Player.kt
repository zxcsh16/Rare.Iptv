package com.iptv.player.ui

import android.app.Activity
import android.app.PictureInPictureParams
import android.net.Uri
import android.os.Build
import android.util.Rational
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.unit.Dp
import kotlin.math.roundToInt
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.iptv.player.R
import kotlinx.coroutines.delay
import android.view.Gravity
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import java.util.Date

private val Glass = Brush.horizontalGradient(listOf(Color(0x44FFFFFF), Color(0x44FFFFFF)))

private fun tfmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val ss = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, ss) else "%d:%02d".format(m, ss)
}

@Composable private fun RoundBtn(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) =
    Fx(onClick, modifier, brush = Glass, pad = 9.dp, round = true, content = content)

/** Media3 ExoPlayer based player (hardware decoding, 4K capable) with custom TV-friendly controls. */
/** True while the player screen is shown (lets the activity switch to picture-in-picture on Home). */
@Volatile var playerOn = false

fun enterPip(a: Activity) {
    if (Build.VERSION.SDK_INT >= 26) try {
        a.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    } catch (_: Exception) { }
}

/** Small wrapper so the controls below talk to the engine through a few simple calls. */
private class Eng(val p: ExoPlayer) {
    val time: Long get() = p.currentPosition.coerceAtLeast(0L)
    val length: Long get() = if (p.duration == C.TIME_UNSET || p.isCurrentMediaItemLive) 0L else p.duration
    val isPlaying: Boolean get() = p.playWhenReady && p.playbackState != Player.STATE_ENDED
    fun setTime(ms: Long) = p.seekTo(ms)
    fun play() { if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L); p.play() }
    fun pause() = p.pause()
}

/**
 * [level] 0 = normal. 1 = plain (synchronous) MediaCodec queueing, the usual cure for 4K decoders that refuse to start.
 * 2 = also prefer a 1080p variant when the stream offers one. [noAudio] drops audio when its decoder is what fails.
 */
private fun buildPlayer(ctx: android.content.Context, cacheMs: Int, level: Int = 0, noAudio: Boolean = false): ExoPlayer {
    val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15000).setReadTimeoutMs(25000).setUserAgent("VLC/3.0.20 LibVLC/3.0.20")   // same identity as before: some providers whitelist it
    val msf = DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http))
    val start = cacheMs.coerceIn(1000, 10000)
    // 4K streams run at 40-100 Mbps: a fixed 64 MB buffer holds only a few seconds and stalls. Size it from the app's heap instead.
    val am = ctx.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
    val big = (ctx.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_LARGE_HEAP) != 0
    val heapMb = if (big) am.largeMemoryClass else am.memoryClass
    val bufMb = (heapMb / 3).coerceIn(48, 192)
    val lc = DefaultLoadControl.Builder()
        .setBufferDurationsMs(15000, 40000, start, maxOf(3000, start))
        .setTargetBufferBytes(bufMb * 1024 * 1024).setPrioritizeTimeOverSizeThresholds(false)
        .build()
    var rf = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
    if (level >= 1) rf = rf.forceDisableMediaCodecAsynchronousQueueing()
    val ts = DefaultTrackSelector(ctx)
    var pb = ts.buildUponParameters().setAllowVideoMixedMimeTypeAdaptiveness(true)
    if (level >= 2) pb = pb.setMaxVideoSize(1920, 1080)
    if (noAudio) pb = pb.setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
    ts.setParameters(pb.build())
    return ExoPlayer.Builder(ctx, rf).setMediaSourceFactory(msf).setLoadControl(lc).setTrackSelector(ts).build()
}

@Composable fun PlayerScreen(url: String, title: String, startMs: Long, onProgress: (Long, Long) -> Unit, onBack: () -> Unit, onCast: () -> Unit, onEnded: () -> Unit = {}, onRestart: () -> Unit = {}, onNext: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    var playing by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf(false) }
    var errInfo by remember { mutableStateOf("") }                       // error name shown under the message (helps to see why a stream failed)
    var level by remember(url) { mutableIntStateOf(0) }                 // automatic "safer settings" retries for decoder problems (4K)
    var noAudio by remember(url) { mutableStateOf(false) }
    var retryPos by remember(url) { mutableLongStateOf(0L) }            // position to come back to after an automatic retry
    var ended by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var time by remember { mutableLongStateOf(0L) }
    var length by remember { mutableLongStateOf(0L) }
    var show by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var rate by remember { mutableFloatStateOf(1f) }
    var aspect by remember { mutableIntStateOf(prefs.getInt("aspect", 0)) }
    var dlg by remember { mutableIntStateOf(0) }
    var ask by remember(url, reload) { mutableStateOf(false) }          // "resume or start over" prompt, shown inside the player
    var gest by remember { mutableStateOf<String?>(null) }              // brightness / volume indicator
    var gestTick by remember { mutableIntStateOf(0) }
    val activity = ctx as? Activity
    val am = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(3).toFloat() / am.getStreamMaxVolume(3).coerceAtLeast(1)) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var held by remember { mutableStateOf(false) }          // a remote key is being held for fast seeking
    var seekAcc by remember { mutableLongStateOf(-1L) }
    var lastSeekAt by remember { mutableLongStateOf(0L) }
    var seeked by remember(url, reload) { mutableStateOf(false) }
    // (resize mode, forced ratio): best fit, zoom, stretch, 16:9, 4:3
    val scales = remember {
        listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT to 0f, AspectRatioFrameLayout.RESIZE_MODE_ZOOM to 0f, AspectRatioFrameLayout.RESIZE_MODE_FILL to 0f,
            AspectRatioFrameLayout.RESIZE_MODE_FIT to (16f / 9f), AspectRatioFrameLayout.RESIZE_MODE_FIT to (4f / 3f))
    }
    var videoRatio by remember { mutableFloatStateOf(0f) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    val rates = remember { listOf(1f, 1.25f, 1.5f, 2f, 0.75f) }
    val root = remember { FocusRequester() }
    val playFocus = remember { FocusRequester() }
    // One ExoPlayer per video (released on exit); it decodes with the device's hardware codecs, so 4K stays smooth on TV boxes.
    val player = remember(url, reload) { buildPlayer(ctx, prefs.getInt("cache", 1500), level, noAudio) }
    val mp = remember(player) { Eng(player) }
    val layout = remember(player) {
        val sv = SurfaceView(ctx)
        val frame = AspectRatioFrameLayout(ctx).apply { addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)) }
        player.setVideoSurfaceView(sv)
        FrameLayout(ctx).apply { addView(frame, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)) }
    }
    val frame = remember(layout) { (layout.getChildAt(0)) as AspectRatioFrameLayout }

    DisposableEffect(player) {
        val u = if (url.startsWith("/")) Uri.fromFile(java.io.File(url)) else Uri.parse(url)
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> buffering = true
                    Player.STATE_READY -> {
                        buffering = false
                        if (!seeked) {
                            seeked = true
                            if (retryPos > 0L) { player.seekTo(retryPos); retryPos = 0L }   // automatic retry: carry on where it stopped
                            else if (startMs > 5000) ask = true
                        }
                    }
                    Player.STATE_ENDED -> { playing = false; ended = true }
                    else -> {}
                }
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { playing = playWhenReady && player.playbackState != Player.STATE_ENDED }
            override fun onVideoSizeChanged(v: VideoSize) { if (v.height > 0) videoRatio = v.width * v.pixelWidthHeightRatio / v.height }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onPlayerError(e: PlaybackException) {
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) { player.seekToDefaultPosition(); player.prepare() }
                else if (level < 2 && (e.errorCode in 4001..4005 || e.errorCode in 5001..5002)) {
                    // decoder / audio-output problem (typical for 4K): rebuild the player with safer settings and continue from the same spot
                    val audio = e.errorCode in 5001..5002 ||
                        ((e as? ExoPlaybackException)?.let { it.type == ExoPlaybackException.TYPE_RENDERER && player.getRendererType(it.rendererIndex) == C.TRACK_TYPE_AUDIO } == true)
                    if (audio) noAudio = true
                    retryPos = if (player.isCurrentMediaItemLive) 0L else player.currentPosition
                    level++; buffering = true; reload++
                }
                else { errInfo = e.errorCodeName; err = true; buffering = false }
            }
        }
        player.addListener(l)
        player.setMediaItem(MediaItem.fromUri(u))
        player.prepare()
        player.playWhenReady = true
        onDispose {
            try { onProgress(mp.time, mp.length) } catch (_: Exception) {}
            player.removeListener(l)
            player.release()
        }
    }
    // position / length are read twice a second (cheap) instead of on every frame
    LaunchedEffect(player) {
        while (true) {
            if (!held && drag == null) time = mp.time
            length = mp.length
            delay(500)
        }
    }
    LaunchedEffect(ended) {
        if (ended) { try { onProgress(length, length) } catch (_: Exception) {}; onEnded() }   // mark watched, then jump to the next episode
    }
    LaunchedEffect(ask) { if (ask) { mp.setTime(startMs); mp.pause() } }   // park on the saved frame until the viewer chooses
    LaunchedEffect(gestTick) { if (gest != null) { delay(800); gest = null } }
    DisposableEffect(Unit) {
        playerOn = true
        onDispose {
            playerOn = false
            activity?.window?.let { w -> val lp = w.attributes; lp.screenBrightness = -1f; w.attributes = lp }
        }
    }
    LaunchedEffect(aspect, videoRatio, frame) {
        val (mode, forced) = scales[aspect % scales.size]
        frame.resizeMode = mode
        frame.setAspectRatio(if (forced > 0f) forced else videoRatio)
    }
    LaunchedEffect(rate, player) { player.setPlaybackSpeed(rate) }
    LaunchedEffect(show, tick, playing) { if (show && playing) { delay(5000); show = false } }
    LaunchedEffect(show, ask) {
        delay(60)
        if (!ask) try { if (show) playFocus.requestFocus() else root.requestFocus() } catch (_: Exception) {}
    }
    LaunchedEffect(Unit) { while (true) { delay(10000); onProgress(time, length) } }

    fun seek(d: Long) { mp.setTime((mp.time + d).coerceIn(0L, if (length > 0) length else Long.MAX_VALUE)) }
    fun toggle() { if (mp.isPlaying) mp.pause() else mp.play() }
    /** Holding a key scrubs through the video, faster the longer it is held. */
    fun holdSeek(dir: Int, rc: Int) {
        held = true
        val now = System.currentTimeMillis()
        if (seekAcc < 0) seekAcc = mp.time
        if (now - lastSeekAt < 180) return
        lastSeekAt = now
        seekAcc = (seekAcc + dir * (10_000L + rc.coerceAtMost(30) * 1_000L)).coerceIn(0L, if (length > 0) length else Long.MAX_VALUE)
        mp.setTime(seekAcc)
        time = seekAcc
        gest = (if (dir > 0) "⏩  " else "⏪  ") + tfmt(seekAcc) + (if (length > 0) " / " + tfmt(length) else "")
        tick++
    }
    fun endHold() { held = false; seekAcc = -1L; gestTick++ }
    BackHandler { if (ask) onBack() else if (show) show = false else onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(root).focusable()
        .pointerInput(Unit) { detectTapGestures(onTap = { show = !show; tick++ }) }
        .pointerInput(Unit) {
            // swipe up/down: left half = brightness, right half = volume
            var left = true
            detectVerticalDragGestures(
                onDragStart = { left = it.x < size.width / 2f },
                onDragEnd = { gestTick++ }, onDragCancel = { gestTick++ },
                onVerticalDrag = { ch, dy ->
                    ch.consume()
                    if (!ask) {
                        val d = -dy / size.height * 1.4f
                        if (left) {
                            val w = activity?.window
                            val cur = w?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f
                            val nv = (cur + d).coerceIn(0.02f, 1f)
                            w?.let { val lp = it.attributes; lp.screenBrightness = nv; it.attributes = lp }
                            gest = "☀  " + (nv * 100).roundToInt() + "%"
                        } else {
                            vol = (vol + d).coerceIn(0f, 1f)
                            am.setStreamVolume(3, (vol * am.getStreamMaxVolume(3)).roundToInt(), 0)
                            gest = "🔊  " + (vol * 100).roundToInt() + "%"
                        }
                    }
                })
        }
        .onPreviewKeyEvent { ev ->
            val nk = ev.nativeKeyEvent
            if (ask) false
            else if (ev.type == KeyEventType.KeyUp && held) { endHold(); true }
            else if (ev.type != KeyEventType.KeyDown) false
            else {
                tick++
                when (ev.key) {
                    Key.MediaPlayPause, Key.Spacebar -> { toggle(); show = true; true }
                    Key.MediaPlay -> { if (!mp.isPlaying) mp.play(); show = true; true }
                    Key.MediaPause -> { if (mp.isPlaying) mp.pause(); show = true; true }
                    Key.MediaStop -> { onBack(); true }
                    Key.MediaNext -> { onEnded(); true }
                    Key.MediaPrevious -> { mp.setTime(0L); true }
                    Key.MediaFastForward -> if (nk.repeatCount > 0) { holdSeek(1, nk.repeatCount); true } else { seek(10000); show = true; true }
                    Key.MediaRewind -> if (nk.repeatCount > 0) { holdSeek(-1, nk.repeatCount); true } else { seek(-10000); show = true; true }
                    Key.MediaAudioTrack -> { dlg = 2; true }
                    Key.Info -> { show = !show; true }
                    // Left / Right: tap = ±10 s (controls hidden) or move focus (controls shown); HOLD = scrub, accelerating, in both cases
                    Key.DirectionLeft -> if (length > 0 && nk.repeatCount > 0) { holdSeek(-1, nk.repeatCount); true }
                        else if (!show) { seek(-10000); gest = "⏪  10s"; gestTick++; true } else false
                    Key.DirectionRight -> if (length > 0 && nk.repeatCount > 0) { holdSeek(1, nk.repeatCount); true }
                        else if (!show) { seek(10000); gest = "⏩  10s"; gestTick++; true } else false
                    Key.ChannelUp -> if (length > 0) { seek(60000); gest = "⏩  60s"; gestTick++; true } else false
                    Key.ChannelDown -> if (length > 0) { seek(-60000); gest = "⏪  60s"; gestTick++; true } else false
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.DirectionUp, Key.DirectionDown, Key.Menu -> if (!show) { show = true; true } else false
                    else -> false
                }
            }
        }) {
        AndroidView({ layout }, Modifier.fillMaxSize())
        if (buffering && !err) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Acc)
        if (err) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.playback_error), color = Err)
            if (errInfo.isNotEmpty()) Text(errInfo, color = Dim, fontSize = 11.sp)
            Fx({ err = false; buffering = true; level = 0; noAudio = false; reload += 1 }, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.retry)) }
        }
        AnimatedVisibility(show && !ask, Modifier.fillMaxSize(), enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xCC000000)))))
                RoundBtn(onBack, Modifier.align(Alignment.TopStart).padding(14.dp)) { Icon(Icons.Filled.ArrowBack, null, Modifier.size(18.dp)) }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.weight(1f))
                        RoundBtn({ dlg = 2 }) { Icon(Icons.Filled.VolumeUp, null, Modifier.size(16.dp)) }
                        RoundBtn({ aspect = (aspect + 1) % scales.size; prefs.edit().putInt("aspect", aspect).apply() }) { Icon(Icons.Filled.AspectRatio, null, Modifier.size(16.dp)) }
                        RoundBtn({ rate = rates[(rates.indexOf(rate) + 1) % rates.size] }) { Text(if (rate % 1f == 0f) rate.toInt().toString() + "×" else rate.toString() + "×", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        if (url.startsWith("http")) RoundBtn(onCast) { Icon(Icons.Filled.Cast, null, Modifier.size(16.dp)) }
                        if (Build.VERSION.SDK_INT >= 26 && activity != null) RoundBtn({ enterPip(activity) }) { Icon(Icons.Filled.PictureInPictureAlt, null, Modifier.size(16.dp)) }
                    }
                    if (length > 0) {
                        Slider(value = drag ?: (time.toFloat() / length).coerceIn(0f, 1f),
                            onValueChange = { drag = it; tick++ },
                            onValueChangeFinished = { drag?.let { mp.setTime((it * length).toLong()) }; drag = null },
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Acc, inactiveTrackColor = Color(0x55FFFFFF)),
                            modifier = Modifier.fillMaxWidth().height(20.dp))
                        Row(Modifier.fillMaxWidth()) {
                            Text(tfmt(time), fontSize = 11.sp)
                            Spacer(Modifier.weight(1f))
                            val remain = (length - time).coerceAtLeast(0)
                            val fmt = remember { android.text.format.DateFormat.getTimeFormat(ctx) }
                            Text(stringResource(R.string.ends_at) + " " + fmt.format(Date(System.currentTimeMillis() + remain)) + "   -" + tfmt(remain), fontSize = 11.sp)
                        }
                    } else Text("● " + stringResource(R.string.live_badge), color = Err, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Box(Modifier.fillMaxWidth()) {
                        if (length > 0) RoundBtn({ mp.setTime(0L) }, Modifier.align(Alignment.CenterStart)) { Text(stringResource(R.string.start_over), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        // series only: jump to the next episode (bottom right)
                        if (onNext != null) RoundBtn(onNext, Modifier.align(Alignment.CenterEnd)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(stringResource(R.string.next_episode), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Icon(Icons.Filled.SkipNext, null, Modifier.size(18.dp))
                            }
                        }
                        Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (length > 0) RoundBtn({ seek(-10000) }) { Text("-10", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            RoundBtn({ toggle() }, Modifier.focusRequester(playFocus)) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(22.dp)) }
                            if (length > 0) RoundBtn({ seek(10000) }) { Text("+10", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
        gest?.let { g ->
            Text(g, Modifier.align(Alignment.Center).clip(RoundedCornerShape(14.dp)).background(Color(0x99000000)).padding(horizontal = 18.dp, vertical = 10.dp),
                fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        if (ask) Box(Modifier.fillMaxSize().background(Color(0xB3000000)).pointerInput(Unit) { detectTapGestures { } }, Alignment.Center) {
            val rf = remember { FocusRequester() }
            LaunchedEffect(Unit) { rf.acquire(first = 120) }
            Column(Modifier.clip(RoundedCornerShape(22.dp)).background(Side).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2)
                Text(stringResource(R.string.resume_ask, tfmt(startMs)), color = Dim, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Fx({ ask = false; mp.play() }, Modifier.focusIf(true, rf), brush = Grad, pad = 12.dp) {
                        Text(stringResource(R.string.resume_from, tfmt(startMs)), fontWeight = FontWeight.Bold)
                    }
                    Fx({ ask = false; onRestart(); mp.setTime(0L); mp.play() }, pad = 12.dp) { Text(stringResource(R.string.start_over)) }
                }
            }
        }
        // clock: visible only together with the controls
        AnimatedVisibility(show && !ask, Modifier.align(Alignment.TopEnd).padding(18.dp), enter = fadeIn(), exit = fadeOut()) { ClockText(16.sp) }
    }

    if (dlg == 1 || dlg == 2) {
        val type = if (dlg == 1) C.TRACK_TYPE_TEXT else C.TRACK_TYPE_AUDIO
        val groups = tracks.groups.filter { it.type == type }
        Dialog(onDismissRequest = { dlg = 0 }) {
            Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(if (dlg == 1) R.string.subtitles else R.string.audio_track), fontWeight = FontWeight.Bold)
                if (groups.isEmpty()) Text(stringResource(R.string.no_tracks), color = Dim, fontSize = 12.sp)
                groups.forEach { g ->
                    for (i in 0 until g.length) {
                        if (!g.isTrackSupported(i)) continue
                        val f = g.getTrackFormat(i)
                        val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }?.let { java.util.Locale(it).displayLanguage }
                        val name = (f.label ?: lang ?: "Track ${i + 1}") + (if (f.channelCount > 0 && type == C.TRACK_TYPE_AUDIO) " · ${f.channelCount}ch" else "")
                        Fx({
                            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                            dlg = 0
                        }, Modifier.fillMaxWidth(), brush = if (g.isTrackSelected(i)) Grad else null, pad = 10.dp) {
                            Text(name, maxLines = 1, fontSize = 13.sp)
                        }
                    }
                }
                if (dlg == 1 && groups.isNotEmpty()) Fx({
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build(); dlg = 0
                }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.off), fontSize = 13.sp) }
            }
        }
    }
}
