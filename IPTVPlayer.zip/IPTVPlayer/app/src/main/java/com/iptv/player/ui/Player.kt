package com.iptv.player.ui

import android.app.Activity
import android.app.PictureInPictureParams
import android.net.Uri
import android.os.Build
import android.util.Rational
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.unit.Dp
import kotlin.math.roundToInt
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.iptv.player.R
import kotlinx.coroutines.delay
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Date

private val Glass = Brush.horizontalGradient(listOf(Color(0x44FFFFFF), Color(0x44FFFFFF)))

private fun tfmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val ss = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, ss) else "%d:%02d".format(m, ss)
}

@Composable private fun RoundBtn(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) =
    Fx(onClick, modifier, brush = Glass, pad = 9.dp, round = true, content = content)

/** LibVLC based player: plays almost every IPTV/VOD format, with custom TV-friendly controls. */
/** True while the player screen is shown (lets the activity switch to picture-in-picture on Home). */
@Volatile var playerOn = false

fun enterPip(a: Activity) {
    if (Build.VERSION.SDK_INT >= 26) try {
        a.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    } catch (_: Exception) { }
}

@Composable fun PlayerScreen(url: String, title: String, startMs: Long, onProgress: (Long, Long) -> Unit, onBack: () -> Unit, onCast: () -> Unit, onEnded: () -> Unit = {}, onRestart: () -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    var playing by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf(false) }
    var ended by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var time by remember { mutableLongStateOf(0L) }
    var length by remember { mutableLongStateOf(0L) }
    var show by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var rate by remember { mutableFloatStateOf(1f) }
    var aspect by remember { mutableIntStateOf(prefs.getInt("aspect", 0)) }
    var dlg by remember { mutableIntStateOf(0) }
    var ask by remember(url, reload) { mutableStateOf(false) }          // "resume or start over" prompt, shown inside the player
    var sleepEnd by remember { mutableLongStateOf(0L) }                  // sleep timer: epoch ms when playback stops (0 = off)
    var gest by remember { mutableStateOf<String?>(null) }              // brightness / volume indicator
    var gestTick by remember { mutableIntStateOf(0) }
    val activity = ctx as? Activity
    val am = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(3).toFloat() / am.getStreamMaxVolume(3).coerceAtLeast(1)) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var seeked by remember(url, reload) { mutableStateOf(false) }
    val scales = remember {
        listOf(MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FIT_SCREEN, MediaPlayer.ScaleType.SURFACE_FILL,
            MediaPlayer.ScaleType.SURFACE_16_9, MediaPlayer.ScaleType.SURFACE_4_3, MediaPlayer.ScaleType.SURFACE_ORIGINAL)
    }
    val rates = remember { listOf(1f, 1.25f, 1.5f, 2f, 0.75f) }
    val root = remember { FocusRequester() }
    val playFocus = remember { FocusRequester() }
    val vlc = remember(url, reload) { LibVLC(ctx, arrayListOf("--no-drop-late-frames", "--no-skip-frames")) }
    val mp = remember(vlc) { MediaPlayer(vlc) }
    val layout = remember(vlc) { VLCVideoLayout(ctx) }

    DisposableEffect(vlc) {
        mp.attachViews(layout, null, false, false)
        val media = Media(vlc, Uri.parse(url))
        media.setHWDecoderEnabled(prefs.getBoolean("hw", true), false)
        media.addOption(":network-caching=" + prefs.getInt("cache", 1500))
        mp.media = media
        media.release()
        mp.setEventListener { e ->
            when (e.type) {
                MediaPlayer.Event.Playing -> {
                    playing = true; buffering = false
                    if (!seeked) { seeked = true; if (startMs > 5000) ask = true }
                }
                MediaPlayer.Event.Paused -> playing = false
                MediaPlayer.Event.Buffering -> buffering = e.buffering < 100f
                MediaPlayer.Event.TimeChanged -> time = e.timeChanged
                MediaPlayer.Event.LengthChanged -> length = e.lengthChanged
                MediaPlayer.Event.EncounteredError -> { err = true; buffering = false }
                MediaPlayer.Event.EndReached -> { playing = false; ended = true }
            }
        }
        mp.play()
        onDispose {
            try { onProgress(mp.time, mp.length) } catch (_: Exception) {}
            mp.setEventListener(null)
            mp.stop(); mp.detachViews(); mp.release(); vlc.release()
        }
    }
    LaunchedEffect(ended) {
        if (ended) { try { onProgress(length, length) } catch (_: Exception) {}; onEnded() }   // mark watched, then jump to the next episode
    }
    LaunchedEffect(ask) { if (ask) { mp.setTime(startMs); mp.pause() } }   // park on the saved frame until the viewer chooses
    LaunchedEffect(sleepEnd) {
        if (sleepEnd > 0L) { val left = sleepEnd - System.currentTimeMillis(); if (left > 0) delay(left); onBack() }
    }
    LaunchedEffect(gestTick) { if (gest != null) { delay(800); gest = null } }
    DisposableEffect(Unit) {
        playerOn = true
        onDispose {
            playerOn = false
            activity?.window?.let { w -> val lp = w.attributes; lp.screenBrightness = -1f; w.attributes = lp }
        }
    }
    LaunchedEffect(aspect, vlc) { mp.setVideoScale(scales[aspect % scales.size]) }
    LaunchedEffect(rate, vlc) { mp.setRate(rate) }
    LaunchedEffect(show, tick, playing) { if (show && playing) { delay(5000); show = false } }
    LaunchedEffect(show, ask) {
        delay(60)
        if (!ask) try { if (show) playFocus.requestFocus() else root.requestFocus() } catch (_: Exception) {}
    }
    LaunchedEffect(Unit) { while (true) { delay(10000); onProgress(time, length) } }

    fun seek(d: Long) { mp.setTime((mp.time + d).coerceIn(0L, if (length > 0) length else Long.MAX_VALUE)) }
    fun toggle() { if (mp.isPlaying) mp.pause() else mp.play() }
    BackHandler { if (ask) onBack() else if (show) show = false else onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(root).focusable()
        .pointerInput(Unit) { detectTapGestures(onTap = { show = !show; tick++ }) }
        .pointerInput(Unit) {
            // swipe up/down: left half = brightness, right half = volume
            var left = true
            detectVerticalDragGestures(
                onDragStart = { left = it.x < size.width / 2f },
                onDragEnd = { gestTick++ }, onDragCancel = { gestTick++ },
                onVerticalDrag = { ch, dy ->
                    ch.consume()
                    if (!ask) {
                        val d = -dy / size.height * 1.4f
                        if (left) {
                            val w = activity?.window
                            val cur = w?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f
                            val nv = (cur + d).coerceIn(0.02f, 1f)
                            w?.let { val lp = it.attributes; lp.screenBrightness = nv; it.attributes = lp }
                            gest = "☀  " + (nv * 100).roundToInt() + "%"
                        } else {
                            vol = (vol + d).coerceIn(0f, 1f)
                            am.setStreamVolume(3, (vol * am.getStreamMaxVolume(3)).roundToInt(), 0)
                            gest = "🔊  " + (vol * 100).roundToInt() + "%"
                        }
                    }
                })
        }
        .onPreviewKeyEvent { ev ->
            if (ask || ev.type != KeyEventType.KeyDown) false
            else {
                tick++
                when (ev.key) {
                    Key.MediaPlayPause, Key.Spacebar -> { toggle(); show = true; true }
                    Key.MediaFastForward -> { seek(10000); show = true; true }
                    Key.MediaRewind -> { seek(-10000); show = true; true }
                    Key.DirectionLeft -> if (!show) { seek(-10000); show = true; true } else false
                    Key.DirectionRight -> if (!show) { seek(10000); show = true; true } else false
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.DirectionUp, Key.DirectionDown, Key.Menu -> if (!show) { show = true; true } else false
                    else -> false
                }
            }
        }) {
        AndroidView({ layout }, Modifier.fillMaxSize())
        if (buffering && !err) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Acc)
        if (err) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.playback_error), color = Err)
            Fx({ err = false; buffering = true; reload += 1 }, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.retry)) }
        }
        AnimatedVisibility(show && !ask, Modifier.fillMaxSize(), enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xCC000000)))))
                RoundBtn(onBack, Modifier.align(Alignment.TopStart).padding(14.dp)) { Icon(Icons.Filled.ArrowBack, null, Modifier.size(18.dp)) }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.weight(1f))
                        RoundBtn({ dlg = 1 }) { Icon(Icons.Filled.ClosedCaption, null, Modifier.size(16.dp)) }
                        RoundBtn({ dlg = 2 }) { Icon(Icons.Filled.VolumeUp, null, Modifier.size(16.dp)) }
                        RoundBtn({ aspect = (aspect + 1) % scales.size; prefs.edit().putInt("aspect", aspect).apply() }) { Icon(Icons.Filled.AspectRatio, null, Modifier.size(16.dp)) }
                        RoundBtn({ rate = rates[(rates.indexOf(rate) + 1) % rates.size] }) { Text(if (rate % 1f == 0f) rate.toInt().toString() + "×" else rate.toString() + "×", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        if (url.startsWith("http")) RoundBtn(onCast) { Icon(Icons.Filled.Cast, null, Modifier.size(16.dp)) }
                        if (sleepEnd > 0L) Text("⏲ " + android.text.format.DateFormat.getTimeFormat(ctx).format(Date(sleepEnd)), fontSize = 11.sp, color = Acc)
                        RoundBtn({ dlg = 4 }) { Icon(Icons.Filled.Timer, null, Modifier.size(16.dp)) }
                        if (Build.VERSION.SDK_INT >= 26 && activity != null) RoundBtn({ enterPip(activity) }) { Icon(Icons.Filled.PictureInPictureAlt, null, Modifier.size(16.dp)) }
                        RoundBtn({ dlg = 3 }) { Icon(Icons.Filled.Info, null, Modifier.size(16.dp)) }
                    }
                    if (length > 0) {
                        Slider(value = drag ?: (time.toFloat() / length).coerceIn(0f, 1f),
                            onValueChange = { drag = it; tick++ },
                            onValueChangeFinished = { drag?.let { mp.setTime((it * length).toLong()) }; drag = null },
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Acc, inactiveTrackColor = Color(0x55FFFFFF)),
                            modifier = Modifier.fillMaxWidth().height(20.dp))
                        Row(Modifier.fillMaxWidth()) {
                            Text(tfmt(time), fontSize = 11.sp)
                            Spacer(Modifier.weight(1f))
                            val remain = (length - time).coerceAtLeast(0)
                            val fmt = remember { android.text.format.DateFormat.getTimeFormat(ctx) }
                            Text(stringResource(R.string.ends_at) + " " + fmt.format(Date(System.currentTimeMillis() + remain)) + "   -" + tfmt(remain), fontSize = 11.sp)
                        }
                    } else Text("● " + stringResource(R.string.live_badge), color = Err, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Box(Modifier.fillMaxWidth()) {
                        if (length > 0) RoundBtn({ mp.setTime(0L) }, Modifier.align(Alignment.CenterStart)) { Text(stringResource(R.string.start_over), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (length > 0) RoundBtn({ seek(-10000) }) { Text("-10", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            RoundBtn({ toggle() }, Modifier.focusRequester(playFocus)) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(22.dp)) }
                            if (length > 0) RoundBtn({ seek(10000) }) { Text("+10", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
        gest?.let { g ->
            Text(g, Modifier.align(Alignment.Center).clip(RoundedCornerShape(14.dp)).background(Color(0x99000000)).padding(horizontal = 18.dp, vertical = 10.dp),
                fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        if (ask) Box(Modifier.fillMaxSize().background(Color(0xB3000000)).pointerInput(Unit) { detectTapGestures { } }, Alignment.Center) {
            val rf = remember { FocusRequester() }
            LaunchedEffect(Unit) { delay(120); try { rf.requestFocus() } catch (_: Exception) {} }
            Column(Modifier.clip(RoundedCornerShape(22.dp)).background(Side).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2)
                Text(stringResource(R.string.resume_ask, tfmt(startMs)), color = Dim, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Fx({ ask = false; mp.play() }, Modifier.focusRequester(rf), brush = Grad, pad = 12.dp) {
                        Text(stringResource(R.string.resume_from, tfmt(startMs)), fontWeight = FontWeight.Bold)
                    }
                    Fx({ ask = false; onRestart(); mp.setTime(0L); mp.play() }, pad = 12.dp) { Text(stringResource(R.string.start_over)) }
                }
            }
        }
        // clock: visible only together with the controls
        AnimatedVisibility(show && !ask, Modifier.align(Alignment.TopEnd).padding(18.dp), enter = fadeIn(), exit = fadeOut()) { ClockText(16.sp) }
    }

    if (dlg == 1 || dlg == 2) {
        val tr: Array<MediaPlayer.TrackDescription> = (if (dlg == 1) mp.spuTracks else mp.audioTracks) ?: emptyArray()
        val curId = if (dlg == 1) mp.spuTrack else mp.audioTrack
        Dialog(onDismissRequest = { dlg = 0 }) {
            Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(if (dlg == 1) R.string.subtitles else R.string.audio_track), fontWeight = FontWeight.Bold)
                if (tr.isEmpty()) Text(stringResource(R.string.no_tracks), color = Dim, fontSize = 12.sp)
                tr.forEach { t ->
                    Fx({ if (dlg == 1) mp.setSpuTrack(t.id) else mp.setAudioTrack(t.id); dlg = 0 }, Modifier.fillMaxWidth(), brush = if (t.id == curId) Grad else null, pad = 10.dp) {
                        Text(t.name, maxLines = 1, fontSize = 13.sp)
                    }
                }
            }
        }
    }
    if (dlg == 4) Dialog(onDismissRequest = { dlg = 0 }) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.sleep_timer), fontWeight = FontWeight.Bold)
            if (sleepEnd > 0L) Text(stringResource(R.string.sleep_at, android.text.format.DateFormat.getTimeFormat(ctx).format(Date(sleepEnd))), color = Dim, fontSize = 12.sp)
            listOf(0, 15, 30, 45, 60, 90).forEach { m ->
                Fx({ sleepEnd = if (m == 0) 0L else System.currentTimeMillis() + m * 60000L; dlg = 0 }, Modifier.fillMaxWidth(),
                    brush = if (m == 0 && sleepEnd == 0L) Grad else null, pad = 10.dp) {
                    Text(if (m == 0) stringResource(R.string.off) else stringResource(R.string.minutes_n, m), fontSize = 13.sp)
                }
            }
        }
    }
    if (dlg == 3) Dialog(onDismissRequest = { dlg = 0 }) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(tfmt(time) + " / " + (if (length > 0) tfmt(length) else "LIVE"), color = Dim, fontSize = 12.sp)
        }
    }
}
