package com.iptv.player.ui

import android.app.Activity
import kotlinx.coroutines.delay
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.foundation.text.BasicTextField
import android.widget.Toast
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Mem { val m = HashMap<String, Cata>(); val live = HashMap<String, LiveData>() }

@Composable fun Chip(t: String, on: Boolean, click: () -> Unit) =
    Fx(click, brush = if (on) Grad else null, pad = 8.dp) { Text(t, fontSize = 12.sp, maxLines = 1) }

data class CatItem(val id: String, val label: String, val count: Int = -1)

private val sortLabels = listOf(R.string.sort_default, R.string.sort_az, R.string.sort_za, R.string.sort_new, R.string.sort_rating)

@Composable fun CatRow(t: String, count: Int, on: Boolean, fr: FocusRequester?, click: () -> Unit) =
    Fx(click, if (fr != null) Modifier.fillMaxWidth().focusRequester(fr) else Modifier.fillMaxWidth(), brush = if (on) Grad else null, flat = !on, pad = 7.dp) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(t, fontSize = 12.sp, maxLines = 2, modifier = Modifier.weight(1f))
            if (count >= 0) Text(count.toString(), fontSize = 10.sp, color = if (on) Color.White else Dim)
        }
    }

/** Compact search box. */
@Composable fun SmallSearch(q: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    BasicTextField(q, onChange, modifier = modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(.08f)).padding(horizontal = 12.dp),
        singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 13.sp), cursorBrush = SolidColor(Acc),
        decorationBox = { inner ->
            Row(Modifier.fillMaxHeight(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Filled.Search, null, Modifier.size(16.dp), tint = Dim)
                Box(Modifier.weight(1f), Alignment.CenterStart) {
                    if (q.isEmpty()) Text(hint, color = Dim, fontSize = 13.sp, maxLines = 1)
                    inner()
                }
            }
        })
}

/** Full-screen page: back button + vertical category list (with counts) on the left, content on the right. */
@Composable fun TwoPane(title: String, cats: List<CatItem>, cat: String, onCat: (String) -> Unit, onBack: () -> Unit,
                        allCount: Int = -1, showAll: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(300); try { fr.requestFocus() } catch (_: Exception) {} }
    Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.width(160.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BackBtn(onBack)
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (showAll) item { CatRow(stringResource(R.string.cat_all), allCount, cat.isEmpty(), if (cat.isEmpty()) fr else null) { onCat("") } }
                items(cats) { c -> CatRow(c.label, c.count, cat == c.id, if (cat == c.id) fr else null) { onCat(c.id) } }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable fun Catalog(kind: String, sub: Sub?, favIds: Set<String>, recents: List<Recent>, onOpen: (Vod) -> Unit, onBack: () -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val key = "${sub?.id}|$kind"
    var data by remember(key) { mutableStateOf(Mem.m[key]) }
    var err by remember(key) { mutableStateOf<String?>(null) }
    var cat by remember(key) { mutableStateOf(prefs.getString("cat_$key", "") ?: "") }
    var q by remember(key) { mutableStateOf("") }
    var sort by remember(kind) { mutableIntStateOf(prefs.getInt("sort_$kind", 0)) }
    var view by remember(kind) { mutableIntStateOf(prefs.getInt("view_$kind", 0)) }
    LaunchedEffect(key) {
        if (sub == null || sub.type != "xtream" || data != null) return@LaunchedEffect
        try {
            val d = withContext(Dispatchers.IO) {
                val p = Secure.get(ctx, sub.id)
                if (kind == "movie") Xt.movies(sub.url, sub.user, p) else Xt.seriesList(sub.url, sub.user, p)
            }
            Mem.m[key] = d; data = d
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    val recentVods = remember(recents) { recents.filter { it.kind == kind }.map { Vod(it.itemId, it.name, it.cover, "", it.url) } }
    val counts = remember(data) { data?.items.orEmpty().groupingBy { it.cat }.eachCount() }
    val shown = remember(data, cat, q, sort, recentVods) {
        val base = if (cat == "__recent__") recentVods else data?.items.orEmpty().filter { cat.isEmpty() || it.cat == cat }
        val f = if (q.isBlank()) base else base.filter { it.name.contains(q, true) }
        when (sort) {
            1 -> f.sortedBy { it.name.lowercase() }
            2 -> f.sortedByDescending { it.name.lowercase() }
            3 -> f.sortedByDescending { it.added }
            4 -> f.sortedByDescending { it.rating.toFloatOrNull() ?: 0f }
            else -> f
        }
    }
    val cats = remember(data, counts, recentVods) {
        listOf(CatItem("__recent__", ctx.getString(R.string.recent_cat), recentVods.size)) +
            data?.cats?.entries?.map { CatItem(it.key, it.value, counts[it.key] ?: 0) }.orEmpty()
    }
    TwoPane(stringResource(if (kind == "movie") R.string.movies else R.string.series), cats, cat,
        { cat = it; prefs.edit().putString("cat_$key", it).apply() }, onBack, allCount = data?.items?.size ?: -1) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallSearch(q, { q = it }, stringResource(R.string.search_generic), Modifier.width(170.dp))
            Spacer(Modifier.weight(1f))
            Fx({ sort = (sort + 1) % 5; prefs.edit().putInt("sort_$kind", sort).apply() }, pad = 8.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Filled.Sort, null, Modifier.size(16.dp)); Text(stringResource(sortLabels[sort]), fontSize = 11.sp, maxLines = 1)
                }
            }
            Fx({ view = (view + 1) % 3; prefs.edit().putInt("view_$kind", view).apply() }, pad = 8.dp) {
                Icon(when (view) { 0 -> Icons.Filled.GridView; 1 -> Icons.Filled.ViewModule; else -> Icons.Filled.ViewList }, null, Modifier.size(18.dp))
            }
        }
        when {
            sub == null -> { Text(stringResource(R.string.no_active), color = Dim); Fx(onAdd, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.add_sub)) } }
            sub.type != "xtream" -> Text(stringResource(R.string.xtream_only), color = Dim)
            err != null -> Text(err!!, color = Err)
            data == null -> CircularProgressIndicator(color = Acc)
            view == 2 -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(shown) { v ->
                    Fx({ onOpen(v) }, Modifier.fillMaxWidth(), pad = 6.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AsyncImage(v.cover, null, Modifier.height(52.dp).aspectRatio(0.68f).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Crop)
                            Column(Modifier.weight(1f)) {
                                Text(v.name, maxLines = 2, fontSize = 13.sp)
                                ImdbBadge(v.name, kind == "series")
                            }
                            if (v.id in favIds) Icon(Icons.Filled.Favorite, null, Modifier.size(16.dp), tint = Acc)
                        }
                    }
                }
            }
            else -> LazyVerticalGrid(GridCells.Adaptive(if (view == 0) 104.dp else 140.dp), Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                gridItems(shown) { v ->
                    Fx({ onOpen(v) }, pad = 4.dp) {
                        Column {
                            Box {
                                AsyncImage(v.cover, null, Modifier.fillMaxWidth().aspectRatio(0.68f).clip(RoundedCornerShape(12.dp)).background(Side), contentScale = ContentScale.Crop)
                                ImdbBadge(v.name, kind == "series", Modifier.align(Alignment.BottomStart).padding(5.dp))
                            }
                            Text(v.name, maxLines = 1, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                        if (v.id in favIds) Icon(Icons.Filled.Favorite, null, tint = Acc, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable fun Initials(name: String) = Box(Modifier.fillMaxSize(), Alignment.Center) {
    Text(name.trim().take(2).uppercase(), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Acc)
}

@Composable fun Live(sub: Sub?, favIds: Set<String>, onPlay: (Ch) -> Unit, onFav: (Ch) -> Unit, onBack: () -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val key = "${sub?.id}|live"
    var data by remember(key) { mutableStateOf(Mem.live[key]) }
    var err by remember(key) { mutableStateOf<String?>(null) }
    var cat by remember(key) { mutableStateOf(prefs.getString("cat_$key", "") ?: "") }
    var q by remember(key) { mutableStateOf("") }
    var view by remember { mutableIntStateOf(prefs.getInt("view_live", 0)) }
    LaunchedEffect(key) {
        if (sub == null || data != null) return@LaunchedEffect
        try {
            val d = withContext(Dispatchers.IO) {
                when (sub.type) {
                    "xtream" -> Xt.live(sub.url, sub.user, Secure.get(ctx, sub.id))
                    "m3u" -> Xt.m3uLive(ctx, sub.url)
                    "single" -> LiveData(emptyMap(), listOf(Ch(sub.name, sub.url)))
                    else -> throw IllegalStateException(ctx.getString(R.string.stalker_later))
                }
            }
            Mem.live[key] = d; data = d
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    val counts = remember(data) { data?.items.orEmpty().groupingBy { it.cat }.eachCount() }
    val shown = remember(data, cat, q) { data?.items.orEmpty().filter { (cat.isEmpty() || it.cat == cat) && it.name.contains(q, true) } }
    val cats = remember(data, counts) { data?.cats?.entries?.map { CatItem(it.key, it.value, counts[it.key] ?: 0) }.orEmpty() }
    TwoPane(stringResource(R.string.live), cats, cat, { cat = it; prefs.edit().putString("cat_$key", it).apply() }, onBack, allCount = data?.items?.size ?: -1) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallSearch(q, { q = it }, stringResource(R.string.search), Modifier.width(170.dp))
            Spacer(Modifier.weight(1f))
            Fx({ view = (view + 1) % 2; prefs.edit().putInt("view_live", view).apply() }, pad = 8.dp) {
                Icon(if (view == 0) Icons.Filled.GridView else Icons.Filled.ViewList, null, Modifier.size(18.dp))
            }
        }
        when {
            sub == null -> { Text(stringResource(R.string.no_active), color = Dim); Fx(onAdd, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.add_sub)) } }
            err != null -> Text(err!!, color = Err)
            data == null -> CircularProgressIndicator(color = Acc)
            view == 1 -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(shown) { c ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Fx({ onPlay(c) }, Modifier.weight(1f), pad = 8.dp) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Color.White.copy(.06f))) {
                                    if (c.logo.isNotBlank()) SubcomposeAsyncImage(c.logo, null, Modifier.fillMaxSize().padding(3.dp), contentScale = ContentScale.Fit,
                                        loading = { Initials(c.name) }, error = { Initials(c.name) })
                                    else Initials(c.name)
                                }
                                Text(c.name, maxLines = 1)
                            }
                        }
                        Fx({ onFav(c) }, pad = 10.dp) { Icon(if (c.url in favIds) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, Modifier.size(18.dp), tint = Acc) }
                    }
                }
            }
            else -> LazyVerticalGrid(GridCells.Adaptive(104.dp), Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                gridItems(shown) { c ->
                    Box {
                        Fx({ onPlay(c) }, Modifier.fillMaxWidth(), pad = 6.dp) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(Modifier.fillMaxWidth().aspectRatio(1.25f).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(.06f)), Alignment.Center) {
                                    if (c.logo.isNotBlank()) SubcomposeAsyncImage(c.logo, null, Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit,
                                        loading = { Initials(c.name) }, error = { Initials(c.name) })
                                    else Initials(c.name)
                                }
                                Text(c.name, maxLines = 1, fontSize = 11.sp)
                            }
                        }
                        Fx({ onFav(c) }, Modifier.align(Alignment.TopEnd), pad = 5.dp) {
                            Icon(if (c.url in favIds) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, Modifier.size(14.dp), tint = Acc)
                        }
                    }
                }
            }
        }
    }
}

@Composable fun MovieDialog(v: Vod, fav: Boolean, onPlay: () -> Unit, onFav: () -> Unit, onDownload: () -> Unit,
                            onShare: () -> Unit, onCast: () -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Row(Modifier.fillMaxWidth(0.82f).clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color(0xFF1B1F42), Side))).padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            AsyncImage(v.cover, null, Modifier.width(110.dp).aspectRatio(0.68f).clip(RoundedCornerShape(14.dp)).background(Bg), contentScale = ContentScale.Crop)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(v.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                ImdbBadge(v.name, false)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Fx(onPlay, brush = Grad, pad = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text(stringResource(R.string.play), fontWeight = FontWeight.Bold) }
                    }
                    Fx(onDownload, pad = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Download, null); Spacer(Modifier.width(4.dp)); Text(stringResource(R.string.download), fontSize = 13.sp) }
                    }
                    Fx(onShare, pad = 10.dp) { Icon(Icons.Filled.Share, stringResource(R.string.share)) }
                    Fx(onCast, pad = 10.dp) { Icon(Icons.Filled.Cast, null) }
                    Fx(onFav, pad = 10.dp) { Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Acc) }
                }
            }
        }
    }
}

@Composable fun SeriesDetail(v: Vod, sub: Sub, fav: Boolean, onFav: () -> Unit, onPlay: (Ep) -> Unit, onDownload: (List<Ep>) -> Unit,
                             onShare: () -> Unit, onCast: (Ep) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var eps by remember(v.id) { mutableStateOf<List<Ep>?>(null) }
    var err by remember(v.id) { mutableStateOf<String?>(null) }
    var season by remember(v.id) { mutableIntStateOf(1) }
    var plot by remember(v.id) { mutableStateOf("") }
    var menu by remember(v.id) { mutableIntStateOf(0) }
    var selecting by remember(v.id) { mutableStateOf(false) }
    val picked = remember(v.id) { mutableStateListOf<String>() }
    val all = eps.orEmpty()
    val seasons = all.map { it.season }.distinct()
    BackHandler { if (selecting) { selecting = false; picked.clear() } else onBack() }
    LaunchedEffect(v.id) {
        try {
            val r = withContext(Dispatchers.IO) { Xt.seriesInfo(sub.url, sub.user, Secure.get(ctx, sub.id), v.id) }
            val l = r.eps
            plot = r.plot; eps = l; season = l.firstOrNull()?.season ?: 1
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Header: back, poster, then title + description + action buttons side by side
        Row(Modifier.fillMaxWidth().height(124.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
            BackBtn(onBack)
            Box {
                AsyncImage(v.cover, null, Modifier.height(124.dp).aspectRatio(0.68f).clip(RoundedCornerShape(14.dp)).background(Side), contentScale = ContentScale.Crop)
                ImdbBadge(v.name, true, Modifier.align(Alignment.BottomStart).padding(4.dp))
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(v.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                if (plot.isNotBlank()) Text(plot, fontSize = 12.sp, color = Dim, maxLines = 3, lineHeight = 16.sp)
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Fx(onFav, pad = 8.dp) { Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, Modifier.size(20.dp), tint = Acc) }
                    Fx({ if (eps != null) menu = 1 }, pad = 8.dp) { Icon(Icons.Filled.Download, stringResource(R.string.download), Modifier.size(20.dp)) }
                    Fx(onShare, pad = 8.dp) { Icon(Icons.Filled.Share, stringResource(R.string.share), Modifier.size(20.dp)) }
                }
            }
        }
        when {
            err != null -> Text(err!!, color = Err)
            eps == null -> Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) { CircularProgressIndicator(color = Acc) }
            else -> {
                // Seasons row, then the episodes of the chosen season underneath
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(seasons) { s -> Chip(stringResource(R.string.season) + " " + s, s == season) { season = s } }
                }
                if (selecting) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Fx({ if (picked.isNotEmpty()) { onDownload(all.filter { it.id in picked }); selecting = false; picked.clear() } }, brush = Grad, pad = 8.dp) {
                        Text(stringResource(R.string.dl_start) + " (" + picked.size + ")", fontSize = 12.sp)
                    }
                    Fx({
                        val ids = all.filter { it.season == season }.map { it.id }
                        if (picked.containsAll(ids)) { picked.removeAll(ids) } else { ids.forEach { if (it !in picked) picked.add(it) } }
                    }, pad = 8.dp) { Text(stringResource(R.string.dl_all_season), fontSize = 12.sp) }
                    Fx({ selecting = false; picked.clear() }, pad = 8.dp) { Text(stringResource(R.string.cancel), fontSize = 12.sp) }
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(all.filter { it.season == season }) { e ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Fx({
                                if (!selecting) onPlay(e)
                                else if (e.id in picked) { picked.remove(e.id) } else { picked.add(e.id) }
                            }, Modifier.weight(1f), pad = 10.dp) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (selecting) Checkbox(checked = e.id in picked, onCheckedChange = null, colors = CheckboxDefaults.colors(checkedColor = Acc))
                                    else Icon(Icons.Filled.PlayArrow, null, tint = Acc)
                                    Text("${e.num}. ${e.title}", maxLines = 1)
                                }
                            }
                            if (!selecting) Fx({ onCast(e) }, pad = 10.dp) { Icon(Icons.Filled.Cast, null, Modifier.size(18.dp)) }
                        }
                    }
                }
            }
        }
    }
    if (menu != 0) Dialog(onDismissRequest = { menu = 0 }) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp).heightIn(max = 280.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (menu == 1) {
                Text(stringResource(R.string.download), fontWeight = FontWeight.Bold)
                Fx({ onDownload(all); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_full)) }
                if (seasons.size > 1) Fx({ menu = 2 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_season)) }
                Fx({ selecting = true; picked.clear(); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_episodes)) }
            } else {
                Text(stringResource(R.string.dl_pick_season), fontWeight = FontWeight.Bold)
                seasons.forEach { s ->
                    Fx({ onDownload(all.filter { it.season == s }); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.season) + " " + s) }
                }
            }
        }
    }
}

@Composable fun Favs(sub: Sub?, store: StoreDao, onPlay: (Fav) -> Unit, onSeries: (Fav) -> Unit, onRemove: (Fav) -> Unit, onBack: () -> Unit) {
    var kind by remember { mutableStateOf("live") }
    val list by remember(sub?.id, kind) { store.list(sub?.id ?: -1L, kind) }.collectAsState(initial = emptyList<Fav>())
    TwoPane(stringResource(R.string.fav),
        listOf(CatItem("live", stringResource(R.string.live)), CatItem("movie", stringResource(R.string.movies)), CatItem("series", stringResource(R.string.series))),
        kind, { kind = it }, onBack, showAll = false) {
        if (list.isEmpty()) Text(stringResource(R.string.fav_empty), color = Dim)
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { f ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Fx({ if (f.kind == "series") onSeries(f) else onPlay(f) }, Modifier.weight(1f), pad = 8.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (f.cover.isNotBlank()) AsyncImage(f.cover, null, Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Crop)
                            else Icon(Icons.Filled.PlayArrow, null, Modifier.size(36.dp), tint = Acc)
                            Text(f.name, maxLines = 1)
                        }
                    }
                    Fx({ onRemove(f) }, pad = 10.dp) { Icon(Icons.Filled.Favorite, null, tint = Acc) }
                }
            }
        }
    }
}

@Composable fun DlSettings() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    var dir by remember { mutableStateOf(prefs.getString("dl_dir", null)) }
    var browse by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.dl_path), color = Dim, fontSize = 13.sp)
        Text(dir ?: stringResource(R.string.dl_path_default), fontSize = 12.sp, maxLines = 2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Fx({
                if (StoragePerm.has(ctx)) browse = true
                else { (ctx as? Activity)?.let { StoragePerm.request(it) }; Toast.makeText(ctx, ctx.getString(R.string.perm_text), Toast.LENGTH_LONG).show() }
            }, pad = 8.dp) { Text(stringResource(R.string.dl_choose_folder), fontSize = 13.sp) }
            if (dir != null) Fx({ prefs.edit().remove("dl_dir").apply(); dir = null }, pad = 8.dp) { Text(stringResource(R.string.dl_reset), fontSize = 13.sp) }
        }
        Text(stringResource(R.string.dl_limit), color = Dim, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("1", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.dl_limit_note), color = Dim, fontSize = 11.sp)
        }
    }
    if (browse) Browser(true, emptyList(), { f -> prefs.edit().putString("dl_dir", f.path).apply(); dir = f.path; browse = false }) { browse = false }
}

/** [- N Day(s) +] stepper stored in preferences; 0 = off. */
@Composable fun DaysStepper(prefs: android.content.SharedPreferences, key: String, def: Int) {
    var n by remember { mutableIntStateOf(prefs.getInt(key, def)) }
    fun set(v: Int) { n = v.coerceIn(0, 30); prefs.edit().putInt(key, n).apply() }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Fx({ set(n - 1) }, pad = 8.dp) { Text("−", fontSize = 16.sp) }
        Text(if (n == 0) stringResource(R.string.off) else n.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Fx({ set(n + 1) }, pad = 8.dp) { Text("+", fontSize = 16.sp) }
        if (n > 0) Text(stringResource(R.string.days), color = Dim, fontSize = 13.sp)
    }
}

@Composable fun Settings(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    var tab by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf<String?>(null) }
    val lang = prefs.getString("lang", "") ?: ""
    var resume by remember { mutableStateOf(prefs.getBoolean("resume", true)) }
    var hw by remember { mutableStateOf(prefs.getBoolean("hw", true)) }
    var cache by remember { mutableIntStateOf(prefs.getInt("cache", 1500)) }
    fun setLang(l: String) { prefs.edit().putString("lang", l).apply(); (ctx as? Activity)?.recreate() }
    val tabs = listOf(Triple(Icons.Filled.Tune, R.string.set_general, 0), Triple(Icons.Filled.Download, R.string.set_downloads, 1),
        Triple(Icons.Filled.Palette, R.string.set_appearance, 2), Triple(Icons.Filled.PlayCircle, R.string.set_player, 3))

    @Composable fun Opt(title: String, content: @Composable () -> Unit) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(title, color = Dim, fontSize = 13.sp); content() }
    }

    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.width(150.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BackBtn(onBack); Text(stringResource(R.string.settings), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            tabs.forEach { (ic, l, i) ->
                Fx({ tab = i }, Modifier.fillMaxWidth(), brush = if (tab == i) Grad else null, flat = tab != i, pad = 10.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(ic, null, Modifier.size(18.dp)); Text(stringResource(l), fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(20.dp)).background(Color.White.copy(.05f)).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (tab) {
                0 -> {
                    Opt(stringResource(R.string.display_mode)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip(stringResource(R.string.mode_tv), !Ui.phone) { Ui.applyMode(prefs, false) }
                            Chip(stringResource(R.string.mode_phone), Ui.phone) { Ui.applyMode(prefs, true) }
                        }
                        Text(stringResource(R.string.mode_hint), color = Dim, fontSize = 11.sp)
                    }
                    Opt(stringResource(R.string.lang)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("العربية", lang == "ar") { setLang("ar") }
                            Chip("English", lang == "en") { setLang("en") }
                        }
                    }
                    Opt(stringResource(R.string.perm_title)) {
                        Text(stringResource(if (StoragePerm.has(ctx)) R.string.perm_ok else R.string.perm_no), fontSize = 12.sp, color = if (StoragePerm.has(ctx)) Ok else Err)
                        Fx({ (ctx as? Activity)?.let { StoragePerm.request(it) } }, pad = 8.dp) { Text(stringResource(R.string.perm_allow), fontSize = 13.sp) }
                    }
                    Fx({ ctx.cacheDir.deleteRecursively(); Mem.m.clear(); Mem.live.clear(); msg = ctx.getString(R.string.cache_cleared) }, pad = 10.dp) { Text(stringResource(R.string.clear_cache)) }
                    msg?.let { Text(it, color = Ok, fontSize = 12.sp) }
                    Text(stringResource(R.string.parental_soon), color = Dim, fontSize = 12.sp)
                    Text(stringResource(R.string.app_version), color = Dim, fontSize = 12.sp)
                }
                1 -> DlSettings()
                2 -> {
                    Opt(stringResource(R.string.font_size)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0.85f to R.string.font_small, 1f to R.string.font_normal, 1.15f to R.string.font_large, 1.3f to R.string.font_xl).forEach { (v, r) ->
                                Chip(stringResource(r), Ui.fontScale == v) { Ui.fontScale = v; prefs.edit().putFloat("font_scale", v).apply() }
                            }
                        }
                    }
                    Opt(stringResource(R.string.bar_size)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(44 to R.string.bar_small, 52 to R.string.bar_medium, 62 to R.string.bar_large).forEach { (v, r) ->
                                Chip(stringResource(r), Ui.barH == v) { Ui.barH = v; prefs.edit().putInt("bar_h", v).apply() }
                            }
                        }
                    }
                }
                else -> {
                    Opt(stringResource(R.string.auto_upd)) { DaysStepper(prefs, "auto_upd_days", 2) }
                    Opt(stringResource(R.string.auto_resume)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip(stringResource(R.string.on), resume) { resume = true; prefs.edit().putBoolean("resume", true).apply() }
                            Chip(stringResource(R.string.off), !resume) { resume = false; prefs.edit().putBoolean("resume", false).apply() }
                        }
                    }
                    Opt(stringResource(R.string.hw_decode)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip(stringResource(R.string.on), hw) { hw = true; prefs.edit().putBoolean("hw", true).apply() }
                            Chip(stringResource(R.string.off), !hw) { hw = false; prefs.edit().putBoolean("hw", false).apply() }
                        }
                        Text(stringResource(R.string.hw_hint), color = Dim, fontSize = 11.sp)
                    }
                    Opt(stringResource(R.string.buffer)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(800 to R.string.buf_low, 1500 to R.string.buf_normal, 4000 to R.string.buf_high).forEach { (v, r) ->
                                Chip(stringResource(r), cache == v) { cache = v; prefs.edit().putInt("cache", v).apply() }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun About(onBack: () -> Unit) = Box(Modifier.fillMaxSize()) {
    Box(Modifier.padding(14.dp)) { BackBtn(onBack) }
    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("IPTV Player", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Acc)
        Text(stringResource(R.string.app_version), color = Dim)
        Text(stringResource(R.string.about_note), color = Dim, fontSize = 13.sp)
    }
}

@Composable fun DlRow(d: Dl, sub: Sub?, showTitle: Boolean, onPlay: (Dl) -> Unit) {
    val ctx = LocalContext.current
    val p = if (d.total > 0) (d.done.toFloat() / d.total).coerceIn(0f, 1f) else 0f
    val st = when (d.status) {
        "running" -> R.string.dl_st_running; "paused" -> R.string.dl_st_paused
        "done" -> R.string.dl_st_done; "error" -> R.string.dl_st_error; else -> R.string.dl_st_queued
    }
    // Speed from the progress updates (smoothed)
    var speed by remember(d.id) { mutableLongStateOf(0L) }
    var last by remember(d.id) { mutableStateOf(0L to 0L) }
    LaunchedEffect(d.done, d.status) {
        val now = System.currentTimeMillis()
        if (d.status == "running") {
            if (last.first > 0 && now > last.first && d.done >= last.second) {
                val inst = (d.done - last.second) * 1000 / (now - last.first)
                speed = if (speed == 0L) inst else (speed * 6 + inst * 4) / 10
            }
        } else speed = 0L
        last = now to d.done
    }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        Fx({ if (d.status == "done") onPlay(d) }, Modifier.weight(1f), pad = 8.dp) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                if (showTitle) Text(d.title, maxLines = 1, fontSize = 13.sp)
                if (d.status != "done") Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LinearProgressIndicator(progress = { p }, modifier = Modifier.weight(1f), color = Acc)
                    if (d.status == "running" && speed > 0) Text(Formatter.formatFileSize(ctx, speed) + "/s", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Acc, maxLines = 1)
                }
                Text(stringResource(st) + " · " + Formatter.formatFileSize(ctx, d.done) + (if (d.total > 0) " / " + Formatter.formatFileSize(ctx, d.total) else ""),
                    color = if (d.status == "error") Err else Dim, fontSize = 11.sp)
            }
        }
        if (d.status == "running" || d.status == "queued") Fx({ Downloader.pause(ctx, d.id) }, pad = 8.dp) { Icon(Icons.Filled.Pause, null, Modifier.size(20.dp)) }
        else if (d.status == "paused" || d.status == "error") Fx({ if (sub != null) Downloader.start(ctx, sub, d.id) }, pad = 8.dp) { Icon(Icons.Filled.PlayArrow, null, Modifier.size(20.dp), tint = Ok) }
        Fx({ Downloader.remove(ctx, d.id) }, pad = 8.dp) { Icon(Icons.Filled.Delete, null, Modifier.size(20.dp), tint = Err) }
    }
}

@Composable fun DlGroup(files: List<Dl>, sub: Sub?, onPlay: (Dl) -> Unit) {
    val head = files.first()
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(.06f)).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AsyncImage(head.cover, null, Modifier.width(48.dp).aspectRatio(0.68f).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(head.grp, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            files.sortedBy { it.title }.forEach { d -> DlRow(d, sub, d.kind != "movie", onPlay) }
        }
    }
}

@Composable fun Downloads(sub: Sub?, store: StoreDao, onBack: () -> Unit, onPlay: (Dl) -> Unit) {
    val ctx = LocalContext.current
    val list by remember(sub?.id) { store.dls(sub?.id ?: -1L) }.collectAsState(initial = emptyList<Dl>())
    var tab by remember { mutableIntStateOf(0) }
    var cfg by remember { mutableStateOf(false) }
    val free = Formatter.formatFileSize(ctx, Downloader.dir(ctx).usableSpace)
    val used = Formatter.formatFileSize(ctx, list.sumOf { it.done })
    val shown = list.filter { (it.status == "done") == (tab == 1) }
    val movies = shown.filter { it.kind == "movie" }.groupBy { it.grp }.entries.toList()
    val series = shown.filter { it.kind != "movie" }.groupBy { it.grp }.entries.toList()
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            Text(stringResource(R.string.down), fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Chip(stringResource(R.string.dl_tab_active), tab == 0) { tab = 0 }
            Chip(stringResource(R.string.dl_tab_done), tab == 1) { tab = 1 }
            Fx({ cfg = true }, pad = 8.dp) { Icon(Icons.Filled.Settings, null, Modifier.size(18.dp)) }
        }
        Text(used + " · " + stringResource(R.string.dl_free) + " " + free, color = Dim, fontSize = 12.sp)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (shown.isEmpty()) item { Text(stringResource(R.string.dl_empty), color = Dim) }
            if (movies.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.movies), fontWeight = FontWeight.Bold, color = Acc)
                        HorizontalDivider(Modifier.weight(1f), color = Color.White.copy(.2f))
                    }
                }
                items(movies) { e -> DlGroup(e.value, sub, onPlay) }
            }
            if (series.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HorizontalDivider(Modifier.weight(1f), color = Color.White.copy(.2f))
                        Text(stringResource(R.string.series), fontWeight = FontWeight.Bold, color = Acc)
                    }
                }
                items(series) { e -> DlGroup(e.value, sub, onPlay) }
            }
        }
    }
    if (cfg) Dialog(onDismissRequest = { cfg = false }) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.dl_settings), fontWeight = FontWeight.Bold)
            DlSettings()
            Fx({ cfg = false }, pad = 8.dp) { Text(stringResource(R.string.close)) }
        }
    }
}
