package com.iptv.player.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.graphics.Color
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Mem { val m = HashMap<String, Cata>(); val live = HashMap<String, LiveData>() }

@Composable fun Chip(t: String, on: Boolean, click: () -> Unit) =
    Fx(click, brush = if (on) Grad else null, pad = 8.dp) { Text(t, fontSize = 12.sp, maxLines = 1) }

@Composable fun CatRow(t: String, on: Boolean, click: () -> Unit) =
    Fx(click, Modifier.fillMaxWidth(), brush = if (on) Grad else null, flat = !on, pad = 8.dp) { Text(t, fontSize = 12.sp, maxLines = 2) }

/** Full-screen page: back button + vertical category list on the left, content on the right. */
@Composable fun TwoPane(title: String, cats: List<Pair<String, String>>, cat: String, onCat: (String) -> Unit, onBack: () -> Unit,
                        allLabel: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.width(150.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BackBtn(onBack)
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (allLabel) item { CatRow(stringResource(R.string.cat_all), cat.isEmpty()) { onCat("") } }
                items(cats) { c -> CatRow(c.second, cat == c.first) { onCat(c.first) } }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable fun Catalog(kind: String, sub: Sub?, favIds: Set<String>, onOpen: (Vod) -> Unit, onBack: () -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val key = "${sub?.id}|$kind"
    var data by remember(key) { mutableStateOf(Mem.m[key]) }
    var err by remember(key) { mutableStateOf<String?>(null) }
    var cat by remember(key) { mutableStateOf(prefs.getString("cat_$key", "") ?: "") }
    var q by remember(key) { mutableStateOf("") }
    LaunchedEffect(key) {
        if (sub == null || sub.type != "xtream" || data != null) return@LaunchedEffect
        try {
            val d = withContext(Dispatchers.IO) {
                val p = Secure.get(ctx, sub.id)
                if (kind == "movie") Xt.movies(sub.url, sub.user, p) else Xt.seriesList(sub.url, sub.user, p)
            }
            Mem.m[key] = d; data = d
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    val shown = remember(data, cat, q) { data?.items.orEmpty().filter { (cat.isEmpty() || it.cat == cat) && it.name.contains(q, true) } }
    TwoPane(stringResource(if (kind == "movie") R.string.movies else R.string.series),
        data?.cats?.entries?.map { it.key to it.value }.orEmpty(), cat, { cat = it; prefs.edit().putString("cat_$key", it).apply() }, onBack) {
        if (data != null) OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.search_generic), maxLines = 1) })
        when {
            sub == null -> { Text(stringResource(R.string.no_active), color = Dim); Fx(onAdd, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.add_sub)) } }
            sub.type != "xtream" -> Text(stringResource(R.string.xtream_only), color = Dim)
            err != null -> Text(err!!, color = Err)
            data == null -> CircularProgressIndicator(color = Acc)
            else -> LazyVerticalGrid(GridCells.Adaptive(110.dp), Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                gridItems(shown) { v ->
                    Fx({ onOpen(v) }, pad = 4.dp) {
                        Column {
                            AsyncImage(v.cover, null, Modifier.fillMaxWidth().aspectRatio(0.68f).clip(RoundedCornerShape(12.dp)).background(Side), contentScale = ContentScale.Crop)
                            Text(v.name, maxLines = 1, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                        if (v.id in favIds) Icon(Icons.Filled.Favorite, null, tint = Acc, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable fun Live(sub: Sub?, favIds: Set<String>, onPlay: (Ch) -> Unit, onFav: (Ch) -> Unit, onBack: () -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val key = "${sub?.id}|live"
    var data by remember(key) { mutableStateOf(Mem.live[key]) }
    var err by remember(key) { mutableStateOf<String?>(null) }
    var cat by remember(key) { mutableStateOf(prefs.getString("cat_$key", "") ?: "") }
    var q by remember(key) { mutableStateOf("") }
    LaunchedEffect(key) {
        if (sub == null || data != null) return@LaunchedEffect
        try {
            val d = withContext(Dispatchers.IO) {
                when (sub.type) {
                    "xtream" -> Xt.live(sub.url, sub.user, Secure.get(ctx, sub.id))
                    "m3u" -> Xt.m3uLive(ctx, sub.url)
                    "single" -> LiveData(emptyMap(), listOf(Ch(sub.name, sub.url)))
                    else -> throw IllegalStateException(ctx.getString(R.string.stalker_later))
                }
            }
            Mem.live[key] = d; data = d
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    val shown = remember(data, cat, q) { data?.items.orEmpty().filter { (cat.isEmpty() || it.cat == cat) && it.name.contains(q, true) } }
    TwoPane(stringResource(R.string.live), data?.cats?.entries?.map { it.key to it.value }.orEmpty(), cat,
        { cat = it; prefs.edit().putString("cat_$key", it).apply() }, onBack) {
        if (data != null) OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.search), maxLines = 1) })
        when {
            sub == null -> { Text(stringResource(R.string.no_active), color = Dim); Fx(onAdd, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.add_sub)) } }
            err != null -> Text(err!!, color = Err)
            data == null -> CircularProgressIndicator(color = Acc)
            else -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(shown) { c ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Fx({ onPlay(c) }, Modifier.weight(1f), pad = 8.dp) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (c.logo.isNotBlank()) AsyncImage(c.logo, null, Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Fit)
                                else Icon(Icons.Filled.PlayArrow, null, Modifier.size(34.dp), tint = Acc)
                                Text(c.name, maxLines = 1)
                            }
                        }
                        Fx({ onFav(c) }, pad = 10.dp) { Icon(if (c.url in favIds) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Acc) }
                    }
                }
            }
        }
    }
}

@Composable fun MovieDialog(v: Vod, fav: Boolean, onPlay: () -> Unit, onFav: () -> Unit, onDownload: () -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Row(Modifier.fillMaxWidth(0.8f).clip(RoundedCornerShape(24.dp)).background(Side).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            AsyncImage(v.cover, null, Modifier.width(110.dp).aspectRatio(0.68f).clip(RoundedCornerShape(14.dp)).background(Bg), contentScale = ContentScale.Crop)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(v.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (v.rating.isNotBlank()) Text("★ " + v.rating, color = Dim)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Fx(onPlay, brush = Grad, pad = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text(stringResource(R.string.play), fontWeight = FontWeight.Bold) }
                    }
                    Fx(onDownload, pad = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Download, null); Spacer(Modifier.width(4.dp)); Text(stringResource(R.string.download), fontSize = 13.sp) }
                    }
                    Fx(onFav, pad = 10.dp) { Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Acc) }
                }
            }
        }
    }
}

@Composable fun SeriesDetail(v: Vod, sub: Sub, fav: Boolean, onFav: () -> Unit, onPlay: (Ep) -> Unit, onDownload: (List<Ep>) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var eps by remember(v.id) { mutableStateOf<List<Ep>?>(null) }
    var err by remember(v.id) { mutableStateOf<String?>(null) }
    var season by remember(v.id) { mutableIntStateOf(1) }
    var menu by remember(v.id) { mutableIntStateOf(0) }
    var selecting by remember(v.id) { mutableStateOf(false) }
    val picked = remember(v.id) { mutableStateListOf<String>() }
    val all = eps.orEmpty()
    val seasons = all.map { it.season }.distinct()
    BackHandler { if (selecting) { selecting = false; picked.clear() } else onBack() }
    LaunchedEffect(v.id) {
        try {
            val l = withContext(Dispatchers.IO) { Xt.episodes(sub.url, sub.user, Secure.get(ctx, sub.id), v.id) }
            eps = l; season = l.firstOrNull()?.season ?: 1
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.width(100.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            AsyncImage(v.cover, null, Modifier.fillMaxWidth().aspectRatio(0.68f).clip(RoundedCornerShape(14.dp)).background(Side), contentScale = ContentScale.Crop)
            Text(v.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Fx(onFav, pad = 8.dp) { Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Acc) }
                Fx({ if (eps != null) menu = 1 }, pad = 8.dp) { Icon(Icons.Filled.Download, stringResource(R.string.download)) }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when {
                err != null -> Text(err!!, color = Err)
                eps == null -> CircularProgressIndicator(color = Acc)
                else -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(seasons) { s -> Chip(stringResource(R.string.season) + " " + s, s == season) { season = s } }
                    }
                    if (selecting) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Fx({ if (picked.isNotEmpty()) { onDownload(all.filter { it.id in picked }); selecting = false; picked.clear() } }, brush = Grad, pad = 8.dp) {
                            Text(stringResource(R.string.dl_start) + " (" + picked.size + ")", fontSize = 12.sp)
                        }
                        Fx({
                            val ids = all.filter { it.season == season }.map { it.id }
                            if (picked.containsAll(ids)) { picked.removeAll(ids) } else { ids.forEach { if (it !in picked) picked.add(it) } }
                        }, pad = 8.dp) { Text(stringResource(R.string.dl_all_season), fontSize = 12.sp) }
                        Fx({ selecting = false; picked.clear() }, pad = 8.dp) { Text(stringResource(R.string.cancel), fontSize = 12.sp) }
                    }
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(all.filter { it.season == season }) { e ->
                            Fx({
                                if (!selecting) onPlay(e)
                                else if (e.id in picked) { picked.remove(e.id) } else { picked.add(e.id) }
                            }, Modifier.fillMaxWidth(), pad = 10.dp) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (selecting) Checkbox(checked = e.id in picked, onCheckedChange = null, colors = CheckboxDefaults.colors(checkedColor = Acc))
                                    else Icon(Icons.Filled.PlayArrow, null, tint = Acc)
                                    Text("${e.num}. ${e.title}", maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (menu != 0) Dialog(onDismissRequest = { menu = 0 }) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp).heightIn(max = 280.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (menu == 1) {
                Text(stringResource(R.string.download), fontWeight = FontWeight.Bold)
                Fx({ onDownload(all); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_full)) }
                if (seasons.size > 1) Fx({ menu = 2 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_season)) }
                Fx({ selecting = true; picked.clear(); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_episodes)) }
            } else {
                Text(stringResource(R.string.dl_pick_season), fontWeight = FontWeight.Bold)
                seasons.forEach { s ->
                    Fx({ onDownload(all.filter { it.season == s }); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.season) + " " + s) }
                }
            }
        }
    }
}

@Composable fun Favs(sub: Sub?, store: StoreDao, onPlay: (Fav) -> Unit, onSeries: (Fav) -> Unit, onRemove: (Fav) -> Unit, onBack: () -> Unit) {
    var kind by remember { mutableStateOf("live") }
    val list by remember(sub?.id, kind) { store.list(sub?.id ?: -1L, kind) }.collectAsState(initial = emptyList<Fav>())
    TwoPane(stringResource(R.string.fav),
        listOf("live" to stringResource(R.string.live), "movie" to stringResource(R.string.movies), "series" to stringResource(R.string.series)),
        kind, { kind = it }, onBack, allLabel = false) {
        if (list.isEmpty()) Text(stringResource(R.string.fav_empty), color = Dim)
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { f ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Fx({ if (f.kind == "series") onSeries(f) else onPlay(f) }, Modifier.weight(1f), pad = 8.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (f.cover.isNotBlank()) AsyncImage(f.cover, null, Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Crop)
                            else Icon(Icons.Filled.PlayArrow, null, Modifier.size(36.dp), tint = Acc)
                            Text(f.name, maxLines = 1)
                        }
                    }
                    Fx({ onRemove(f) }, pad = 10.dp) { Icon(Icons.Filled.Favorite, null, tint = Acc) }
                }
            }
        }
    }
}

@Composable fun DlSettings() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    var limit by remember { mutableIntStateOf(prefs.getInt("dl_limit", 2)) }
    var tree by remember { mutableStateOf(prefs.getString("dl_tree", null)) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("dl_tree", uri.toString()).apply(); tree = uri.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.dl_path), color = Dim, fontSize = 13.sp)
        Text(if (tree == null) stringResource(R.string.dl_path_default) else Uri.decode(tree.orEmpty()), fontSize = 12.sp, maxLines = 2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Fx({ pick.launch(null) }, pad = 8.dp) { Text(stringResource(R.string.dl_choose_folder), fontSize = 13.sp) }
            if (tree != null) Fx({ prefs.edit().remove("dl_tree").apply(); tree = null }, pad = 8.dp) { Text(stringResource(R.string.dl_reset), fontSize = 13.sp) }
        }
        Text(stringResource(R.string.dl_limit), color = Dim, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Fx({ if (limit > 1) { limit -= 1; prefs.edit().putInt("dl_limit", limit).apply() } }, pad = 8.dp) { Text("−", fontSize = 16.sp) }
            Text(limit.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Fx({ if (limit < 5) { limit += 1; prefs.edit().putInt("dl_limit", limit).apply() } }, pad = 8.dp) { Text("+", fontSize = 16.sp) }
        }
    }
}

@Composable fun Settings(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val cur = prefs.getString("lang", "") ?: ""
    var msg by remember { mutableStateOf<String?>(null) }
    fun setLang(l: String) { prefs.edit().putString("lang", l).apply(); (ctx as? Activity)?.recreate() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            Text(stringResource(R.string.settings), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Text(stringResource(R.string.lang), color = Dim)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Fx({ setLang("ar") }, brush = if (cur == "ar") Grad else null, pad = 10.dp) { Text("العربية") }
            Fx({ setLang("en") }, brush = if (cur == "en") Grad else null, pad = 10.dp) { Text("English") }
        }
        Text(stringResource(R.string.dl_settings), fontWeight = FontWeight.Bold)
        DlSettings()
        Fx({ ctx.cacheDir.deleteRecursively(); Mem.m.clear(); Mem.live.clear(); msg = ctx.getString(R.string.cache_cleared) }, pad = 10.dp) { Text(stringResource(R.string.clear_cache)) }
        msg?.let { Text(it, color = Ok) }
        Text(stringResource(R.string.parental_soon), color = Dim, fontSize = 13.sp)
        Text(stringResource(R.string.app_version), color = Dim, fontSize = 13.sp)
    }
}

@Composable fun About(onBack: () -> Unit) = Box(Modifier.fillMaxSize()) {
    Box(Modifier.padding(14.dp)) { BackBtn(onBack) }
    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("IPTV Player", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Acc)
        Text(stringResource(R.string.app_version), color = Dim)
        Text(stringResource(R.string.about_note), color = Dim, fontSize = 13.sp)
    }
}

@Composable fun DlRow(d: Dl, sub: Sub?, showTitle: Boolean, onPlay: (Dl) -> Unit) {
    val ctx = LocalContext.current
    val p = if (d.total > 0) (d.done.toFloat() / d.total).coerceIn(0f, 1f) else 0f
    val st = when (d.status) {
        "running" -> R.string.dl_st_running; "paused" -> R.string.dl_st_paused
        "done" -> R.string.dl_st_done; "error" -> R.string.dl_st_error; else -> R.string.dl_st_queued
    }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        Fx({ if (d.status == "done") onPlay(d) }, Modifier.weight(1f), pad = 8.dp) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                if (showTitle) Text(d.title, maxLines = 1, fontSize = 13.sp)
                if (d.status != "done") LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth(), color = Acc)
                Text(stringResource(st) + " · " + Formatter.formatFileSize(ctx, d.done) + (if (d.total > 0) " / " + Formatter.formatFileSize(ctx, d.total) else ""),
                    color = if (d.status == "error") Err else Dim, fontSize = 11.sp)
            }
        }
        if (d.status == "running" || d.status == "queued") Fx({ Downloader.pause(ctx, d.id) }, pad = 8.dp) { Icon(Icons.Filled.Pause, null, Modifier.size(20.dp)) }
        else if (d.status == "paused" || d.status == "error") Fx({ if (sub != null) Downloader.start(ctx, sub, d.id) }, pad = 8.dp) { Icon(Icons.Filled.PlayArrow, null, Modifier.size(20.dp), tint = Ok) }
        Fx({ Downloader.remove(ctx, d.id) }, pad = 8.dp) { Icon(Icons.Filled.Delete, null, Modifier.size(20.dp), tint = Err) }
    }
}

@Composable fun DlGroup(files: List<Dl>, sub: Sub?, onPlay: (Dl) -> Unit) {
    val head = files.first()
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(.06f)).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AsyncImage(head.cover, null, Modifier.width(48.dp).aspectRatio(0.68f).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(head.grp, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            files.sortedBy { it.title }.forEach { d -> DlRow(d, sub, d.kind != "movie", onPlay) }
        }
    }
}

@Composable fun Downloads(sub: Sub?, store: StoreDao, onBack: () -> Unit, onPlay: (Dl) -> Unit) {
    val ctx = LocalContext.current
    val list by remember(sub?.id) { store.dls(sub?.id ?: -1L) }.collectAsState(initial = emptyList<Dl>())
    var tab by remember { mutableIntStateOf(0) }
    var cfg by remember { mutableStateOf(false) }
    val free = Formatter.formatFileSize(ctx, Downloader.dir(ctx).usableSpace)
    val used = Formatter.formatFileSize(ctx, list.sumOf { it.done })
    val shown = list.filter { (it.status == "done") == (tab == 1) }
    val movies = shown.filter { it.kind == "movie" }.groupBy { it.grp }.entries.toList()
    val series = shown.filter { it.kind != "movie" }.groupBy { it.grp }.entries.toList()
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            Text(stringResource(R.string.down), fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Chip(stringResource(R.string.dl_tab_active), tab == 0) { tab = 0 }
            Chip(stringResource(R.string.dl_tab_done), tab == 1) { tab = 1 }
            Fx({ cfg = true }, pad = 8.dp) { Icon(Icons.Filled.Settings, null, Modifier.size(18.dp)) }
        }
        Text(used + " · " + stringResource(R.string.dl_free) + " " + free, color = Dim, fontSize = 12.sp)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (shown.isEmpty()) item { Text(stringResource(R.string.dl_empty), color = Dim) }
            if (movies.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.movies), fontWeight = FontWeight.Bold, color = Acc)
                        HorizontalDivider(Modifier.weight(1f), color = Color.White.copy(.2f))
                    }
                }
                items(movies) { e -> DlGroup(e.value, sub, onPlay) }
            }
            if (series.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HorizontalDivider(Modifier.weight(1f), color = Color.White.copy(.2f))
                        Text(stringResource(R.string.series), fontWeight = FontWeight.Bold, color = Acc)
                    }
                }
                items(series) { e -> DlGroup(e.value, sub, onPlay) }
            }
        }
    }
    if (cfg) Dialog(onDismissRequest = { cfg = false }) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.dl_settings), fontWeight = FontWeight.Bold)
            DlSettings()
            Fx({ cfg = false }, pad = 8.dp) { Text(stringResource(R.string.close)) }
        }
    }
}
