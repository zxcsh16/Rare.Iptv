package com.iptv.player.ui

import android.app.Activity
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Mem { val m = HashMap<String, Cata>() }

@Composable fun Chip(t: String, on: Boolean, click: () -> Unit) =
    Fx(click, brush = if (on) Grad else null, pad = 8.dp) { Text(t, fontSize = 12.sp, maxLines = 1) }

@Composable fun Catalog(kind: String, sub: Sub?, favIds: Set<String>, onOpen: (Vod) -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val key = "${sub?.id}|$kind"
    var data by remember(key) { mutableStateOf(Mem.m[key]) }
    var err by remember(key) { mutableStateOf<String?>(null) }
    var cat by remember(key) { mutableStateOf("") }
    var q by remember(key) { mutableStateOf("") }
    LaunchedEffect(key) {
        if (sub == null || sub.type != "xtream" || data != null) return@LaunchedEffect
        try {
            val d = withContext(Dispatchers.IO) {
                val p = Secure.get(ctx, sub.id)
                if (kind == "movie") Xt.movies(sub.url, sub.user, p) else Xt.seriesList(sub.url, sub.user, p)
            }
            Mem.m[key] = d; data = d
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    val shown = remember(data, cat, q) { data?.items.orEmpty().filter { (cat.isEmpty() || it.cat == cat) && it.name.contains(q, true) } }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(if (kind == "movie") R.string.movies else R.string.series), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (data != null) OutlinedTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.search_generic), maxLines = 1) })
        }
        when {
            sub == null -> { Text(stringResource(R.string.no_active), color = Dim); Fx(onAdd, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.add_sub)) } }
            sub.type != "xtream" -> Text(stringResource(R.string.xtream_only), color = Dim)
            err != null -> Text(err!!, color = Err)
            data == null -> CircularProgressIndicator(color = Acc)
            else -> {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Chip(stringResource(R.string.cat_all), cat.isEmpty()) { cat = "" } }
                    items(data!!.cats.entries.toList()) { e -> Chip(e.value, cat == e.key) { cat = e.key } }
                }
                LazyVerticalGrid(GridCells.Adaptive(110.dp), Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    gridItems(shown) { v ->
                        Fx({ onOpen(v) }, pad = 4.dp) {
                            Column {
                                AsyncImage(v.cover, null, Modifier.fillMaxWidth().aspectRatio(0.68f).clip(RoundedCornerShape(12.dp)).background(Side), contentScale = ContentScale.Crop)
                                Text(v.name, maxLines = 1, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                            if (v.id in favIds) Icon(Icons.Filled.Favorite, null, tint = Acc, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable fun MovieDialog(v: Vod, fav: Boolean, onPlay: () -> Unit, onFav: () -> Unit, onDownload: () -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Row(Modifier.fillMaxWidth(0.8f).clip(RoundedCornerShape(24.dp)).background(Side).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            AsyncImage(v.cover, null, Modifier.width(110.dp).aspectRatio(0.68f).clip(RoundedCornerShape(14.dp)).background(Bg), contentScale = ContentScale.Crop)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(v.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (v.rating.isNotBlank()) Text("★ " + v.rating, color = Dim)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Fx(onPlay, brush = Grad, pad = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text(stringResource(R.string.play), fontWeight = FontWeight.Bold) }
                    }
                    Fx(onDownload, pad = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Download, null); Spacer(Modifier.width(4.dp)); Text(stringResource(R.string.download), fontSize = 13.sp) }
                    }
                    Fx(onFav, pad = 10.dp) { Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Acc) }
                }
            }
        }
    }
}

@Composable fun SeriesDetail(v: Vod, sub: Sub, fav: Boolean, onFav: () -> Unit, onPlay: (Ep) -> Unit, onDownload: (List<Ep>) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var eps by remember(v.id) { mutableStateOf<List<Ep>?>(null) }
    var err by remember(v.id) { mutableStateOf<String?>(null) }
    var season by remember(v.id) { mutableIntStateOf(1) }
    var menu by remember(v.id) { mutableIntStateOf(0) }
    var selecting by remember(v.id) { mutableStateOf(false) }
    val picked = remember(v.id) { mutableStateListOf<String>() }
    val all = eps.orEmpty()
    val seasons = all.map { it.season }.distinct()
    BackHandler { if (selecting) { selecting = false; picked.clear() } else onBack() }
    LaunchedEffect(v.id) {
        try {
            val l = withContext(Dispatchers.IO) { Xt.episodes(sub.url, sub.user, Secure.get(ctx, sub.id), v.id) }
            eps = l; season = l.firstOrNull()?.season ?: 1
        } catch (e: Exception) { err = e.message ?: ctx.getString(R.string.e_conn) }
    }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.width(120.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AsyncImage(v.cover, null, Modifier.fillMaxWidth().aspectRatio(0.68f).clip(RoundedCornerShape(14.dp)).background(Side), contentScale = ContentScale.Crop)
            Text(v.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Fx(onFav, pad = 8.dp) { Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Acc) }
                Fx({ if (eps != null) menu = 1 }, pad = 8.dp) { Icon(Icons.Filled.Download, stringResource(R.string.download)) }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when {
                err != null -> Text(err!!, color = Err)
                eps == null -> CircularProgressIndicator(color = Acc)
                else -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(seasons) { s -> Chip(stringResource(R.string.season) + " " + s, s == season) { season = s } }
                    }
                    if (selecting) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Fx({ if (picked.isNotEmpty()) { onDownload(all.filter { it.id in picked }); selecting = false; picked.clear() } }, brush = Grad, pad = 8.dp) {
                            Text(stringResource(R.string.dl_start) + " (" + picked.size + ")", fontSize = 12.sp)
                        }
                        Fx({
                            val ids = all.filter { it.season == season }.map { it.id }
                            if (picked.containsAll(ids)) { picked.removeAll(ids) } else { ids.forEach { if (it !in picked) picked.add(it) } }
                        }, pad = 8.dp) { Text(stringResource(R.string.dl_all_season), fontSize = 12.sp) }
                        Fx({ selecting = false; picked.clear() }, pad = 8.dp) { Text(stringResource(R.string.cancel), fontSize = 12.sp) }
                    }
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(all.filter { it.season == season }) { e ->
                            Fx({
                                if (!selecting) onPlay(e)
                                else if (e.id in picked) { picked.remove(e.id) } else { picked.add(e.id) }
                            }, Modifier.fillMaxWidth(), pad = 10.dp) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (selecting) Checkbox(checked = e.id in picked, onCheckedChange = null, colors = CheckboxDefaults.colors(checkedColor = Acc))
                                    else Icon(Icons.Filled.PlayArrow, null, tint = Acc)
                                    Text("${e.num}. ${e.title}", maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (menu != 0) Dialog(onDismissRequest = { menu = 0 }) {
        Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Side).padding(16.dp).heightIn(max = 280.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (menu == 1) {
                Text(stringResource(R.string.download), fontWeight = FontWeight.Bold)
                Fx({ onDownload(all); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_full)) }
                if (seasons.size > 1) Fx({ menu = 2 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_season)) }
                Fx({ selecting = true; picked.clear(); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.dl_episodes)) }
            } else {
                Text(stringResource(R.string.dl_pick_season), fontWeight = FontWeight.Bold)
                seasons.forEach { s ->
                    Fx({ onDownload(all.filter { it.season == s }); menu = 0 }, Modifier.fillMaxWidth(), pad = 10.dp) { Text(stringResource(R.string.season) + " " + s) }
                }
            }
        }
    }
}

@Composable fun Favs(sub: Sub?, store: StoreDao, onPlay: (Fav) -> Unit, onSeries: (Fav) -> Unit, onRemove: (Fav) -> Unit) {
    var kind by remember { mutableStateOf("live") }
    val list by remember(sub?.id, kind) { store.list(sub?.id ?: -1L, kind) }.collectAsState(initial = emptyList<Fav>())
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.fav), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(stringResource(R.string.live), kind == "live") { kind = "live" }
            Chip(stringResource(R.string.movies), kind == "movie") { kind = "movie" }
            Chip(stringResource(R.string.series), kind == "series") { kind = "series" }
        }
        if (list.isEmpty()) Text(stringResource(R.string.fav_empty), color = Dim)
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { f ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Fx({ if (f.kind == "series") onSeries(f) else onPlay(f) }, Modifier.weight(1f), pad = 8.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (f.cover.isNotBlank()) AsyncImage(f.cover, null, Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Side), contentScale = ContentScale.Crop)
                            else Icon(Icons.Filled.PlayArrow, null, tint = Acc)
                            Text(f.name, maxLines = 1)
                        }
                    }
                    Fx({ onRemove(f) }, pad = 10.dp) { Icon(Icons.Filled.Favorite, null, tint = Acc) }
                }
            }
        }
    }
}

@Composable fun Settings() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val cur = prefs.getString("lang", "") ?: ""
    var msg by remember { mutableStateOf<String?>(null) }
    fun setLang(l: String) { prefs.edit().putString("lang", l).apply(); (ctx as? Activity)?.recreate() }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.settings), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.lang), color = Dim)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Fx({ setLang("ar") }, brush = if (cur == "ar") Grad else null, pad = 10.dp) { Text("العربية") }
            Fx({ setLang("en") }, brush = if (cur == "en") Grad else null, pad = 10.dp) { Text("English") }
        }
        Fx({ ctx.cacheDir.deleteRecursively(); Mem.m.clear(); msg = ctx.getString(R.string.cache_cleared) }, pad = 10.dp) { Text(stringResource(R.string.clear_cache)) }
        msg?.let { Text(it, color = Ok) }
        Text(stringResource(R.string.parental_soon), color = Dim, fontSize = 13.sp)
        Text(stringResource(R.string.app_version), color = Dim, fontSize = 13.sp)
    }
}

@Composable fun About() = Box(Modifier.fillMaxSize(), Alignment.Center) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("IPTV Player", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Acc)
        Text(stringResource(R.string.app_version), color = Dim)
        Text(stringResource(R.string.about_note), color = Dim, fontSize = 13.sp)
    }
}

@Composable fun Downloads(sub: Sub?, store: StoreDao, onPlay: (Dl) -> Unit) {
    val ctx = LocalContext.current
    val list by remember(sub?.id) { store.dls(sub?.id ?: -1L) }.collectAsState(initial = emptyList<Dl>())
    val free = Formatter.formatFileSize(ctx, Downloader.dir(ctx).usableSpace)
    val used = Formatter.formatFileSize(ctx, list.sumOf { it.done })
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.down), fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(used + " · " + stringResource(R.string.dl_free) + " " + free, color = Dim, fontSize = 12.sp)
        }
        if (list.isEmpty()) Text(stringResource(R.string.dl_empty), color = Dim)
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { d ->
                val p = if (d.total > 0) (d.done.toFloat() / d.total).coerceIn(0f, 1f) else 0f
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Fx({ if (d.status == "done") onPlay(d) }, Modifier.weight(1f), pad = 10.dp) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(d.title, maxLines = 1, fontSize = 14.sp)
                            if (d.status != "done") LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth(), color = Acc)
                            val st = when (d.status) {
                                "running" -> R.string.dl_st_running; "paused" -> R.string.dl_st_paused
                                "done" -> R.string.dl_st_done; "error" -> R.string.dl_st_error; else -> R.string.dl_st_queued
                            }
                            Text(stringResource(st) + " · " + Formatter.formatFileSize(ctx, d.done) + (if (d.total > 0) " / " + Formatter.formatFileSize(ctx, d.total) else ""),
                                color = if (d.status == "error") Err else Dim, fontSize = 11.sp)
                        }
                    }
                    if (d.status == "running" || d.status == "queued") Fx({ Downloader.pause(ctx, d.id) }, pad = 10.dp) { Icon(Icons.Filled.Pause, null) }
                    else if (d.status == "paused" || d.status == "error") Fx({ if (sub != null) Downloader.start(ctx, sub, d.id) }, pad = 10.dp) { Icon(Icons.Filled.PlayArrow, null, tint = Ok) }
                    Fx({ Downloader.remove(ctx, d.id) }, pad = 10.dp) { Icon(Icons.Filled.Delete, null, tint = Err) }
                }
            }
        }
    }
}
