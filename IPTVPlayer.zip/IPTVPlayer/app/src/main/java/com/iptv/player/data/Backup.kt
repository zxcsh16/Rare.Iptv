package com.iptv.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Encrypted subscription backup (AES-GCM, key derived from the user's password). */
object Backup {
    private val MAGIC = "IPTVBK1".toByteArray()
    private fun key(p: CharArray, salt: ByteArray): SecretKeySpec {
        val k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(PBEKeySpec(p, salt, 100000, 256)).encoded
        return SecretKeySpec(k, "AES")
    }
    fun export(c: Context, subs: List<Sub>, pass: CharArray): ByteArray {
        val arr = JSONArray()
        for (s in subs) arr.put(JSONObject().put("name", s.name).put("type", s.type).put("url", s.url)
            .put("user", s.user).put("expTs", s.expTs).put("pass", Secure.get(c, s.id)))
        val plain = JSONObject().put("subs", arr).toString().toByteArray()
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, key(pass, salt), GCMParameterSpec(128, iv))
        return MAGIC + salt + iv + ci.doFinal(plain)
    }
    /** Returns (number added, id of the first added subscription). Throws on wrong password / bad file. */
    suspend fun import(c: Context, data: ByteArray, pass: CharArray): Pair<Int, Long> {
        val m = MAGIC.size
        require(data.size > m + 28 && data.copyOfRange(0, m).contentEquals(MAGIC))
        val salt = data.copyOfRange(m, m + 16)
        val iv = data.copyOfRange(m + 16, m + 28)
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.DECRYPT_MODE, key(pass, salt), GCMParameterSpec(128, iv))
        val plain = ci.doFinal(data, m + 28, data.size - m - 28)
        val arr = JSONObject(String(plain)).getJSONArray("subs")
        val dao = Db.get(c).dao()
        val have = dao.snapshot()
        var n = 0; var first = -1L
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val s = Sub(name = o.getString("name"), type = o.getString("type"), url = o.getString("url"), user = o.optString("user"), expTs = o.optLong("expTs"))
            if (have.any { it.type == s.type && it.url == s.url && it.user == s.user }) continue
            val id = dao.add(s)
            if (o.optString("pass").isNotEmpty()) Secure.put(c, id, o.getString("pass"))
            if (first < 0) first = id
            n++
        }
        return n to first
    }
}
