package com.iptv.player.data

import android.content.Context
import android.net.Uri
import androidx.room.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

@Entity data class Sub(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val type: String, val url: String,
    val user: String = "", val expTs: Long = 0
)
fun Sub.expired() = expTs > 0 && expTs * 1000 < System.currentTimeMillis()

@Dao interface SubDao {
    @Query("SELECT * FROM Sub ORDER BY id") fun all(): Flow<List<Sub>>
    @Insert suspend fun add(s: Sub): Long
    @Delete suspend fun del(s: Sub)
}

@Database(entities = [Sub::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): SubDao
    companion object {
        @Volatile private var I: Db? = null
        fun get(c: Context): Db = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "iptv.db").build().also { I = it }
        }
    }
}

/** Passwords are kept in encrypted storage, never in the database. */
object Secure {
    private fun p(c: Context) = EncryptedSharedPreferences.create(
        c, "sec", MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun put(c: Context, id: Long, v: String) = p(c).edit().putString("p$id", v).apply()
    fun get(c: Context, id: Long): String = p(c).getString("p$id", "") ?: ""
    fun del(c: Context, id: Long) = p(c).edit().remove("p$id").apply()
}

data class Ch(val name: String, val url: String)

object Net {
    fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 20000
        return c.inputStream.bufferedReader().use { it.readText() }
    }
    private fun api(s: String, u: String, p: String) = "${s.trimEnd('/')}/player_api.php?username=$u&password=$p"

    /** Returns the expiry as epoch seconds (0 = none). */
    fun xtreamLogin(s: String, u: String, p: String): Long {
        val ui = JSONObject(get(api(s, u, p))).getJSONObject("user_info")
        if (ui.optInt("auth", 0) != 1) throw IllegalStateException("Invalid credentials")
        return ui.optString("exp_date", "").toLongOrNull() ?: 0L
    }
    fun xtreamLive(s: String, u: String, p: String): List<Ch> {
        val a = JSONArray(get(api(s, u, p) + "&action=get_live_streams"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Ch(o.optString("name"), "${s.trimEnd('/')}/live/$u/$p/${o.optInt("stream_id")}.m3u8")
        }
    }
    fun m3u(c: Context, u: String): List<Ch> {
        val t = if (u.startsWith("content:")) c.contentResolver.openInputStream(Uri.parse(u))!!.bufferedReader().use { it.readText() } else get(u)
        var n: String? = null
        val r = ArrayList<Ch>()
        for (l in t.lineSequence()) {
            val s = l.trim()
            if (s.startsWith("#EXTINF")) n = s.substringAfterLast(",").ifBlank { "Channel" }
            else if (s.isNotEmpty() && !s.startsWith("#")) { r.add(Ch(n ?: s, s)); n = null }
        }
        return r
    }
}
