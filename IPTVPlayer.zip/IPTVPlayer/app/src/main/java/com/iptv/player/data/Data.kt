package com.iptv.player.data

import android.content.Context
import android.net.Uri
import androidx.room.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

@Entity data class Sub(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val type: String, val url: String,
    val user: String = "", val expTs: Long = 0
)
fun Sub.expired() = expTs > 0 && expTs * 1000 < System.currentTimeMillis()

@Dao interface SubDao {
    @Query("SELECT * FROM Sub ORDER BY id") fun all(): Flow<List<Sub>>
    @Insert suspend fun add(s: Sub): Long
    @Delete suspend fun del(s: Sub)
}

@Database(entities = [Sub::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): SubDao
    companion object {
        @Volatile private var I: Db? = null
        fun get(c: Context): Db = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "iptv.db").build().also { I = it }
        }
    }
}

/** Passwords are kept in encrypted storage, never in the database. */
object Secure {
    private fun p(c: Context) = EncryptedSharedPreferences.create(
        c, "sec", MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun put(c: Context, id: Long, v: String) = p(c).edit().putString("p$id", v).apply()
    fun get(c: Context, id: Long): String = p(c).getString("p$id", "") ?: ""
    fun del(c: Context, id: Long) = p(c).edit().remove("p$id").apply()
}

data class Ch(val name: String, val url: String)

object Net {
    fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 20000
        return c.inputStream.bufferedReader().use { it.readText() }
    }
    private fun api(s: String, u: String, p: String) = "${s.trimEnd('/')}/player_api.php?username=$u&password=$p"

    /** Returns the expiry as epoch seconds (0 = none). */
    fun xtreamLogin(s: String, u: String, p: String): Long {
        val ui = JSONObject(get(api(s, u, p))).getJSONObject("user_info")
        if (ui.optInt("auth", 0) != 1) throw IllegalStateException("Invalid credentials")
        return ui.optString("exp_date", "").toLongOrNull() ?: 0L
    }
    fun xtreamLive(s: String, u: String, p: String): List<Ch> {
        val a = JSONArray(get(api(s, u, p) + "&action=get_live_streams"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Ch(o.optString("name"), "xt:live/${o.optInt("stream_id")}.m3u8")
        }
    }
    fun m3u(c: Context, u: String): List<Ch> {
        val t = if (u.startsWith("content:")) c.contentResolver.openInputStream(Uri.parse(u))!!.bufferedReader().use { it.readText() } else get(u)
        var n: String? = null
        val r = ArrayList<Ch>()
        for (l in t.lineSequence()) {
            val s = l.trim()
            if (s.startsWith("#EXTINF")) n = s.substringAfterLast(",").ifBlank { "Channel" }
            else if (s.isNotEmpty() && !s.startsWith("#")) { r.add(Ch(n ?: s, s)); n = null }
        }
        return r
    }
}

private fun JSONObject.str(k: String): String { val v = optString(k, ""); return if (v == "null") "" else v }

data class Vod(val id: String, val name: String, val cover: String, val cat: String, val url: String, val rating: String = "")
data class Cata(val cats: Map<String, String>, val items: List<Vod>)
data class Ep(val id: String, val title: String, val season: Int, val num: Int, val url: String)

/** Xtream movie / series APIs. Stream links are stored as "xt:" paths (no password) and resolved at play time. */
object Xt {
    private fun q(s: String, u: String, p: String, a: String) = "${s.trimEnd('/')}/player_api.php?username=$u&password=$p&action=$a"
    private fun cats(s: String, u: String, p: String, a: String): Map<String, String> {
        val j = JSONArray(Net.get(q(s, u, p, a)))
        return (0 until j.length()).associate { val o = j.getJSONObject(it); o.str("category_id") to o.str("category_name") }
    }
    fun movies(s: String, u: String, p: String): Cata {
        val c = cats(s, u, p, "get_vod_categories")
        val a = JSONArray(Net.get(q(s, u, p, "get_vod_streams")))
        return Cata(c, (0 until a.length()).map {
            val o = a.getJSONObject(it); val id = o.str("stream_id")
            val ext = o.str("container_extension").ifBlank { "mp4" }
            Vod(id, o.str("name"), o.str("stream_icon"), o.str("category_id"), "xt:movie/$id.$ext", o.str("rating"))
        })
    }
    fun seriesList(s: String, u: String, p: String): Cata {
        val c = cats(s, u, p, "get_series_categories")
        val a = JSONArray(Net.get(q(s, u, p, "get_series")))
        return Cata(c, (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Vod(o.str("series_id"), o.str("name"), o.str("cover"), o.str("category_id"), "", o.str("rating"))
        })
    }
    fun episodes(s: String, u: String, p: String, id: String): List<Ep> {
        val j = JSONObject(Net.get(q(s, u, p, "get_series_info") + "&series_id=$id"))
        val e = j.optJSONObject("episodes") ?: return emptyList()
        val out = ArrayList<Ep>()
        for (k in e.keys()) {
            val a = e.optJSONArray(k) ?: continue
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ext = o.str("container_extension").ifBlank { "mkv" }
                out.add(Ep(o.str("id"), o.str("title"), k.toIntOrNull() ?: 1, o.optInt("episode_num", i + 1), "xt:series/${o.str("id")}.$ext"))
            }
        }
        return out.sortedWith(compareBy({ it.season }, { it.num }))
    }
}

fun resolve(c: Context, s: Sub, u: String): String {
    if (!u.startsWith("xt:")) return u
    val r = u.removePrefix("xt:"); val i = r.indexOf('/')
    return "${s.url.trimEnd('/')}/${r.substring(0, i)}/${s.user}/${Secure.get(c, s.id)}/${r.substring(i + 1)}"
}

@Entity(indices = [Index(value = ["subId", "kind", "itemId"], unique = true)])
data class Fav(@PrimaryKey(autoGenerate = true) val id: Long = 0, val subId: Long, val kind: String, val itemId: String,
               val name: String, val url: String, val cover: String = "")

@Entity data class Recent(@PrimaryKey val rk: String, val subId: Long, val kind: String, val itemId: String,
                          val name: String, val url: String, val cover: String, val ts: Long)

@Entity data class Dl(@PrimaryKey val id: String, val subId: Long, val title: String, val grp: String, val url: String,
                      val path: String, val status: String, val done: Long = 0, val total: Long = 0, val ts: Long = 0)

@Dao interface StoreDao {
    @Query("SELECT * FROM Fav WHERE subId=:s AND kind=:k ORDER BY id DESC") fun list(s: Long, k: String): Flow<List<Fav>>
    @Query("SELECT itemId FROM Fav WHERE subId=:s AND kind=:k") fun ids(s: Long, k: String): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun add(f: Fav)
    @Query("DELETE FROM Fav WHERE subId=:s AND kind=:k AND itemId=:i") suspend fun del(s: Long, k: String, i: String)
    @Query("SELECT * FROM Recent WHERE subId=:s ORDER BY ts DESC LIMIT 12") fun recent(s: Long): Flow<List<Recent>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addRecent(r: Recent)
    @Query("SELECT * FROM Dl WHERE subId=:s ORDER BY ts DESC") fun dls(s: Long): Flow<List<Dl>>
    @Query("SELECT * FROM Dl WHERE id=:i") suspend fun dl(i: String): Dl?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putDl(d: Dl)
    @Query("UPDATE Dl SET done=:d, total=:t, status=:st WHERE id=:i") suspend fun prog(i: String, d: Long, t: Long, st: String)
    @Query("UPDATE Dl SET status=:st WHERE id=:i") suspend fun setSt(i: String, st: String)
    @Query("DELETE FROM Dl WHERE id=:i") suspend fun delDl(i: String)
    @Query("UPDATE Dl SET status='paused' WHERE status IN ('running','queued')") suspend fun normalize()
}

@Database(entities = [Fav::class, Recent::class, Dl::class], version = 2, exportSchema = false)
abstract class Store : RoomDatabase() {
    abstract fun dao(): StoreDao
    companion object {
        @Volatile private var I: Store? = null
        fun get(c: Context): Store = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, Store::class.java, "store.db").fallbackToDestructiveMigration().build().also { I = it }
        }
    }
}
