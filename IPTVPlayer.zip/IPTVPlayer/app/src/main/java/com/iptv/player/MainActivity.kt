package com.iptv.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.iptv.player.data.*
import com.iptv.player.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(b: Context) {
        val l = b.getSharedPreferences("app", 0).getString("lang", "") ?: ""
        if (l.isEmpty()) super.attachBaseContext(b)
        else {
            val cfg = Configuration(b.resources.configuration)
            cfg.setLocale(Locale(l))
            super.attachBaseContext(b.createConfigurationContext(cfg))
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IptvTheme { App() } }
    }
}

@Composable fun App() {
    val ctx = LocalContext.current
    val dao = remember { Db.get(ctx).dao() }
    val store = remember { Store.get(ctx).dao() }
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val flow = remember { dao.all() }
    val subs by flow.collectAsState(initial = emptyList())
    var active by remember { mutableLongStateOf(prefs.getLong("active", -1)) }
    var scr by remember { mutableStateOf(S.Home) }
    var back by remember { mutableStateOf(S.Home) }
    var stream by remember { mutableStateOf("") }
    var series by remember { mutableStateOf<Vod?>(null) }
    var movie by remember { mutableStateOf<Vod?>(null) }
    var pending by remember { mutableStateOf<List<DlReq>?>(null) }
    var added by remember { mutableStateOf<List<Pair<String, Vod>>>(emptyList()) }
    val cur = subs.find { it.id == active }
    val favLive by remember(active) { store.ids(active, "live") }.collectAsState(initial = emptyList<String>())
    val favMovie by remember(active) { store.ids(active, "movie") }.collectAsState(initial = emptyList<String>())
    val favSeries by remember(active) { store.ids(active, "series") }.collectAsState(initial = emptyList<String>())
    val recents by remember(active) { store.recent(active) }.collectAsState(initial = emptyList<Recent>())
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(cur?.id) {
        val s = cur
        if (s == null || s.type != "xtream") { added = emptyList(); return@LaunchedEffect }
        try {
            val r = withContext(Dispatchers.IO) {
                val p = Secure.get(ctx, s.id)
                val m = Mem.m["${s.id}|movie"] ?: Xt.movies(s.url, s.user, p).also { Mem.m["${s.id}|movie"] = it }
                val t = Mem.m["${s.id}|series"] ?: Xt.seriesList(s.url, s.user, p).also { Mem.m["${s.id}|series"] = it }
                (m.items.map { "movie" to it } + t.items.map { "series" to it })
                    .filter { it.second.cover.isNotBlank() }.sortedByDescending { it.second.added }.take(12)
            }
            added = r
        } catch (_: Exception) { }
    }
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { if (Downloader.active.value == 0) store.normalize() } }

    fun setActive(i: Long) { active = i; prefs.edit().putLong("active", i).apply() }
    fun play(url: String, name: String, kind: String, id: String, cover: String) {
        val s = cur ?: return
        scope.launch {
            val full = withContext(Dispatchers.IO) { resolve(ctx, s, url) }
            withContext(Dispatchers.IO) { store.addRecent(Recent("${s.id}|$kind|$id", s.id, kind, id, name, url, cover, System.currentTimeMillis())) }
            stream = full; back = scr; scr = S.Player
        }
    }
    fun toggleFav(kind: String, id: String, name: String, url: String, cover: String, isFav: Boolean) {
        val s = cur ?: return
        scope.launch(Dispatchers.IO) {
            if (isFav) store.del(s.id, kind, id) else store.add(Fav(subId = s.id, kind = kind, itemId = id, name = name, url = url, cover = cover))
        }
    }
    fun enqueue(reqs: List<DlReq>) {
        val s = cur ?: return
        Downloader.enqueue(ctx, s, reqs)
        Toast.makeText(ctx, ctx.getString(R.string.dl_added, reqs.size), Toast.LENGTH_SHORT).show()
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun askDownload(reqs: List<DlReq>) { if (prefs.getBoolean("dl_ok", false)) enqueue(reqs) else pending = reqs }
    BackHandler(scr != S.Home && scr != S.Player) { if (movie != null) movie = null else scr = S.Home }

    val pd = pending
    if (pd != null) AlertDialog(
        onDismissRequest = { pending = null },
        title = { Text(stringResource(R.string.dl_consent_title)) },
        text = { Text(stringResource(R.string.dl_consent_text)) },
        confirmButton = { TextButton(onClick = { prefs.edit().putBoolean("dl_ok", true).apply(); enqueue(pd); pending = null }) { Text(stringResource(R.string.accept)) } },
        dismissButton = { TextButton(onClick = { pending = null }) { Text(stringResource(R.string.cancel)) } })

    Surface(Modifier.fillMaxSize(), color = Bg, contentColor = Color.White) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val compact = maxWidth < 700.dp
            val full = scr == S.Live || scr == S.Movies || scr == S.Series || scr == S.Fav
            if (scr == S.Player) PlayerScreen(stream) { scr = back }
            else Row(Modifier.fillMaxSize()) {
                if (!full) {
                    val expired = cur?.expired() == true
                    Sidebar(if (scr == S.Add) S.Switch else scr, compact, cur?.name ?: stringResource(R.string.no_sub),
                        if (cur == null) "—" else stringResource(if (expired) R.string.expired else R.string.active),
                        cur != null && !expired) { series = null; movie = null; scr = it }
                }
                Box(Modifier.weight(1f)) {
                    when (scr) {
                        S.Home -> Home({ scr = it }, compact, recents, added,
                            { r -> play(r.url, r.name, r.kind, r.itemId, r.cover) },
                            { k, v -> if (k == "movie") { movie = v; scr = S.Movies } else { series = v; scr = S.Series } })
                        S.Live -> Live(cur, favLive.toSet(), { c -> play(c.url, c.name, "live", c.url, c.logo) },
                            { c -> toggleFav("live", c.url, c.name, c.url, c.logo, c.url in favLive) }, { scr = S.Home }, { scr = S.Add })
                        S.Movies -> {
                            Catalog("movie", cur, favMovie.toSet(), { movie = it }, { scr = S.Home }, { scr = S.Add })
                            val m = movie
                            if (m != null) MovieDialog(m, m.id in favMovie,
                                { play(m.url, m.name, "movie", m.id, m.cover); movie = null },
                                { toggleFav("movie", m.id, m.name, m.url, m.cover, m.id in favMovie) },
                                { askDownload(listOf(DlReq("${cur?.id ?: -1}|movie|${m.id}", "movie", m.name, m.name, m.cover, m.name, m.url, m.url.substringAfterLast('.')))) },
                                { movie = null })
                        }
                        S.Series -> {
                            val sv = series
                            if (sv != null && cur != null) SeriesDetail(sv, cur, sv.id in favSeries,
                                { toggleFav("series", sv.id, sv.name, "", sv.cover, sv.id in favSeries) },
                                { e -> play(e.url, sv.name + " · S" + e.season + "E" + e.num, "episode", e.id, sv.cover) },
                                { list -> askDownload(list.map { e ->
                                    val label = "S%02d.E%02d".format(e.season, e.num)
                                    DlReq("${cur.id}|ep|${e.id}", "episode", sv.name, label, sv.cover, sv.name + "_" + label, e.url, e.url.substringAfterLast('.'))
                                }) },
                                { series = null })
                            else Catalog("series", cur, favSeries.toSet(), { series = it }, { scr = S.Home }, { scr = S.Add })
                        }
                        S.Fav -> Favs(cur, store, { f -> play(f.url, f.name, f.kind, f.itemId, f.cover) },
                            { f -> series = Vod(f.itemId, f.name, f.cover, "", ""); scr = S.Series },
                            { f -> scope.launch(Dispatchers.IO) { store.del(f.subId, f.kind, f.itemId) } }, { scr = S.Home })
                        S.Add -> AddSub({ scr = S.Home }) { id -> if (active < 0 || cur == null) setActive(id); scr = S.Switch }
                        S.Switch -> SwitchSub(subs, active, { setActive(it); scr = S.Home }, { scr = S.Add }, { scr = S.Home }) { s ->
                            scope.launch(Dispatchers.IO) { dao.del(s); Secure.del(ctx, s.id) }
                            if (s.id == active) setActive(-1)
                        }
                        S.Down -> Downloads(cur, store, { scr = S.Home }) { d -> stream = Downloader.playUri(d.path); back = scr; scr = S.Player }
                        S.Settings -> Settings { scr = S.Home }
                        S.About -> About { scr = S.Home }
                        else -> Soon()
                    }
                }
            }
        }
    }
}
