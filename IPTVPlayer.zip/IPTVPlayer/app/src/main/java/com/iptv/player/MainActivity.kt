package com.iptv.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.iptv.player.data.*
import com.iptv.player.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IptvTheme { App() } }
    }
}

@Composable fun App() {
    val ctx = LocalContext.current
    val dao = remember { Db.get(ctx).dao() }
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val flow = remember { dao.all() }
    val subs by flow.collectAsState(initial = emptyList())
    var active by remember { mutableLongStateOf(prefs.getLong("active", -1)) }
    var scr by remember { mutableStateOf(S.Home) }
    var stream by remember { mutableStateOf("") }
    val cur = subs.find { it.id == active }
    fun setActive(i: Long) { active = i; prefs.edit().putLong("active", i).apply() }
    BackHandler(scr != S.Home && scr != S.Player) { scr = S.Home }

    Surface(Modifier.fillMaxSize(), color = Bg, contentColor = Color.White) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val compact = maxWidth < 700.dp
            if (scr == S.Player) PlayerScreen(stream) { scr = S.Live }
            else Row(Modifier.fillMaxSize()) {
                val expired = cur?.expired() == true
                Sidebar(if (scr == S.Add) S.Switch else scr, compact, cur?.name ?: stringResource(R.string.no_sub),
                    if (cur == null) "—" else stringResource(if (expired) R.string.expired else R.string.active),
                    cur != null && !expired) { scr = it }
                Box(Modifier.weight(1f)) {
                    when (scr) {
                        S.Home -> Home({ scr = it }, compact)
                        S.Live -> Live(cur, { stream = it; scr = S.Player }, { scr = S.Add })
                        S.Add -> AddSub { id -> if (active < 0 || cur == null) setActive(id); scr = S.Switch }
                        S.Switch -> SwitchSub(subs, active, { setActive(it); scr = S.Live }, { scr = S.Add }) { s ->
                            scope.launch(Dispatchers.IO) { dao.del(s); Secure.del(ctx, s.id) }
                            if (s.id == active) setActive(-1)
                        }
                        else -> Soon()
                    }
                }
            }
        }
    }
}
