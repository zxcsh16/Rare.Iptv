package com.iptv.player

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Density
import com.iptv.player.data.*
import com.iptv.player.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(b: Context) {
        val l = b.getSharedPreferences("app", 0).getString("lang", "") ?: ""
        if (l.isEmpty()) super.attachBaseContext(b)
        else {
            val cfg = Configuration(b.resources.configuration)
            cfg.setLocale(Locale(l))
            super.attachBaseContext(b.createConfigurationContext(cfg))
        }
    }
    // Pressing Home while a video plays keeps it running in a small floating window (picture-in-picture).
    override fun onUserLeaveHint() { super.onUserLeaveHint(); if (playerOn) enterPip(this) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("app", 0)
        Ui.fontScale = p.getFloat("font_scale", 1f)
        Ui.barH = p.getInt("bar_h", 52)
        Ui.phone = p.getString("mode", "") == "phone"
        Ui.lite = p.getBoolean("lite", !Ui.phone)   // TV boxes default to the lighter mode
        // lighter image decoding: RGB565 halves memory, no cross-fades
        coil.Coil.setImageLoader(coil.ImageLoader.Builder(this).allowRgb565(true).crossfade(false).build())
        // warm up the video engine in the background so the first video starts faster
        val appCtx = applicationContext
        Thread { try { VlcHolder.get(appCtx) } catch (_: Throwable) { } }.start()
        setContent {
            IptvTheme {
                val d = LocalDensity.current
                // Layout stays left-to-right in every language (icons and panels keep their places); only the text changes.
                CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * Ui.fontScale),
                    LocalLayoutDirection provides LayoutDirection.Ltr) { App() }
            }
        }
    }
}

@Composable fun App() {
    val ctx = LocalContext.current
    val dao = remember { Db.get(ctx).dao() }
    val store = remember { Store.get(ctx).dao() }
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val flow = remember { dao.all() }
    val subs by flow.collectAsState(initial = emptyList())
    var active by remember { mutableLongStateOf(prefs.getLong("active", -1)) }
    var scr by remember { mutableStateOf(S.Home) }
    var back by remember { mutableStateOf(S.Home) }
    var stream by remember { mutableStateOf("") }
    var streamTitle by remember { mutableStateOf("") }
    var streamKey by remember { mutableStateOf("") }
    var startMs by remember { mutableLongStateOf(0L) }
    var nextUp by remember { mutableStateOf<(() -> Unit)?>(null) }   // plays the next episode when this one ends
    var lastAdded by remember { mutableLongStateOf(-1L) }   // subscription just added: the subscriptions screen puts the cursor on it
    var lastBack by remember { mutableLongStateOf(0L) }     // double-press Back on Home to exit
    var nextBtn by remember { mutableStateOf<(() -> Unit)?>(null) }  // "Next episode" button in the player (set whenever a next episode exists)
    var series by remember { mutableStateOf<Vod?>(null) }
    var movie by remember { mutableStateOf<Vod?>(null) }
    var pending by remember { mutableStateOf<List<DlReq>?>(null) }
    var added by remember { mutableStateOf<List<Pair<String, Vod>>>(emptyList()) }
    var castUrl by remember { mutableStateOf<String?>(null) }
    var askPerm by remember { mutableStateOf(false) }
    var permReqs by remember { mutableStateOf<List<DlReq>?>(null) }   // download waiting for the one-time file-access prompt
    var tick by remember { mutableIntStateOf(0) }
    var mode by remember { mutableStateOf(prefs.getString("mode", "") ?: "") }
    val cur = subs.find { it.id == active }
    val favLive by remember(active) { store.ids(active, "live") }.collectAsState(initial = emptyList<String>())
    val favMovie by remember(active) { store.ids(active, "movie") }.collectAsState(initial = emptyList<String>())
    val favSeries by remember(active) { store.ids(active, "series") }.collectAsState(initial = emptyList<String>())
    val recents by remember(active) { store.recent(active) }.collectAsState(initial = emptyList<Recent>())
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // Auto-update: lists are fetched fresh at launch; if the app stays open (e.g. a TV box) refresh them every N days.
    LaunchedEffect(cur?.id) {
        val s = cur ?: return@LaunchedEffect
        val k = "upd_${s.id}"
        prefs.edit().putLong(k, System.currentTimeMillis()).apply()
        while (true) {
            kotlinx.coroutines.delay(60 * 60 * 1000L)
            val days = prefs.getInt("auto_upd_days", 2)
            if (days > 0 && System.currentTimeMillis() - prefs.getLong(k, 0L) >= days * 86400000L) {
                Mem.m.keys.removeAll { it.startsWith("${s.id}|") }; Mem.live.keys.removeAll { it.startsWith("${s.id}|") }
                prefs.edit().putLong(k, System.currentTimeMillis()).apply(); tick++
            }
        }
    }
    LaunchedEffect(cur?.id, tick) {
        val s = cur
        if (s == null || s.type != "xtream") { added = emptyList(); return@LaunchedEffect }
        try {
            val r = withContext(Dispatchers.IO) {
                val p = Secure.get(ctx, s.id)
                val m = Mem.m["${s.id}|movie"] ?: Xt.movies(s.url, s.user, p).also { Mem.m["${s.id}|movie"] = it }
                val t = Mem.m["${s.id}|series"] ?: Xt.seriesList(s.url, s.user, p).also { Mem.m["${s.id}|series"] = it }
                (m.items.map { "movie" to it } + t.items.map { "series" to it })
                    .filter { it.second.cover.isNotBlank() }.sortedByDescending { it.second.added }.take(10)
            }
            added = r
        } catch (_: Exception) { }
    }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { if (Downloader.active.value == 0) store.normalize() }
    }

    fun setActive(i: Long) { active = i; prefs.edit().putLong("active", i).apply() }
    fun resumeMs(key: String): Long = if (prefs.getBoolean("resume", true)) prefs.getLong("pos_" + key.hashCode(), 0L) else 0L
    fun saveProgress(key: String, pos: Long, len: Long) {
        if (len <= 0 || key.isEmpty()) return
        val h = key.hashCode()
        val e = prefs.edit()
        if (len - pos < 30000) e.remove("pos_$h").remove("len_$h").putBoolean("done_$h", true)   // finished -> mark watched
        else if (pos > 10000) e.putLong("pos_$h", pos).putLong("len_$h", len).remove("done_$h")
        e.apply()
    }
    /** Starts playback at the saved position; the player itself asks "resume or start over" when one exists. */
    fun begin(full: String, title: String, key: String, live: Boolean, pre: () -> Unit = {}) {
        pre()
        stream = full; streamTitle = title; streamKey = key; startMs = if (live) 0L else resumeMs(key)
        if (scr != S.Player) back = scr
        scr = S.Player
    }
    fun play(url: String, name: String, kind: String, id: String, cover: String, title: String = name) {
        val s = cur ?: return
        nextUp = null; nextBtn = null
        scope.launch {
            val full = withContext(Dispatchers.IO) { resolve(ctx, s, url) }
            begin(full, title, url, kind == "live") {
                scope.launch(Dispatchers.IO) { store.addRecent(Recent("${s.id}|$kind|$id", s.id, kind, id, name, url, cover, System.currentTimeMillis(), parent = title)) }
            }
        }
    }
    /** Plays an episode and, when auto-next is on, queues the following one of the same series. */
    fun playEpisode(sv: Vod, e: Ep, all: List<Ep>) {
        play(e.url, sv.name, "series", sv.id, sv.cover, sv.name + " · S%02d.E%02d".format(e.season, e.num))
        val nx = all.getOrNull(all.indexOfFirst { it.id == e.id } + 1)
        nextBtn = if (nx != null) ({ playEpisode(sv, nx, all) }) else null
        nextUp = if (nx != null && prefs.getBoolean("auto_next", true)) nextBtn else null
    }
    // "Recently watched" tap: jump straight back into the last movie / episode (position is restored by resumeMs).
    fun resumeRecent(r: Recent) = play(r.url, r.name, r.kind, r.itemId, r.cover, r.parent.ifEmpty { r.name })
    fun cast(u: String) {
        val s = cur ?: return
        scope.launch { castUrl = withContext(Dispatchers.IO) { resolve(ctx, s, u) } }
    }
    fun toggleFav(kind: String, id: String, name: String, url: String, cover: String, isFav: Boolean) {
        val s = cur ?: return
        scope.launch(Dispatchers.IO) {
            if (isFav) store.del(s.id, kind, id) else store.add(Fav(subId = s.id, kind = kind, itemId = id, name = name, url = url, cover = cover))
        }
    }
    fun enqueue(reqs: List<DlReq>) {
        val s = cur ?: return
        Downloader.enqueue(ctx, s, reqs)
        Toast.makeText(ctx, ctx.getString(R.string.dl_added, reqs.size), Toast.LENGTH_SHORT).show()
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun proceedDownload(reqs: List<DlReq>) { if (prefs.getBoolean("dl_ok", false)) enqueue(reqs) else pending = reqs }
    // File access is asked for only when the user first taps download (never at app start); the download continues either way.
    fun askDownload(reqs: List<DlReq>) {
        if (!StoragePerm.has(ctx) && !prefs.getBoolean("perm_asked", false)) { permReqs = reqs; askPerm = true } else proceedDownload(reqs)
    }
    // Home: press Back twice to leave the app
    BackHandler(scr == S.Home) {
        val now = System.currentTimeMillis()
        if (now - lastBack < 2000) (ctx as? Activity)?.finish()
        else { lastBack = now; Toast.makeText(ctx, ctx.getString(R.string.press_again_exit), Toast.LENGTH_SHORT).show() }
    }
    BackHandler(scr != S.Home && scr != S.Player) { if (movie != null) movie = null else scr = S.Home }

    val pd = pending
    if (pd != null) AlertDialog(
        onDismissRequest = { pending = null },
        title = { Text(stringResource(R.string.dl_consent_title)) },
        text = { Text(stringResource(R.string.dl_consent_text)) },
        confirmButton = { TextButton(onClick = { prefs.edit().putBoolean("dl_ok", true).apply(); enqueue(pd); pending = null }) { Text(stringResource(R.string.accept)) } },
        dismissButton = { TextButton(onClick = { pending = null }) { Text(stringResource(R.string.cancel)) } })
    if (askPerm) {
        fun finish(request: Boolean) {
            prefs.edit().putBoolean("perm_asked", true).apply(); askPerm = false
            if (request) (ctx as? Activity)?.let { StoragePerm.request(it) }
            permReqs?.let { proceedDownload(it) }; permReqs = null
        }
        AlertDialog(
            onDismissRequest = { finish(false) },
            title = { Text(stringResource(R.string.perm_title)) },
            text = { Text(stringResource(R.string.perm_text)) },
            confirmButton = { TextButton(onClick = { finish(true) }) { Text(stringResource(R.string.perm_allow)) } },
            dismissButton = { TextButton(onClick = { finish(false) }) { Text(stringResource(R.string.perm_later)) } })
    }
    val cu = castUrl
    if (cu != null) CastSheet(cu) { castUrl = null }

    Surface(Modifier.fillMaxSize(), color = Bg, contentColor = Color.White) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0D1030), Bg)))) {
            if (mode.isEmpty()) ModeChooser { phone -> Ui.applyMode(prefs, phone); mode = if (phone) "phone" else "tv" }
            else if (scr == S.Player) key(stream) {
                val k = streamKey
                PlayerScreen(stream, streamTitle, startMs, { pos, len -> saveProgress(k, pos, len) }, { scr = back }, { castUrl = stream }, { nextUp?.invoke() }, onNext = nextBtn,
                    onRestart = { prefs.edit().remove("pos_" + k.hashCode()).remove("len_" + k.hashCode()).apply() })
            }
            else Crossfade(targetState = scr, animationSpec = tween(220), label = "page") { s ->
                when (s) {
                    S.Home -> Home({ series = null; movie = null; scr = it }, cur, added) { k, v -> if (k == "movie") { movie = v; scr = S.Movies } else { series = v; scr = S.Series } }
                    S.Live -> Live(cur, favLive.toSet(), { c -> play(c.url, c.name, "live", c.url, c.logo) },
                        { c -> toggleFav("live", c.url, c.name, c.url, c.logo, c.url in favLive) }, { scr = S.Home }, { scr = S.Add })
                    S.Movies -> {
                        Catalog("movie", cur, favMovie.toSet(), recents, { movie = it }, { resumeRecent(it) }, { scr = S.Home }, { scr = S.Add }, { r -> scope.launch(Dispatchers.IO) { store.delRecent(r.rk) } }, paused = movie != null)
                        val m = movie
                        if (m != null) MovieDialog(m, m.id in favMovie,
                            { play(m.url, m.name, "movie", m.id, m.cover); movie = null },
                            { toggleFav("movie", m.id, m.name, m.url, m.cover, m.id in favMovie) },
                            { askDownload(listOf(DlReq("${cur?.id ?: -1}|movie|${m.id}", "movie", m.name, m.name, m.cover, m.name, m.url, m.url.substringAfterLast('.'))))},
                            { shareText(ctx, m.name) },
                            { cast(m.url); movie = null },
                            { movie = null })
                    }
                    S.Series -> {
                        val sv = series
                        if (sv != null && cur != null) SeriesDetail(sv, cur, sv.id in favSeries,
                            { toggleFav("series", sv.id, sv.name, "", sv.cover, sv.id in favSeries) },
                            { e, all -> playEpisode(sv, e, all) },
                            { list -> askDownload(list.map { e ->
                                val label = "S%02d.E%02d".format(e.season, e.num)
                                DlReq("${cur.id}|ep|${e.id}", "episode", sv.name, label, sv.cover, sv.name + "_" + label, e.url, e.url.substringAfterLast('.'))
                            }) },
                            { shareText(ctx, sv.name) },
                            { e -> cast(e.url) },
                            { series = null })
                        else Catalog("series", cur, favSeries.toSet(), recents, { series = it }, { resumeRecent(it) }, { scr = S.Home }, { scr = S.Add }, { r -> scope.launch(Dispatchers.IO) { store.delRecent(r.rk) } })
                    }
                    S.Fav -> Favs(cur, store, { f -> play(f.url, f.name, f.kind, f.itemId, f.cover) },
                        { f -> series = Vod(f.itemId, f.name, f.cover, "", ""); scr = S.Series },
                        { f -> scope.launch(Dispatchers.IO) { store.del(f.subId, f.kind, f.itemId) } }, { scr = S.Home })
                    S.Search -> SearchScreen(cur, { c -> play(c.url, c.name, "live", c.url, c.logo) },
                        { v -> movie = v; scr = S.Movies }, { v -> series = v; scr = S.Series }) { scr = S.Home }
                    S.Matches -> MatchesScreen { scr = S.Home }
                    S.Add -> AddSub({ scr = S.Home }) { id -> lastAdded = id; scr = S.Switch }   // stay on the subscriptions screen until the user picks one
                    S.Switch -> SwitchSub(subs, active, { setActive(it); scr = S.Home }, { scr = S.Add }, { scr = S.Home },
                        { sb ->
                            scope.launch(Dispatchers.IO) { dao.del(sb); Secure.del(ctx, sb.id) }
                            if (sb.id == active) setActive(-1)
                        }, focusId = lastAdded)
                    S.Down -> Downloads(cur, store, { scr = S.Home }) { d ->
                        nextUp = null; nextBtn = null
                        begin(Downloader.playUri(d.path), if (d.kind == "movie") d.grp else d.grp + " " + d.title, d.path, false)
                    }
                    S.Settings -> Settings { scr = S.Home }
                    S.About -> About { scr = S.Home }
                    else -> Soon()
                }
            }
        }
    }
}

fun fmtTime(ms: Long): String {
    val t = ms / 1000; val h = t / 3600; val m = (t % 3600) / 60; val sec = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}
