package com.iptv.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Real IMDb ratings through the OMDb API (https://www.omdbapi.com, free key).
 * Results are cached on the device, including "not found", so every title is looked up once.
 */
object Imdb {
    private val sem = Semaphore(3)
    @Volatile private var badKey: String? = null

    private fun cache(c: Context) = c.getSharedPreferences("imdb", 0)
    fun apiKey(c: Context): String = c.getSharedPreferences("app", 0).getString("omdb_key", "")?.trim().orEmpty()

    /** Strips years, brackets, language prefixes and quality tags from provider titles. */
    fun clean(raw: String): Pair<String, String?> {
        val year = Regex("\\((\\d{4})\\)").find(raw)?.groupValues?.get(1)
            ?: Regex("\\b((?:19|20)\\d{2})\\s*$").find(raw)?.groupValues?.get(1)
        var s = raw.replace(Regex("\\[[^\\]]*\\]|\\([^)]*\\)"), " ")
        s = s.replace(Regex("^\\s*\\|?[A-Za-z]{2,3}\\|?\\s*[-:|]\\s*"), "")
        s = s.replace(Regex("(?i)\\b(4k|uhd|fhd|hd|hevc|1080p|720p|2160p|bluray|web-dl|multi|dubbed)\\b"), " ")
        s = s.replace(Regex("\\b(?:19|20)\\d{2}\\s*$"), "")
        s = s.replace(Regex("\\s*[-|:]\\s*$"), "").replace(Regex("\\s+"), " ").trim()
        return s to year
    }

    private fun ck(t: String, y: String?, series: Boolean) = (if (series) "s|" else "m|") + t.lowercase() + "|" + (y ?: "")

    /** Cached value: rating text, "" when the title has no IMDb rating, null when not looked up yet. */
    fun cached(c: Context, raw: String, series: Boolean): String? {
        val (t, y) = clean(raw)
        return cache(c).getString(ck(t, y, series), null)
    }

    private fun query(key: String, t: String, y: String?, series: Boolean): JSONObject {
        val u = "https://www.omdbapi.com/?apikey=" + URLEncoder.encode(key, "UTF-8") + "&t=" + URLEncoder.encode(t, "UTF-8") +
            "&type=" + (if (series) "series" else "movie") + (if (y != null) "&y=$y" else "")
        return JSONObject(Net.get(u))
    }

    /** Returns the IMDb rating (e.g. "7.8") or "" when unavailable. Network errors are not cached. */
    suspend fun rating(c: Context, raw: String, series: Boolean): String {
        val key = apiKey(c)
        if (key.isEmpty() || key == badKey) return ""
        val (t, y) = clean(raw)
        if (t.length < 2 || t.none { it in 'A'..'Z' || it in 'a'..'z' }) return ""   // OMDb only knows Latin titles
        val k = ck(t, y, series)
        cache(c).getString(k, null)?.let { return it }
        return sem.withPermit {
            withContext(Dispatchers.IO) {
                try {
                    var j = query(key, t, y, series)
                    if (j.optString("Response") != "True" && y != null) j = query(key, t, null, series)
                    if (j.optString("Error").contains("API key", true) || j.optString("Error").contains("limit", true)) {
                        if (j.optString("Error").contains("API key", true)) badKey = key
                        return@withContext ""
                    }
                    val r = if (j.optString("Response") == "True") j.optString("imdbRating").takeIf { it != "N/A" }.orEmpty() else ""
                    cache(c).edit().putString(k, r).apply()
                    r
                } catch (e: Exception) { "" }
            }
        }
    }
}
