package com.iptv.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Poster ratings. TMDB (built-in key) finds the title, Arabic titles included, and gives its rating ("T:7.5").
 * If the user also set a free OMDb key, the title's real IMDb rating is used instead ("I:7.8").
 * Results are cached on the device, including "not found" (""), so every title is looked up once.
 */
object Imdb {
    private const val TMDB_KEY = "bf1016b78d91df395a02611b11cdad4e"
    private val sem = Semaphore(3)
    @Volatile private var badOmdb: String? = null

    private fun cache(c: Context) = c.getSharedPreferences("ratings", 0)
    fun apiKey(c: Context): String = c.getSharedPreferences("app", 0).getString("omdb_key", "")?.trim().orEmpty()

    /** Strips years, brackets, language prefixes and quality tags from provider titles. */
    fun clean(raw: String): Pair<String, String?> {
        val year = Regex("\\((\\d{4})\\)").find(raw)?.groupValues?.get(1)
            ?: Regex("\\b((?:19|20)\\d{2})\\s*$").find(raw)?.groupValues?.get(1)
        var s = raw.replace(Regex("\\[[^\\]]*\\]|\\([^)]*\\)"), " ")
        s = s.replace(Regex("^\\s*\\|?[A-Za-z]{2,3}\\|?\\s*[-:|]\\s*"), "")
        s = s.replace(Regex("(?i)\\b(4k|uhd|fhd|hd|hevc|1080p|720p|2160p|bluray|web-dl|multi|dubbed)\\b"), " ")
        s = s.replace(Regex("\\b(?:19|20)\\d{2}\\s*$"), "")
        s = s.replace(Regex("\\s*[-|:]\\s*$"), "").replace(Regex("\\s+"), " ").trim()
        return s to year
    }

    private fun ck(c: Context, t: String, y: String?, series: Boolean) =
        (if (series) "s|" else "m|") + (if (apiKey(c).isEmpty()) "t|" else "i|") + t.lowercase() + "|" + (y ?: "")

    /** Cached value: "I:7.8" / "T:7.5", "" when nothing found, null when not looked up yet. */
    fun cached(c: Context, raw: String, series: Boolean): String? {
        val (t, y) = clean(raw)
        return cache(c).getString(ck(c, t, y, series), null)
    }

    private fun enc(x: String) = URLEncoder.encode(x, "UTF-8")

    /** Returns "I:x.x", "T:x.x" or "" when unavailable. Network errors are not cached. */
    suspend fun rating(c: Context, raw: String, series: Boolean): String {
        val (t, y) = clean(raw)
        if (t.length < 2) return ""
        val k = ck(c, t, y, series)
        cache(c).getString(k, null)?.let { return it }
        return sem.withPermit {
            withContext(Dispatchers.IO) {
                try {
                    val kind = if (series) "tv" else "movie"
                    fun search(year: String?): JSONObject? {
                        val u = "https://api.themoviedb.org/3/search/$kind?api_key=$TMDB_KEY&language=en-US&query=${enc(t)}" +
                            (if (year != null) (if (series) "&first_air_date_year=$year" else "&year=$year") else "")
                        return JSONObject(Net.get(u)).optJSONArray("results")?.optJSONObject(0)
                    }
                    val hit = search(y) ?: (if (y != null) search(null) else null)
                    var out = ""
                    if (hit != null) {
                        val omdb = apiKey(c)
                        if (omdb.isNotEmpty() && omdb != badOmdb) {
                            try {
                                val imdbId = JSONObject(Net.get("https://api.themoviedb.org/3/$kind/${hit.optInt("id")}/external_ids?api_key=$TMDB_KEY")).optString("imdb_id")
                                if (imdbId.startsWith("tt")) {
                                    val j = JSONObject(Net.get("https://www.omdbapi.com/?apikey=${enc(omdb)}&i=$imdbId"))
                                    if (j.optString("Error").contains("API key", true)) badOmdb = omdb
                                    val r = j.optString("imdbRating")
                                    if (j.optString("Response") == "True" && r != "N/A" && r.isNotBlank()) out = "I:$r"
                                }
                            } catch (_: Exception) { }
                        }
                        if (out.isEmpty()) {
                            val v = hit.optDouble("vote_average", 0.0)
                            if (v > 0 && hit.optInt("vote_count", 0) > 0) out = "T:" + String.format(java.util.Locale.US, "%.1f", v)
                        }
                    }
                    cache(c).edit().putString(k, out).apply()
                    out
                } catch (e: Exception) { "" }
            }
        }
    }
}
