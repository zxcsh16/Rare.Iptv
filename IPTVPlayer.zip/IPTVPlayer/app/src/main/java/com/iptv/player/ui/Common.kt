package com.iptv.player.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Date
import com.iptv.player.R

val Bg = Color(0xFF080B1A); val Side = Color(0xFF14172E); val Pri = Color(0xFF7925F5)
val Sec = Color(0xFF1264E8); val Acc = Color(0xFFB34BFF); val Ok = Color(0xFF16C784)
val Err = Color(0xFFF04452); val Dim = Color(0xFFB8BCD0)
val Grad = Brush.horizontalGradient(listOf(Pri, Acc))

enum class S { Home, Live, Movies, Series, Fav, Matches, Down, Switch, Settings, About, Add, Player }

/** User-adjustable look (saved in preferences, applied app-wide). */
object Ui {
    var fontScale by mutableFloatStateOf(1f)
    var barH by mutableIntStateOf(52)
}

@Composable fun IptvTheme(c: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Pri, secondary = Sec, tertiary = Acc, background = Bg, surface = Side, error = Err),
    content = c)

/** Focusable, clickable card with spring press/focus motion and a purple glow on D-pad focus. */
@Composable fun Fx(onClick: () -> Unit, modifier: Modifier = Modifier, brush: Brush? = null, flat: Boolean = false, pad: Dp = 14.dp,
                   round: Boolean = false, content: @Composable BoxScope.() -> Unit) {
    var f by remember { mutableStateOf(false) }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.94f else if (f) 1.06f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "fx")
    val bw by animateDpAsState(if (f) 3.dp else 0.dp, label = "bw")
    val sh = if (round) CircleShape else RoundedCornerShape(18.dp)
    Box(modifier.onFocusChanged { f = it.isFocused }
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .shadow(if (f) 14.dp else 0.dp, sh, ambientColor = Acc, spotColor = Acc)
        .border(bw, Acc, sh).clip(sh)
        .background(brush ?: SolidColor(if (flat) Color.Transparent else Color.White.copy(.08f)))
        .clickable(interactionSource = src, indication = null, onClick = onClick).padding(pad), content = content)
}

@Composable fun PulseIcon(ic: ImageVector, size: Dp, tint: Color = Color.White) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(1f, 1.16f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    Icon(ic, null, Modifier.size(size).graphicsLayer { scaleX = s; scaleY = s }, tint = tint)
}

@Composable fun FloatIcon(ic: ImageVector, size: Dp, tint: Color = Color.White) {
    val t = rememberInfiniteTransition(label = "float")
    val dy by t.animateFloat(-2.5f, 2.5f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy")
    Icon(ic, null, Modifier.size(size).graphicsLayer { translationY = dy * density }, tint = tint)
}

@Composable fun Avatar(t: String, size: Dp, glow: Boolean = false) {
    Box(Modifier.size(size).then(if (glow) Modifier.border(3.dp, Acc, CircleShape) else Modifier).clip(CircleShape)
        .background(Brush.linearGradient(listOf(Pri, Sec))), contentAlignment = Alignment.Center) {
        Text(t.take(1).uppercase(), fontSize = (size.value / 2.4f).sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable fun BackBtn(onBack: () -> Unit) = Fx(onBack, pad = 8.dp) { Icon(Icons.Filled.ArrowBack, null) }

@Composable fun StatusBadge(expired: Boolean, text: String) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(if (expired) Color(0xFF7A1F2A) else Color(0xFF0E6B3A)).padding(horizontal = 6.dp, vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Icon(if (expired) Icons.Filled.Close else Icons.Filled.Check, null, Modifier.size(9.dp), tint = Color.White)
        Text(text, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}

/** Device time (follows the phone's 12/24h setting). */
@Composable fun ClockText(size: TextUnit = 13.sp, modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val fmt = remember { android.text.format.DateFormat.getTimeFormat(ctx) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(15000) } }
    Text(fmt.format(Date(now)), fontSize = size, fontWeight = FontWeight.SemiBold, modifier = modifier)
}

/** Home navigation row: logo + name, subscription chip (arrow switches subscriptions), shortcuts, clock. */
@Composable fun TopBar(name: String, status: String, expired: Boolean, hasSub: Boolean, onSwitch: () -> Unit, go: (S) -> Unit) {
    val h = Ui.barH.dp
    val navs = listOf(
        Triple(S.Home, Icons.Filled.Home, R.string.home), Triple(S.Matches, Icons.Filled.SportsSoccer, R.string.matches),
        Triple(S.Down, Icons.Filled.Download, R.string.down), Triple(S.Settings, Icons.Filled.Settings, R.string.settings),
        Triple(S.About, Icons.Filled.Info, R.string.about))
    Row(Modifier.fillMaxWidth().height(h), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(h - 14.dp))
        Text("Rare iptv", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Fx(onSwitch, pad = 4.dp) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box {
                    Avatar(name, h - 22.dp, true)
                    Text("👑", fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomEnd))
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Icon(Icons.Filled.KeyboardArrowDown, null, Modifier.size(16.dp), tint = Dim)
                    }
                    if (hasSub) StatusBadge(expired, status)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        navs.forEach { (k, ic, l) ->
            val on = k == S.Home
            Fx({ go(k) }, brush = if (on) Grad else null, flat = true, pad = 4.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(ic, null, Modifier.size(18.dp), tint = if (on) Color.White else Dim)
                    Text(stringResource(l), fontSize = 9.sp, color = if (on) Color.White else Dim, maxLines = 1)
                }
            }
        }
        ClockText()
    }
}
