package com.iptv.player.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Date
import com.iptv.player.R

val Bg = Color(0xFF080B1A); val Side = Color(0xFF14172E); val Pri = Color(0xFF7925F5)
val Sec = Color(0xFF1264E8); val Acc = Color(0xFFB34BFF); val Ok = Color(0xFF16C784)
val Err = Color(0xFFF04452); val Dim = Color(0xFFB8BCD0)
val Grad = Brush.horizontalGradient(listOf(Pri, Acc))

enum class S { Home, Live, Movies, Series, Fav, Matches, Down, Switch, Settings, About, Add, Player, Search }

/** User-adjustable look (saved in preferences, applied app-wide). */
object Ui {
    var fontScale by mutableFloatStateOf(1f)
    var barH by mutableIntStateOf(52)
    /** true when the user picked "Phone" at first launch (compact layout). */
    var phone by mutableStateOf(false)
    /** Performance mode: no endless decorative animations (lighter on TV boxes). */
    var lite by mutableStateOf(false)
    /** Home slideshow moves by itself. Phone: on (default). TV: off by default, switched with the remote's Left / Right keys. */
    var slideAuto by mutableStateOf(true)

    /** Phone => Small font + Small top bar. TV => default settings. */
    fun applyMode(p: android.content.SharedPreferences, phoneMode: Boolean) {
        phone = phoneMode
        fontScale = if (phoneMode) 0.85f else 1f
        barH = if (phoneMode) 44 else 52
        // first choice only: phone => animations / motion ON, TV => performance mode. A later manual choice is kept.
        if (!p.contains("slide_auto")) { slideAuto = phoneMode; p.edit().putBoolean("slide_auto", slideAuto).apply() }
        if (!p.contains("lite")) { lite = !phoneMode; p.edit().putBoolean("lite", lite).apply() }
        p.edit().putString("mode", if (phoneMode) "phone" else "tv")
            .putFloat("font_scale", fontScale).putInt("bar_h", barH).apply()
    }
}

@Composable fun IptvTheme(c: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Pri, secondary = Sec, tertiary = Acc, background = Bg, surface = Side, error = Err),
    content = c)

/** Remembers which focus targets really hold the remote cursor (a plain requestFocus() can silently do nothing). */
object FocusMap {
    private val m = java.util.WeakHashMap<FocusRequester, Boolean>()
    fun set(f: FocusRequester, v: Boolean) { m[f] = v }
    fun has(f: FocusRequester): Boolean = m[f] == true
}

/**
 * Moves the remote cursor onto this element and keeps trying until it REALLY holds it: the element may not be on screen yet,
 * a dialog window may still be taking the focus (that is what left the cursor on the first button), or a list may still be scrolling.
 * [prep] runs before every try (e.g. scroll the wanted item into view). Returns true when the cursor is there.
 */
suspend fun FocusRequester.acquire(first: Long = 200, tries: Int = 28, gap: Long = 130, prep: suspend () -> Unit = {}): Boolean {
    delay(first)
    var stable = 0
    for (i in 0 until tries) {
        try { prep() } catch (_: Exception) { }
        if (FocusMap.has(this)) { stable++; if (stable >= 2) return true }   // held for two checks in a row: done
        else { stable = 0; try { requestFocus() } catch (_: Exception) { } }
        delay(gap)
    }
    return FocusMap.has(this)
}

/** Moves the remote cursor to [fr] shortly after a page / dialog opens (retries until it is really there). */
@Composable fun AutoFocus(fr: FocusRequester, key: Any? = Unit, enabled: Boolean = true, ms: Long = 250) {
    LaunchedEffect(key, enabled) { if (enabled) fr.acquire(first = ms) }
}
@Composable fun rememberFocusReq(): FocusRequester = remember { FocusRequester() }
fun Modifier.focusIf(on: Boolean, fr: FocusRequester): Modifier =
    if (on) this.focusRequester(fr).onFocusChanged { FocusMap.set(fr, it.isFocused) } else this

/** Focusable, clickable card with spring press/focus motion and a purple glow on D-pad focus. */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable fun Fx(onClick: () -> Unit, modifier: Modifier = Modifier, brush: Brush? = null, flat: Boolean = false, pad: Dp = 14.dp,
                   round: Boolean = false, onLong: (() -> Unit)? = null, content: @Composable BoxScope.() -> Unit) {
    var f by remember { mutableStateOf(false) }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.94f else if (f) 1.06f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "fx")
    val bw by animateDpAsState(if (f) 3.dp else 0.dp, label = "bw")
    val sh = if (round) CircleShape else RoundedCornerShape(18.dp)
    Box(modifier.onFocusChanged { f = it.isFocused }
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .shadow(if (f) 14.dp else 0.dp, sh, ambientColor = Acc, spotColor = Acc)
        .border(bw, Acc, sh).clip(sh)
        .background(brush ?: SolidColor(if (flat) Color.Transparent else Color.White.copy(.08f)))
        .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLong).padding(pad), content = content)
}

@Composable fun PulseIcon(ic: ImageVector, size: Dp, tint: Color = Color.White) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(1f, 1.16f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    Icon(ic, null, Modifier.size(size).graphicsLayer { scaleX = s; scaleY = s }, tint = tint)
}

@Composable fun FloatIcon(ic: ImageVector, size: Dp, tint: Color = Color.White) {
    if (Ui.lite) { Icon(ic, null, Modifier.size(size), tint = tint); return }   // performance mode: icon stays still
    val t = rememberInfiniteTransition(label = "float")
    val dy by t.animateFloat(-2.5f, 2.5f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy")
    Icon(ic, null, Modifier.size(size).graphicsLayer { translationY = dy * density }, tint = tint)
}

@Composable fun Avatar(t: String, size: Dp, glow: Boolean = false) {
    Box(Modifier.size(size).then(if (glow) Modifier.border(3.dp, Acc, CircleShape) else Modifier).clip(CircleShape)
        .background(Brush.linearGradient(listOf(Pri, Sec))), contentAlignment = Alignment.Center) {
        Text(t.take(1).uppercase(), fontSize = (size.value / 2.4f).sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable fun BackBtn(onBack: () -> Unit, modifier: Modifier = Modifier) = Fx(onBack, modifier, pad = 8.dp) { Icon(Icons.Filled.ArrowBack, null) }

@Composable fun StatusBadge(expired: Boolean, text: String) {
    val c = if (expired) Err else Ok
    val a: Float
    if (Ui.lite) a = 1f else {
        val t = rememberInfiniteTransition(label = "badge")
        val av by t.animateFloat(1f, 0.3f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
        a = av
    }
    val sh = RoundedCornerShape(50)
    Row(Modifier.clip(sh).background(c.copy(.16f)).border(1.dp, c.copy(.55f), sh).padding(horizontal = 7.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(6.dp).graphicsLayer { alpha = if (expired) 1f else a }.clip(CircleShape).background(c))
        Text(text, fontSize = 9.sp, lineHeight = 11.sp, fontWeight = FontWeight.SemiBold, color = c, maxLines = 1)
    }
}

/** Animated "Rare iptv" wordmark: shimmering gradient, soft glow and a springy entrance. */
@Composable fun BrandTitle(size: TextUnit, modifier: Modifier = Modifier) {
    val x: Float; val glow: Float
    if (Ui.lite) { x = 120f; glow = 14f } else {   // performance mode keeps the wordmark static (no per-frame text redraw)
        val t = rememberInfiniteTransition(label = "brand")
        val xs by t.animateFloat(0f, 600f, infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Restart), label = "x")
        val gs by t.animateFloat(8f, 20f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
        x = xs; glow = gs
    }
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 120f)) }
    val shimmer = Brush.linearGradient(listOf(Color.White, Color(0xFFD9B3FF), Color(0xFF7FB2FF)),
        start = Offset(x, 0f), end = Offset(x + 300f, 0f), tileMode = TileMode.Mirror)
    val accent = Brush.horizontalGradient(listOf(Acc, Sec))
    Row(modifier.graphicsLayer {
        val e = enter.value
        scaleX = 0.7f + 0.3f * e; scaleY = 0.7f + 0.3f * e; alpha = e.coerceIn(0f, 1f)
    }, verticalAlignment = Alignment.CenterVertically) {
        Text("Rare", style = TextStyle(brush = shimmer, fontSize = size, fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic,
            letterSpacing = 0.5.sp, shadow = Shadow(Acc.copy(.75f), Offset.Zero, glow)), maxLines = 1)
        Spacer(Modifier.width((size.value * 0.22f).dp))
        Text("iptv", style = TextStyle(brush = accent, fontSize = size, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic,
            letterSpacing = 1.sp, shadow = Shadow(Sec.copy(.7f), Offset.Zero, glow)), maxLines = 1)
    }
}

/** Device time (follows the phone's 12/24h setting) with the weekday and date beside it. */
@Composable fun ClockText(size: TextUnit = 13.sp, modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val fmt = remember { android.text.format.DateFormat.getTimeFormat(ctx) }
    val dayFmt = remember { java.text.SimpleDateFormat("EEEE", java.util.Locale.getDefault()) }
    val dateFmt = remember { java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault()) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(15000) } }
    val d = Date(now)
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(horizontalAlignment = Alignment.End) {
            Text(dayFmt.format(d), fontSize = (size.value - 3).sp, lineHeight = (size.value - 1).sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
            Text(dateFmt.format(d), fontSize = (size.value - 4).sp, lineHeight = (size.value - 2).sp, color = Dim, maxLines = 1, softWrap = false)
        }
        Box(Modifier.width(1.dp).height((size.value + 6).dp).background(Color.White.copy(.25f)))
        Text(fmt.format(d), fontSize = size, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
    }
}

/** Home navigation: brand + subscription chip on the left, a floating animated nav pill in the true center, clock on the right. */
/** Remote control: pressing Down from this element goes to [fr] (when given). */
fun Modifier.focusDownTo(fr: FocusRequester?): Modifier = if (fr == null) this else this.focusProperties { down = fr }

@Composable fun TopBar(name: String, status: String, expired: Boolean, hasSub: Boolean, onSwitch: () -> Unit, go: (S) -> Unit,
                       downTo: FocusRequester? = null, homeFocus: FocusRequester? = null) {
    val h = Ui.barH.dp
    val navs = listOf(
        Triple(S.Home, Icons.Filled.Home, R.string.home), Triple(S.Search, Icons.Filled.Search, R.string.search_all), Triple(S.Down, Icons.Filled.Download, R.string.down),
        Triple(S.Settings, Icons.Filled.Settings, R.string.settings))
    var sel by remember { mutableIntStateOf(0) }
    val itemW = if (Ui.phone) 50.dp else 58.dp
    val itemH = h - 8.dp
    val ind by animateDpAsState(itemW * sel, spring(dampingRatio = 0.6f, stiffness = 380f), label = "ind")
    val gl: Float
    if (Ui.lite) gl = 10f else {
        val t = rememberInfiniteTransition(label = "navglow")
        val g by t.animateFloat(6f, 16f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "gl")
        gl = g
    }
    val pill = RoundedCornerShape(50)

    Box(Modifier.fillMaxWidth().height(h)) {
        Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(h - 12.dp))
            BrandTitle(if (Ui.phone) 15.sp else 18.sp)
            Fx(onSwitch, Modifier.height(h).focusDownTo(downTo), pad = 4.dp) {
                Row(Modifier.fillMaxHeight(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box {
                        Avatar(name, h - 22.dp, true)
                        Text("👑", fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomEnd).offset(x = 3.dp, y = 2.dp))
                    }
                    Column(verticalArrangement = Arrangement.Center) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.widthIn(max = 90.dp))
                            Icon(Icons.Filled.KeyboardArrowDown, null, Modifier.size(14.dp), tint = Dim)
                        }
                        if (hasSub) { Spacer(Modifier.height(2.dp)); StatusBadge(expired, status) }
                    }
                }
            }
        }
        Box(Modifier.align(Alignment.Center).shadow(10.dp, pill, ambientColor = Acc.copy(.45f), spotColor = Acc.copy(.45f))
            .clip(pill).background(Brush.verticalGradient(listOf(Color.White.copy(.13f), Color.White.copy(.05f))))
            .border(1.dp, Brush.horizontalGradient(listOf(Acc.copy(.75f), Sec.copy(.75f))), pill).padding(3.dp)) {
            Box(Modifier.offset(x = ind).size(itemW, itemH).shadow(gl.dp, RoundedCornerShape(20.dp), ambientColor = Acc, spotColor = Acc)
                .clip(RoundedCornerShape(20.dp)).background(Grad))
            Row {
                navs.forEachIndexed { i, (k, ic, l) ->
                    val src = remember { MutableInteractionSource() }
                    val pressed by src.collectIsPressedAsState()
                    val on = sel == i
                    val sc by animateFloatAsState(if (pressed) 0.86f else if (on) 1.14f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "ni")
                    Column(Modifier.size(itemW, itemH).clip(RoundedCornerShape(20.dp))
                        .onFocusChanged { if (it.isFocused) sel = i }
                        .focusDownTo(downTo)
                        .then(if (i == 0 && homeFocus != null) Modifier.focusRequester(homeFocus) else Modifier)
                        .clickable(interactionSource = src, indication = null) { sel = i; go(k) },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(ic, null, Modifier.size(if (Ui.phone) 17.dp else 19.dp).graphicsLayer { scaleX = sc; scaleY = sc }, tint = if (on) Color.White else Dim)
                        Text(stringResource(l), fontSize = 9.sp, lineHeight = 10.sp, color = if (on) Color.White else Dim, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
        ClockText(modifier = Modifier.align(Alignment.CenterEnd))
    }
}
