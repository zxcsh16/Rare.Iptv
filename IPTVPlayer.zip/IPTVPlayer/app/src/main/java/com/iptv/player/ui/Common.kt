package com.iptv.player.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iptv.player.R

val Bg = Color(0xFF080B1A); val Side = Color(0xFF14172E); val Pri = Color(0xFF7925F5)
val Sec = Color(0xFF1264E8); val Acc = Color(0xFFB34BFF); val Ok = Color(0xFF16C784)
val Err = Color(0xFFF04452); val Dim = Color(0xFFB8BCD0)
val Grad = Brush.horizontalGradient(listOf(Pri, Acc))

enum class S { Home, Live, Movies, Series, Fav, Down, Switch, Settings, About, Add, Player }

@Composable fun IptvTheme(c: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Pri, secondary = Sec, tertiary = Acc, background = Bg, surface = Side, error = Err),
    content = c)

/** Focusable, clickable card: purple glow border on D-pad focus. */
@Composable fun Fx(onClick: () -> Unit, modifier: Modifier = Modifier, brush: Brush? = null, flat: Boolean = false, pad: Dp = 14.dp,
                   content: @Composable BoxScope.() -> Unit) {
    var f by remember { mutableStateOf(false) }
    val sh = RoundedCornerShape(18.dp)
    Box(modifier.onFocusChanged { f = it.isFocused }.scale(if (f) 1.04f else 1f)
        .border(if (f) 3.dp else 0.dp, Acc, sh).clip(sh)
        .background(brush ?: SolidColor(if (flat) Color.Transparent else Color.White.copy(.08f)))
        .clickable(onClick = onClick).padding(pad), content = content)
}

@Composable fun Avatar(t: String, size: Dp, glow: Boolean = false) {
    Box(Modifier.size(size).then(if (glow) Modifier.border(3.dp, Acc, CircleShape) else Modifier).clip(CircleShape)
        .background(Brush.linearGradient(listOf(Pri, Sec))), contentAlignment = Alignment.Center) {
        Text(t.take(1).uppercase(), fontSize = (size.value / 2.4f).sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable fun BackBtn(onBack: () -> Unit) = Fx(onBack, pad = 8.dp) { Icon(Icons.Filled.ArrowBack, null) }

@Composable fun Sidebar(sel: S, compact: Boolean, name: String, status: String, good: Boolean, go: (S) -> Unit) {
    val items = listOf(
        Triple(S.Home, Icons.Filled.Home, R.string.home), Triple(S.Down, Icons.Filled.Download, R.string.down),
        Triple(S.Switch, Icons.Filled.SwapHoriz, R.string.switch_sub), Triple(S.Settings, Icons.Filled.Settings, R.string.settings),
        Triple(S.About, Icons.Filled.Info, R.string.about))
    BoxWithConstraints(Modifier.width(if (compact) 60.dp else 112.dp).fillMaxHeight().background(Side)) {
        val ih = ((maxHeight - 120.dp) / items.size - 3.dp).coerceIn(40.dp, 62.dp)
        Column(Modifier.fillMaxSize().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("IPTV", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Acc)
            Avatar(name, 34.dp, true)
            if (!compact) {
                Text(name, fontSize = 10.sp, maxLines = 1, fontWeight = FontWeight.SemiBold)
                Text(status, color = if (good) Ok else Err, fontSize = 9.sp)
            }
            Spacer(Modifier.height(2.dp))
            items.forEach { (k, ic, l) ->
                val on = k == sel
                Fx({ go(k) }, Modifier.fillMaxWidth().height(ih), brush = if (on) Grad else null, flat = true, pad = 2.dp) {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(ic, stringResource(l), Modifier.size(20.dp), tint = if (on) Color.White else Dim)
                        if (!compact) Text(stringResource(l), color = if (on) Color.White else Dim, fontSize = 9.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 10.sp)
                    }
                }
            }
        }
    }
}
