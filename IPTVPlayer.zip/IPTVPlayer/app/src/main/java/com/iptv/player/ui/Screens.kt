package com.iptv.player.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date

private class Cat(val s: S, val ic: ImageVector, val t: Int, val d: Int, val b: Brush)
private fun g(a: Long, b: Long) = Brush.linearGradient(listOf(Color(a), Color(b)))

@Composable fun Home(go: (S) -> Unit, compact: Boolean, recents: List<Recent>, added: List<Pair<String, Vod>>,
                     onRecent: (Recent) -> Unit, onAdded: (String, Vod) -> Unit) {
    val cats = listOf(
        Cat(S.Live, Icons.Filled.Tv, R.string.live, R.string.live_sub, g(0xFF7925F5, 0xFF4A1CB0)),
        Cat(S.Movies, Icons.Filled.Movie, R.string.movies, R.string.movies_sub, g(0xFF1264E8, 0xFF0B3F9A)),
        Cat(S.Series, Icons.Filled.VideoLibrary, R.string.series, R.string.series_sub, g(0xFF16A869, 0xFF0B6B4A)),
        Cat(S.Fav, Icons.Filled.Star, R.string.fav, R.string.fav_sub, g(0xFFF59E0B, 0xFFD97706)))
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Pri, Sec))).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.width(110.dp)) {
                Text("IPTV", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic)
                Text(stringResource(R.string.recently_added), fontSize = 10.sp, color = Color(0xFFE6D9FF))
            }
            val st = rememberLazyListState()
            LaunchedEffect(added.size) {
                if (added.size > 1) {
                    var i = 0
                    while (true) { delay(2500); i = (i + 1) % added.size; st.animateScrollToItem(i) }
                }
            }
            LazyRow(Modifier.weight(1f).fillMaxHeight(), state = st, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(added) { p ->
                    Fx({ onAdded(p.first, p.second) }, pad = 0.dp) {
                        AsyncImage(p.second.cover, null, Modifier.fillMaxHeight().aspectRatio(0.68f), contentScale = ContentScale.Crop)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().weight(1.3f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            cats.forEach { c ->
                Fx({ go(c.s) }, Modifier.weight(1f).fillMaxHeight(), brush = c.b, pad = 8.dp) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(c.ic, null, Modifier.size(36.dp))
                        Text(stringResource(c.t).uppercase(), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(stringResource(c.d), fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(stringResource(R.string.recently), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            if (recents.isEmpty()) Text(stringResource(R.string.nothing_yet), color = Dim, fontSize = 12.sp, modifier = Modifier.height(78.dp))
            else LazyRow(Modifier.height(78.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recents, key = { it.rk }) { r ->
                    Fx({ onRecent(r) }, pad = 0.dp) {
                        if (r.cover.isNotBlank()) AsyncImage(r.cover, null, Modifier.fillMaxHeight().aspectRatio(0.68f), contentScale = ContentScale.Crop)
                        else Box(Modifier.fillMaxHeight().width(54.dp), Alignment.Center) { Text(r.name, fontSize = 9.sp, maxLines = 3, textAlign = TextAlign.Center) }
                    }
                }
            }
        }
    }
}

@Composable fun AddSub(onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { Db.get(ctx).dao() }
    var type by remember { mutableStateOf("xtream") }
    var name by remember { mutableStateOf("") }; var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }; var ok by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            url = uri.toString()
        }
    }
    val types = listOf(
        Triple("xtream", "Xtream Code", g(0xFF7925F5, 0xFF4A1CB0)), Triple("m3u", "M3U URL / File", g(0xFF1264E8, 0xFF0B3F9A)),
        Triple("stalker", "Stalker MAC", g(0xFF16A869, 0xFF0B6B4A)), Triple("single", "Single URL", g(0xFFF59E0B, 0xFFD97706)))

    fun check(): String? {
        if (name.isBlank()) return ctx.getString(R.string.e_name)
        val u = url.trim()
        if (!(u.startsWith("http://") || u.startsWith("https://") || (type == "m3u" && u.startsWith("content:")))) return ctx.getString(R.string.e_url)
        if (type == "xtream" && (user.isBlank() || pass.isBlank())) return ctx.getString(R.string.e_cred)
        if (type == "stalker" && !Regex("(?i)^([0-9a-f]{2}:){5}[0-9a-f]{2}$").matches(user.trim())) return ctx.getString(R.string.e_mac)
        return null
    }
    fun submit() {
        val e = check()
        if (e != null) { msg = e; ok = false; return }
        scope.launch {
            busy = true; msg = null
            try {
                val exp = withContext(Dispatchers.IO) {
                    when (type) {
                        "xtream" -> Net.xtreamLogin(url.trim(), user.trim(), pass)
                        "m3u" -> { require(Net.m3u(ctx, url.trim()).isNotEmpty()); 0L }
                        else -> 0L
                    }
                }
                val id = withContext(Dispatchers.IO) { dao.add(Sub(name = name.trim(), type = type, url = url.trim(), user = user.trim(), expTs = exp)) }
                if (type == "xtream") withContext(Dispatchers.IO) { Secure.put(ctx, id, pass) }
                ok = true; msg = ctx.getString(R.string.saved); onSaved(id)
            } catch (ex: Exception) { ok = false; msg = ex.message ?: ctx.getString(R.string.e_conn) }
            busy = false
        }
    }

    @Composable fun TC(t: Triple<String, String, Brush>, m: Modifier) {
        Fx({ type = t.first; msg = null }, m, brush = if (type == t.first) t.third else null, pad = 8.dp) {
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Text(t.second, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                if (type == t.first) { Spacer(Modifier.weight(1f)); Icon(Icons.Filled.Check, null) }
            }
        }
    }
    @Composable fun F(v: String, on: (String) -> Unit, label: Int, m: Modifier, pw: Boolean = false) {
        OutlinedTextField(v, on, m, singleLine = true, label = { Text(stringResource(label), maxLines = 1) },
            visualTransformation = if (pw) PasswordVisualTransformation() else VisualTransformation.None)
    }
    @Composable fun Two(wide: Boolean, a: @Composable (Modifier) -> Unit, b: @Composable (Modifier) -> Unit) {
        if (wide) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { a(Modifier.weight(1f)); b(Modifier.weight(1f)) }
        else Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) { a(Modifier.fillMaxWidth()); b(Modifier.fillMaxWidth()) }
    }
    @Composable fun Form(wide: Boolean) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val urlL = when (type) { "xtream" -> R.string.f_server; "m3u" -> R.string.f_m3u; "stalker" -> R.string.f_portal; else -> R.string.f_stream }
            Two(wide, { m -> F(name, { name = it }, R.string.f_name, m) }, { m -> F(url, { url = it }, urlL, m) })
            when (type) {
                "xtream" -> Two(wide, { m -> F(user, { user = it }, R.string.f_user, m) }, { m -> F(pass, { pass = it }, R.string.f_pass, m, true) })
                "stalker" -> F(user, { user = it }, R.string.f_mac, Modifier.fillMaxWidth())
                "m3u" -> Fx({ pick.launch(arrayOf("*/*")) }, pad = 8.dp) { Text(stringResource(R.string.f_pick)) }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Fx({ if (!busy) submit() }, brush = Grad, pad = 10.dp) {
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text(stringResource(R.string.connect), fontWeight = FontWeight.Bold)
                }
                msg?.let { Text(it, color = if (ok) Ok else Err, fontSize = 13.sp, modifier = Modifier.weight(1f)) }
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (maxWidth >= 440.dp) Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(0.8f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { BackBtn(onBack); Text(stringResource(R.string.add_sub), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                types.forEach { TC(it, Modifier.fillMaxWidth().weight(1f)) }
            }
            Column(Modifier.weight(1.4f).fillMaxHeight(), verticalArrangement = Arrangement.Center) { Form(true) }
        } else Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { BackBtn(onBack); Text(stringResource(R.string.add_sub), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            types.chunked(2).forEach { r ->
                Row(Modifier.fillMaxWidth().height(52.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    r.forEach { TC(it, Modifier.weight(1f).fillMaxHeight()) }
                }
            }
            Form(false)
        }
    }
}

@Composable fun SwitchSub(subs: List<Sub>, active: Long, onSwitch: (Long) -> Unit, onAdd: () -> Unit, onBack: () -> Unit, onDelete: (Sub) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sel by remember(active) { mutableLongStateOf(active) }
    var dlg by remember { mutableIntStateOf(0) }
    var pw by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<Uri?>(null) }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy") }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            val msg = try {
                withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(Backup.export(ctx, subs, pw.toCharArray())) } }
                ctx.getString(R.string.bk_done)
            } catch (e: Exception) { ctx.getString(R.string.bk_bad) }
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
        }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) { picked = uri; pw = ""; dlg = 2 } }
    fun doImport() {
        val u = picked ?: return
        scope.launch {
            val msg = try {
                val r = withContext(Dispatchers.IO) { Backup.import(ctx, ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }, pw.toCharArray()) }
                if (active < 0 && r.second > 0) onSwitch(r.second)
                ctx.getString(R.string.bk_imported, r.first)
            } catch (e: Exception) { ctx.getString(R.string.bk_bad) }
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
        }
    }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            Text(stringResource(R.string.switch_sub), fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Fx({ if (subs.isNotEmpty()) { pw = ""; dlg = 1 } }, pad = 8.dp) { Text(stringResource(R.string.bk_export), fontSize = 12.sp) }
            Fx({ importL.launch(arrayOf("*/*")) }, pad = 8.dp) { Text(stringResource(R.string.bk_import), fontSize = 12.sp) }
        }
        if (subs.isEmpty()) Box(Modifier.weight(1f)) { Text(stringResource(R.string.no_active), color = Dim) }
        else LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(subs, key = { it.id }) { s ->
                Fx({ sel = s.id }, Modifier.width(170.dp).fillMaxHeight(), pad = 8.dp) {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Avatar(s.name, 64.dp, s.id == active)
                        Spacer(Modifier.height(6.dp))
                        Text(s.name, fontWeight = FontWeight.Bold, maxLines = 1, fontSize = 14.sp)
                        Text(s.type.uppercase(), color = Sec, fontSize = 11.sp)
                        Text(stringResource(if (s.expired()) R.string.expired else R.string.active), color = if (s.expired()) Err else Ok, fontSize = 12.sp)
                        Text(if (s.expTs > 0) stringResource(R.string.expires) + " " + fmt.format(Date(s.expTs * 1000)) else stringResource(R.string.no_exp), color = Dim, fontSize = 11.sp)
                        if (s.id == sel) Text(stringResource(R.string.selected), color = Acc, fontSize = 12.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Fx({ if (sel > 0) onSwitch(sel) }, brush = Grad, pad = 10.dp) { Text(stringResource(R.string.switch_btn), fontWeight = FontWeight.Bold) }
            Fx(onAdd, pad = 10.dp) { Text(stringResource(R.string.add_new), maxLines = 1) }
            Fx({ subs.find { it.id == sel }?.let(onDelete) }, pad = 10.dp) { Text(stringResource(R.string.delete), color = Err) }
        }
    }
    if (dlg != 0) AlertDialog(
        onDismissRequest = { dlg = 0 },
        title = { Text(stringResource(R.string.bk_pass_title)) },
        text = { OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(stringResource(R.string.bk_pass)) }) },
        confirmButton = {
            TextButton(onClick = {
                if (pw.length >= 4) {
                    if (dlg == 1) exportL.launch("iptv-backup.iptvbk") else doImport()
                    dlg = 0
                }
            }) { Text(stringResource(R.string.accept)) }
        },
        dismissButton = { TextButton(onClick = { dlg = 0 }) { Text(stringResource(R.string.cancel)) } })
}

@Composable fun Soon() = Box(Modifier.fillMaxSize(), Alignment.Center) { Text(stringResource(R.string.soon), color = Dim, fontSize = 18.sp) }

@Composable fun PlayerScreen(url: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var err by remember { mutableStateOf<String?>(null) }
    val p = remember(url) { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true } }
    DisposableEffect(p) {
        val l = object : Player.Listener { override fun onPlayerError(e: PlaybackException) { err = e.errorCodeName } }
        p.addListener(l)
        onDispose { p.removeListener(l); p.release() }
    }
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ PlayerView(it).apply { player = p; useController = true } }, Modifier.fillMaxSize())
        err?.let {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.playback_error) + ": " + it, color = Err)
                Fx({ err = null; p.prepare(); p.play() }, brush = Grad) { Text(stringResource(R.string.retry)) }
            }
        }
    }
}
