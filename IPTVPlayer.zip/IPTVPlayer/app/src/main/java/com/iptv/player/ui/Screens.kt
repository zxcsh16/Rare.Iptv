package com.iptv.player.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date

private class Cat(val s: S, val ic: ImageVector, val t: Int, val d: Int, val b: Brush)
private fun g(a: Long, b: Long) = Brush.linearGradient(listOf(Color(a), Color(b)))

@Composable fun Hero(added: List<Pair<String, Vod>>, onAdded: (String, Vod) -> Unit, modifier: Modifier,
                     focusWatch: FocusRequester? = null, upFr: FocusRequester? = null, downFr: FocusRequester? = null) {
    val deep = Color(0xFF1B0F4A)
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(deep, Color(0xFF0E2A6E))))) {
        if (added.isEmpty()) {
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(64.dp))
                Column {
                    BrandTitle(30.sp)
                    Text(stringResource(R.string.tagline), fontSize = 13.sp)
                }
            }
        } else {
            // Faint "R" behind the slideshow: slowly floats, breathes and sways to add depth without distracting.
            // Performance mode: only the "R" stays still (no transition is even created); the slideshow is unaffected.
            val lgScale: Float; val lgRot: Float; val lgFloat: Float; val lgAlpha: Float
            if (Ui.lite) { lgScale = 1f; lgRot = 0f; lgFloat = 0f; lgAlpha = 0.18f } else {
                val lt = rememberInfiniteTransition(label = "heroLogo")
                val a by lt.animateFloat(0.94f, 1.08f, infiniteRepeatable(tween(6000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "lgS")
                val b by lt.animateFloat(-5f, 5f, infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "lgR")
                val c by lt.animateFloat(-8f, 8f, infiniteRepeatable(tween(5000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "lgY")
                val d by lt.animateFloat(0.12f, 0.24f, infiniteRepeatable(tween(4000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "lgA")
                lgScale = a; lgRot = b; lgFloat = c; lgAlpha = d
            }
            // Sits in the empty gap between the text column and the posters.
            Box(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.37f).fillMaxHeight(), contentAlignment = Alignment.CenterEnd) {
                // Just the "R" of the logo, in the same gradient / italic style as the "Rare iptv" title.
                Text("R", Modifier.padding(end = 34.dp)
                    .graphicsLayer { scaleX = lgScale; scaleY = lgScale; rotationZ = lgRot; translationY = lgFloat; alpha = lgAlpha },
                    style = TextStyle(brush = Brush.linearGradient(listOf(Color(0xFFD9B3FF), Acc, Sec)), fontSize = 130.sp,
                        fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, shadow = Shadow(Acc.copy(.7f), Offset.Zero, 24f)),
                    maxLines = 1)
            }
            val n = added.size
            val density = LocalDensity.current
            // Posters ride a looping conveyor (side by side, right to left, never stopping). Its width in px is needed to pick the "current" poster.
            var beltW by remember { mutableFloatStateOf(0f) }
            val stepMs = 4500
            // The slideshow keeps moving in every mode (only the "R" and the icons stop in performance mode).
            val t = rememberInfiniteTransition(label = "belt")
            val prog by t.animateFloat(0f, 1f, infiniteRepeatable(tween(stepMs * n, easing = LinearEasing)), label = "prog")
            var step by remember { mutableFloatStateOf(1f) }   // px between poster starts
            val idx by remember(n) { derivedStateOf { if (step <= 1f) 0 else (((prog * n * step + beltW / 2f) / step).toInt()) % n } }
            val cur = added[idx.coerceIn(0, n - 1)]

            BoxWithConstraints(Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(0.64f).clipToBounds()
                .onSizeChanged { beltW = it.width.toFloat() }) {
                val cardH = maxHeight - 24.dp
                val cardW = cardH * 0.68f
                val gap = 14.dp
                val stepDp = cardW + gap
                val copies = (maxWidth / stepDp).toInt() + 2
                SideEffect { step = with(density) { stepDp.toPx() } }
                Row(Modifier.align(Alignment.CenterStart).wrapContentWidth(Alignment.Start, unbounded = true)
                    .graphicsLayer { translationX = -prog * n * step }, horizontalArrangement = Arrangement.spacedBy(gap)) {
                    for (i in 0 until n + copies) {
                        val v = added[i % n]
                        AsyncImage(v.second.cover, null, Modifier.size(cardW, cardH).clip(RoundedCornerShape(16.dp)).background(Color(0xFF10132B))
                            .border(1.dp, Color.White.copy(.18f), RoundedCornerShape(16.dp)).pointerInput(v.first) { detectTapGestures { onAdded(v.first, v.second) } },
                            contentScale = ContentScale.Fit)
                    }
                }
                // posters fade out toward the title on the left and in from the right edge
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to deep, 0.22f to Color.Transparent, 0.93f to Color.Transparent, 1f to Color(0x990E2A6E))))
            }
            Column(Modifier.align(Alignment.CenterStart).padding(start = 20.dp).fillMaxWidth(0.36f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                BrandTitle(if (Ui.phone) 22.sp else 28.sp)
                AnimatedContent(targetState = cur, transitionSpec = { fadeIn(tween(500)) togetherWith fadeOut(tween(300)) }, label = "heroText") { p ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(p.second.name, fontSize = 14.sp, maxLines = 2)
                        Text(stringResource(R.string.recently_added), fontSize = 10.sp, color = Color(0xFFE6D9FF))
                    }
                }
                // outside AnimatedContent so the remote's focus is not lost every time the slide changes
                var wm: Modifier = Modifier
                if (upFr != null || downFr != null) wm = wm.focusProperties { if (upFr != null) up = upFr; if (downFr != null) down = downFr }
                if (focusWatch != null) wm = wm.focusRequester(focusWatch)
                Fx({ onAdded(cur.first, cur.second) }, wm, brush = Grad, pad = 8.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.watch_now), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Row(Modifier.align(Alignment.BottomStart).padding(start = 20.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                added.indices.forEach { i ->
                    val on = i == idx
                    val w by animateDpAsState(if (on) 16.dp else 6.dp, label = "dot")
                    Box(Modifier.height(6.dp).width(w).clip(CircleShape).background(if (on) Color.White else Color.White.copy(.4f)))
                }
            }
        }
    }
}

@Composable fun Home(go: (S) -> Unit, cur: Sub?, added: List<Pair<String, Vod>>, onAdded: (String, Vod) -> Unit) {
    val cats = listOf(
        Cat(S.Live, Icons.Filled.Tv, R.string.live, R.string.live_sub, g(0xFF7925F5, 0xFF4A1CB0)),
        Cat(S.Movies, Icons.Filled.Movie, R.string.movies, R.string.movies_sub, g(0xFF1264E8, 0xFF0B3F9A)),
        Cat(S.Series, Icons.Filled.VideoLibrary, R.string.series, R.string.series_sub, g(0xFF16A869, 0xFF0B6B4A)),
        Cat(S.Fav, Icons.Filled.Star, R.string.fav, R.string.fav_sub, g(0xFFF59E0B, 0xFFD97706)))
    val expired = cur?.expired() == true
    // Remote control order: top bar  <->  Watch Now  <->  category tiles
    val watchFr = remember { FocusRequester() }
    val homeNavFr = remember { FocusRequester() }
    val tile0Fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(250); try { tile0Fr.requestFocus() } catch (_: Exception) { } }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // "Watch Now" only exists while the slideshow has items. Pointing the remote at a FocusRequester that is not
        // attached to any element throws and closes the app, so fall back to the neighbouring element in that case.
        val hasWatch = added.isNotEmpty()
        TopBar(cur?.name ?: stringResource(R.string.no_sub), if (cur == null) "—" else stringResource(if (expired) R.string.expired else R.string.active),
            expired, cur != null, { go(S.Switch) }, go, downTo = if (hasWatch) watchFr else tile0Fr, homeFocus = homeNavFr)
        Hero(added, onAdded, Modifier.fillMaxWidth().weight(1.7f), watchFr, homeNavFr, tile0Fr)
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            cats.forEachIndexed { ci, c ->
                Fx({ go(c.s) }, Modifier.weight(1f).fillMaxHeight().focusProperties { up = if (hasWatch) watchFr else homeNavFr }
                    .then(if (ci == 0) Modifier.focusRequester(tile0Fr) else Modifier), brush = c.b, pad = 6.dp) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatIcon(c.ic, if (Ui.phone) 26.dp else 30.dp)
                        Text(stringResource(c.t).uppercase(), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(stringResource(c.d), fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable fun AddSub(onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { Db.get(ctx).dao() }
    var type by remember { mutableStateOf("xtream") }
    var name by remember { mutableStateOf("") }; var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var fmt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }; var ok by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var browse by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            url = uri.toString()
        }
    }
    val types = listOf(
        Triple("xtream", "Xtream Code", g(0xFF7925F5, 0xFF4A1CB0)), Triple("m3u", "M3U URL / File", g(0xFF1264E8, 0xFF0B3F9A)),
        Triple("stalker", "Stalker MAC", g(0xFF16A869, 0xFF0B6B4A)), Triple("single", "Single URL", g(0xFFF59E0B, 0xFFD97706)))

    fun check(): String? {
        if (name.isBlank()) return ctx.getString(R.string.e_name)
        val u = url.trim()
        if (!(u.startsWith("http://") || u.startsWith("https://") || (type == "m3u" && (u.startsWith("content:") || u.startsWith("/"))))) return ctx.getString(R.string.e_url)
        if (type == "xtream" && (user.isBlank() || pass.isBlank())) return ctx.getString(R.string.e_cred)
        if (type == "stalker" && !Regex("(?i)^([0-9a-f]{2}:){5}[0-9a-f]{2}$").matches(user.trim())) return ctx.getString(R.string.e_mac)
        return null
    }
    fun submit() {
        val e = check()
        if (e != null) { msg = e; ok = false; return }
        scope.launch {
            busy = true; msg = null
            try {
                val exp = withContext(Dispatchers.IO) {
                    when (type) {
                        "xtream" -> Net.xtreamLogin(url.trim(), user.trim(), pass)
                        "m3u" -> { require(Net.m3u(ctx, url.trim()).isNotEmpty()); 0L }
                        else -> 0L
                    }
                }
                val id = withContext(Dispatchers.IO) { dao.add(Sub(name = name.trim(), type = type, url = url.trim(), user = user.trim(), expTs = exp, fmt = if (type == "xtream") fmt else "")) }
                if (type == "xtream") withContext(Dispatchers.IO) { Secure.put(ctx, id, pass) }
                ok = true; msg = ctx.getString(R.string.saved); onSaved(id)
            } catch (ex: Exception) { ok = false; msg = ex.message ?: ctx.getString(R.string.e_conn) }
            busy = false
        }
    }

    @Composable fun TC(t: Triple<String, String, Brush>, m: Modifier) {
        Fx({ type = t.first; msg = null }, m, brush = if (type == t.first) t.third else null, pad = 8.dp) {
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Text(t.second, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                if (type == t.first) { Spacer(Modifier.weight(1f)); Icon(Icons.Filled.Check, null) }
            }
        }
    }
    @Composable fun F(v: String, on: (String) -> Unit, label: Int, m: Modifier, pw: Boolean = false) {
        OutlinedTextField(v, on, m, singleLine = true, label = { Text(stringResource(label), maxLines = 1) },
            visualTransformation = if (pw) PasswordVisualTransformation() else VisualTransformation.None)
    }
    @Composable fun Two(wide: Boolean, a: @Composable (Modifier) -> Unit, b: @Composable (Modifier) -> Unit) {
        if (wide) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { a(Modifier.weight(1f)); b(Modifier.weight(1f)) }
        else Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) { a(Modifier.fillMaxWidth()); b(Modifier.fillMaxWidth()) }
    }
    @Composable fun Form(wide: Boolean) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val urlL = when (type) { "xtream" -> R.string.f_server; "m3u" -> R.string.f_m3u; "stalker" -> R.string.f_portal; else -> R.string.f_stream }
            Two(wide, { m -> F(name, { name = it }, R.string.f_name, m) }, { m -> F(url, { url = it }, urlL, m) })
            when (type) {
                "xtream" -> Two(wide, { m -> F(user, { user = it }, R.string.f_user, m) }, { m -> F(pass, { pass = it }, R.string.f_pass, m, true) })
                "stalker" -> F(user, { user = it }, R.string.f_mac, Modifier.fillMaxWidth())
                "m3u" -> Fx({
                    if (StoragePerm.has(ctx)) browse = true
                    else { (ctx as? android.app.Activity)?.let { StoragePerm.request(it) }; Toast.makeText(ctx, ctx.getString(R.string.perm_text), Toast.LENGTH_LONG).show() }
                }, pad = 8.dp) { Text(stringResource(R.string.f_pick)) }
            }
            if (type == "xtream") {
                Text(stringResource(R.string.stream_format), color = Dim, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("" to R.string.fmt_default, "ts" to R.string.fmt_ts, "m3u8" to R.string.fmt_hls).forEach { (v, r) ->
                        Fx({ fmt = v }, brush = if (fmt == v) Grad else null, pad = 8.dp) { Text(stringResource(r), fontSize = 12.sp, maxLines = 1) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Fx({ if (!busy) submit() }, Modifier.heightIn(min = 46.dp).widthIn(min = 180.dp), brush = Grad, pad = 10.dp) {
                    Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Filled.Save, null, Modifier.size(20.dp))
                        Text(stringResource(if (busy) R.string.connecting else R.string.save_connect), fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                    }
                }
                msg?.let { Text(it, color = if (ok) Ok else Err, fontSize = 13.sp, modifier = Modifier.weight(1f)) }
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 440.dp
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BackBtn(onBack); Text(stringResource(R.string.add_sub), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                types.forEach { TC(it, Modifier.weight(1f).height(50.dp)) }
            }
            Column(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(20.dp)).background(Color.White.copy(.05f))) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) { Form(wide) }
            }
        }
    }
    if (browse) Browser(false, listOf(".m3u", ".m3u8", ".txt"), { f -> url = f.path; browse = false }) { browse = false }
}

@Composable fun GlowAvatar(name: String, size: Dp) {
    Box(Modifier.size(size).shadow(18.dp, CircleShape, ambientColor = Acc, spotColor = Acc)
        .border(4.dp, Brush.linearGradient(listOf(Acc, Sec)), CircleShape).padding(5.dp).clip(CircleShape)
        .background(Brush.linearGradient(listOf(Pri, Sec))), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), fontSize = (size.value / 2.6f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun SideSub(s: Sub?, click: () -> Unit) {
    if (s == null) Spacer(Modifier.width(84.dp))
    else Fx(click, Modifier.width(84.dp), flat = true, pad = 4.dp) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Avatar(s.name, 52.dp)
            Text(s.name, fontSize = 11.sp, maxLines = 1)
            StatusBadge(s.expired(), stringResource(if (s.expired()) R.string.expired else R.string.active))
        }
    }
}

@Composable fun SwitchSub(subs: List<Sub>, active: Long, onSwitch: (Long) -> Unit, onAdd: () -> Unit, onBack: () -> Unit, onDelete: (Sub) -> Unit,
                             focusId: Long = -1L) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var importing by remember { mutableStateOf(false) }
    var focusTarget by remember { mutableLongStateOf(focusId) }
    var delTarget by remember { mutableStateOf<Sub?>(null) }
    val gridState = rememberLazyGridState()
    val targetFr = remember { FocusRequester() }
    var dlg by remember { mutableIntStateOf(0) }
    var browse by remember { mutableIntStateOf(0) }
    var pw by remember { mutableStateOf("") }
    var data by remember { mutableStateOf<ByteArray?>(null) }
    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            data = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }; pw = ""; dlg = 2
        } catch (_: Exception) { Toast.makeText(ctx, ctx.getString(R.string.bk_bad), Toast.LENGTH_LONG).show() }
    }
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val b = pending; pending = null
        if (uri != null && b != null) {
            val ok = try { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(b) }; true } catch (_: Exception) { false }
            Toast.makeText(ctx, ctx.getString(if (ok) R.string.bk_done else R.string.bk_bad), Toast.LENGTH_LONG).show()
        }
    }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy") }
    // the cursor starts on the subscription just added / imported, otherwise on the current one, otherwise on the first
    val targetId = subs.firstOrNull { it.id == focusTarget }?.id ?: subs.firstOrNull { it.id == active }?.id ?: subs.firstOrNull()?.id ?: -1L
    LaunchedEffect(targetId, subs.size) {
        if (targetId < 0) return@LaunchedEffect
        gridState.scrollToItem(subs.indexOfFirst { it.id == targetId }.coerceAtLeast(0))
        delay(250)
        try { targetFr.requestFocus() } catch (_: Exception) { }
    }
    fun toast(r: Int, vararg a: Any) = Toast.makeText(ctx, ctx.getString(r, *a), Toast.LENGTH_LONG).show()
    fun needPerm(): Boolean {
        if (StoragePerm.has(ctx)) return false
        (ctx as? android.app.Activity)?.let { StoragePerm.request(it) }
        toast(R.string.perm_text)
        return true
    }
    /** With file access: save to Download/RareIptv (survives uninstall). Without: let the user pick a location with the system picker. */
    fun export() {
        scope.launch {
            val bytes = try { withContext(Dispatchers.IO) { Backup.export(ctx, subs, pw.toCharArray()) } } catch (e: Exception) { toast(R.string.bk_bad); return@launch }
            val path = if (StoragePerm.has(ctx)) try { withContext(Dispatchers.IO) { BackupFiles.write(ctx, bytes) } } catch (_: Exception) { null } else null
            if (path != null) { toast(R.string.bk_saved, path); return@launch }
            try {
                pending = bytes
                createDoc.launch("iptv-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(Date()) + ".iptvbk")
            } catch (e: Exception) { pending = null; needPerm() }
        }
    }
    fun doImport(bytes: ByteArray) {
        scope.launch {
            importing = true
            try {
                val r = withContext(Dispatchers.IO) { Backup.import(ctx, bytes, pw.toCharArray()) }
                toast(R.string.bk_imported, r.first)
                importing = false
                if (r.second > 0) focusTarget = r.second   // stay here: the user picks the subscription to use
            } catch (e: Exception) { importing = false; toast(R.string.bk_bad) }
        }
    }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF130B3D), Bg))).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // header: back, title + hint, and the three actions
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.switch_sub), fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(stringResource(R.string.pick_sub_hint), fontSize = 11.sp, color = Dim, maxLines = 1)
            }
            Fx(onAdd, brush = Grad, pad = 8.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Filled.Add, null, Modifier.size(16.dp)); Text(stringResource(R.string.add_new), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            Fx({ if (!needPerm()) browse = 2 }, pad = 8.dp) {   // no file access yet -> ask for it first
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Filled.FileDownload, null, Modifier.size(16.dp)); Text(stringResource(R.string.bk_import), fontSize = 12.sp, maxLines = 1)
                }
            }
            Fx({ if (subs.isNotEmpty() && !needPerm()) { pw = ""; dlg = 1 } }, pad = 8.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Filled.FileUpload, null, Modifier.size(16.dp)); Text(stringResource(R.string.bk_export), fontSize = 12.sp, maxLines = 1)
                }
            }
        }
        if (subs.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.no_active), color = Dim)
                Fx(onAdd, brush = Grad, pad = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Filled.Add, null); Text(stringResource(R.string.add_new), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        else LazyVerticalGrid(GridCells.Adaptive(300.dp), Modifier.weight(1f), state = gridState,
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            gridItems(subs, key = { it.id }) { sb ->
                val on = sb.id == active
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // tapping / OK on the card picks this subscription and opens Home
                    Fx({ onSwitch(sb.id) }, Modifier.weight(1f).then(if (sb.id == targetId) Modifier.focusRequester(targetFr) else Modifier),
                        brush = if (on) Brush.horizontalGradient(listOf(Pri.copy(.55f), Sec.copy(.55f))) else null, pad = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Avatar(sb.name, 46.dp, on)
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(sb.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(sb.type.uppercase() + " · " + (if (sb.expTs > 0) stringResource(R.string.expires) + " " + fmt.format(Date(sb.expTs * 1000)) else stringResource(R.string.no_exp)),
                                    fontSize = 11.sp, color = Dim, maxLines = 1)
                                StatusBadge(sb.expired(), stringResource(if (sb.expired()) R.string.expired else R.string.active))
                            }
                            if (on) Icon(Icons.Filled.CheckCircle, stringResource(R.string.current_sub), tint = Ok)
                        }
                    }
                    Fx({ delTarget = sb }, round = true, pad = 10.dp) { Icon(Icons.Filled.Delete, stringResource(R.string.delete), Modifier.size(18.dp), tint = Err) }
                }
            }
        }
    }
    delTarget?.let { d ->
        AlertDialog(onDismissRequest = { delTarget = null }, title = { Text(d.name, maxLines = 1) }, text = { Text(stringResource(R.string.delete_sub_q)) },
            confirmButton = { TextButton(onClick = { onDelete(d); delTarget = null }) { Text(stringResource(R.string.delete), color = Err) } },
            dismissButton = { TextButton(onClick = { delTarget = null }) { Text(stringResource(R.string.cancel)) } })
    }
    // loading overlay while a backup is being imported
    if (importing) Box(Modifier.fillMaxSize().background(Color(0xCC080B1A)).pointerInput(Unit) { detectTapGestures { } }, Alignment.Center) {
        // take the remote's focus so nothing underneath can be pressed while loading
        val ofr = remember { androidx.compose.ui.focus.FocusRequester() }
        LaunchedEffect(Unit) { try { ofr.requestFocus() } catch (_: Exception) { } }
        Box(Modifier.size(1.dp).focusRequester(ofr).focusable())
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator(color = Acc)
            Text(stringResource(R.string.loading), fontWeight = FontWeight.Bold)
        }
    }
    // a backup saved without a password restores straight away
    val plainPick = dlg == 2 && data?.let { Backup.isPlain(it) } == true
    LaunchedEffect(plainPick) { if (plainPick) { dlg = 0; data?.let { doImport(it) } } }
    if (dlg != 0 && !plainPick) AlertDialog(
        onDismissRequest = { dlg = 0 },
        title = { Text(stringResource(R.string.bk_pass_title)) },
        text = { OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(stringResource(R.string.bk_pass)) }) },
        confirmButton = {
            TextButton(onClick = {
                if (pw.isEmpty() || pw.length >= 4) {   // password is optional
                    val d = dlg
                    dlg = 0
                    if (d == 1) export() else data?.let { doImport(it) }
                }
            }) { Text(stringResource(R.string.accept)) }
        },
        dismissButton = { TextButton(onClick = { dlg = 0 }) { Text(stringResource(R.string.cancel)) } })
    if (browse == 2) Browser(false, listOf(".iptvbk"), { f ->
        browse = 0
        try { data = f.readBytes(); pw = ""; dlg = 2 } catch (_: Exception) { toast(R.string.bk_bad) }
    }) { browse = 0 }
}

@Composable fun Soon() = Box(Modifier.fillMaxSize(), Alignment.Center) { Text(stringResource(R.string.soon), color = Dim, fontSize = 18.sp) }


/** First-launch screen: choose TV or Phone. Phone => Small font + Small top bar; TV => default settings. */
@Composable fun ModeChooser(onPick: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val isTv = remember {
        (ctx.getSystemService(android.content.Context.UI_MODE_SERVICE) as? android.app.UiModeManager)?.currentModeType ==
            android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    }
    val fr = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { if (isTv) try { fr.requestFocus() } catch (_: Exception) {} }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 640.dp).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            BrandTitle(30.sp)
            Text(stringResource(R.string.mode_title), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.mode_sub), fontSize = 12.sp, color = Dim, textAlign = TextAlign.Center)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                @Composable fun ModeCard(m: Modifier, ic: ImageVector, t: Int, d: Int, b: Brush, phone: Boolean) =
                    Fx({ onPick(phone) }, m.height(130.dp), brush = b, pad = 10.dp) {
                        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            FloatIcon(ic, 40.dp)
                            Text(stringResource(t), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(stringResource(d), fontSize = 11.sp, textAlign = TextAlign.Center, color = Color.White.copy(.85f))
                        }
                    }
                ModeCard(Modifier.weight(1f).then(if (isTv) Modifier.focusRequester(fr) else Modifier), Icons.Filled.Tv, R.string.mode_tv, R.string.mode_tv_sub, g(0xFF7925F5, 0xFF4A1CB0), false)
                ModeCard(Modifier.weight(1f), Icons.Filled.PhoneAndroid, R.string.mode_phone, R.string.mode_phone_sub, g(0xFF1264E8, 0xFF0B3F9A), true)
            }
        }
    }
}
