package com.iptv.player.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date

private class Cat(val s: S, val ic: ImageVector, val t: Int, val d: Int, val b: Brush)
private fun g(a: Long, b: Long) = Brush.linearGradient(listOf(Color(a), Color(b)))

@Composable fun Hero(added: List<Pair<String, Vod>>, onAdded: (String, Vod) -> Unit, modifier: Modifier) {
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(added.size) {
        if (added.size > 1) while (true) { delay(4500); idx = (idx + 1) % added.size }
    }
    val deep = Color(0xFF1B0F4A)
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(deep, Color(0xFF0E2A6E))))) {
        if (added.isEmpty()) {
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(64.dp))
                Column {
                    BrandTitle(30.sp)
                    Text(stringResource(R.string.tagline), fontSize = 13.sp)
                }
            }
        } else {
            val cur = added[idx % added.size]
            // Poster glides left toward the "Rare iptv" title and fades out; the next poster enters from the right.
            AnimatedContent(targetState = cur, modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(0.34f + 0.06f),
                transitionSpec = {
                    (slideInHorizontally(tween(750, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(600, delayMillis = 150))) togetherWith
                        (slideOutHorizontally(tween(750, easing = FastOutSlowInEasing)) { -(it * 2) } + fadeOut(tween(450))) using SizeTransform(clip = false)
                }, label = "poster") { p ->
                Box(Modifier.fillMaxSize().padding(vertical = 12.dp, horizontal = 14.dp).clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color.White.copy(.18f), RoundedCornerShape(18.dp))) {
                    AsyncImage(p.second.cover, null, Modifier.fillMaxSize().graphicsLayer { alpha = 0.4f }, contentScale = ContentScale.Crop)
                    AsyncImage(p.second.cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
            }
            Column(Modifier.align(Alignment.CenterStart).padding(start = 20.dp).fillMaxWidth(0.58f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                BrandTitle(if (Ui.phone) 22.sp else 28.sp)
                AnimatedContent(targetState = cur, transitionSpec = { fadeIn(tween(600)) togetherWith fadeOut(tween(300)) }, label = "heroText") { p ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(p.second.name, fontSize = 14.sp, maxLines = 2)
                        Text(stringResource(R.string.recently_added), fontSize = 10.sp, color = Color(0xFFE6D9FF))
                        Fx({ onAdded(p.first, p.second) }, brush = Grad, pad = 8.dp) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                                Text(stringResource(R.string.watch_now), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            Row(Modifier.align(Alignment.BottomStart).padding(start = 20.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                added.indices.forEach { i ->
                    val on = i == idx % added.size
                    val w by animateDpAsState(if (on) 16.dp else 6.dp, label = "dot")
                    Box(Modifier.height(6.dp).width(w).clip(CircleShape).background(if (on) Color.White else Color.White.copy(.4f)))
                }
            }
        }
    }
}

@Composable fun Home(go: (S) -> Unit, cur: Sub?, added: List<Pair<String, Vod>>, onAdded: (String, Vod) -> Unit) {
    val cats = listOf(
        Cat(S.Live, Icons.Filled.Tv, R.string.live, R.string.live_sub, g(0xFF7925F5, 0xFF4A1CB0)),
        Cat(S.Movies, Icons.Filled.Movie, R.string.movies, R.string.movies_sub, g(0xFF1264E8, 0xFF0B3F9A)),
        Cat(S.Series, Icons.Filled.VideoLibrary, R.string.series, R.string.series_sub, g(0xFF16A869, 0xFF0B6B4A)),
        Cat(S.Fav, Icons.Filled.Star, R.string.fav, R.string.fav_sub, g(0xFFF59E0B, 0xFFD97706)))
    val expired = cur?.expired() == true
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TopBar(cur?.name ?: stringResource(R.string.no_sub), if (cur == null) "—" else stringResource(if (expired) R.string.expired else R.string.active),
            expired, cur != null, { go(S.Switch) }, go)
        Hero(added, onAdded, Modifier.fillMaxWidth().weight(1.7f))
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            cats.forEach { c ->
                Fx({ go(c.s) }, Modifier.weight(1f).fillMaxHeight(), brush = c.b, pad = 6.dp) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatIcon(c.ic, if (Ui.phone) 26.dp else 30.dp)
                        Text(stringResource(c.t).uppercase(), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(stringResource(c.d), fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable fun AddSub(onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { Db.get(ctx).dao() }
    var type by remember { mutableStateOf("xtream") }
    var name by remember { mutableStateOf("") }; var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var fmt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }; var ok by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var browse by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            url = uri.toString()
        }
    }
    val types = listOf(
        Triple("xtream", "Xtream Code", g(0xFF7925F5, 0xFF4A1CB0)), Triple("m3u", "M3U URL / File", g(0xFF1264E8, 0xFF0B3F9A)),
        Triple("stalker", "Stalker MAC", g(0xFF16A869, 0xFF0B6B4A)), Triple("single", "Single URL", g(0xFFF59E0B, 0xFFD97706)))

    fun check(): String? {
        if (name.isBlank()) return ctx.getString(R.string.e_name)
        val u = url.trim()
        if (!(u.startsWith("http://") || u.startsWith("https://") || (type == "m3u" && (u.startsWith("content:") || u.startsWith("/"))))) return ctx.getString(R.string.e_url)
        if (type == "xtream" && (user.isBlank() || pass.isBlank())) return ctx.getString(R.string.e_cred)
        if (type == "stalker" && !Regex("(?i)^([0-9a-f]{2}:){5}[0-9a-f]{2}$").matches(user.trim())) return ctx.getString(R.string.e_mac)
        return null
    }
    fun submit() {
        val e = check()
        if (e != null) { msg = e; ok = false; return }
        scope.launch {
            busy = true; msg = null
            try {
                val exp = withContext(Dispatchers.IO) {
                    when (type) {
                        "xtream" -> Net.xtreamLogin(url.trim(), user.trim(), pass)
                        "m3u" -> { require(Net.m3u(ctx, url.trim()).isNotEmpty()); 0L }
                        else -> 0L
                    }
                }
                val id = withContext(Dispatchers.IO) { dao.add(Sub(name = name.trim(), type = type, url = url.trim(), user = user.trim(), expTs = exp, fmt = if (type == "xtream") fmt else "")) }
                if (type == "xtream") withContext(Dispatchers.IO) { Secure.put(ctx, id, pass) }
                ok = true; msg = ctx.getString(R.string.saved); onSaved(id)
            } catch (ex: Exception) { ok = false; msg = ex.message ?: ctx.getString(R.string.e_conn) }
            busy = false
        }
    }

    @Composable fun TC(t: Triple<String, String, Brush>, m: Modifier) {
        Fx({ type = t.first; msg = null }, m, brush = if (type == t.first) t.third else null, pad = 8.dp) {
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Text(t.second, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                if (type == t.first) { Spacer(Modifier.weight(1f)); Icon(Icons.Filled.Check, null) }
            }
        }
    }
    @Composable fun F(v: String, on: (String) -> Unit, label: Int, m: Modifier, pw: Boolean = false) {
        OutlinedTextField(v, on, m, singleLine = true, label = { Text(stringResource(label), maxLines = 1) },
            visualTransformation = if (pw) PasswordVisualTransformation() else VisualTransformation.None)
    }
    @Composable fun Two(wide: Boolean, a: @Composable (Modifier) -> Unit, b: @Composable (Modifier) -> Unit) {
        if (wide) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { a(Modifier.weight(1f)); b(Modifier.weight(1f)) }
        else Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) { a(Modifier.fillMaxWidth()); b(Modifier.fillMaxWidth()) }
    }
    @Composable fun Form(wide: Boolean) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val urlL = when (type) { "xtream" -> R.string.f_server; "m3u" -> R.string.f_m3u; "stalker" -> R.string.f_portal; else -> R.string.f_stream }
            Two(wide, { m -> F(name, { name = it }, R.string.f_name, m) }, { m -> F(url, { url = it }, urlL, m) })
            when (type) {
                "xtream" -> Two(wide, { m -> F(user, { user = it }, R.string.f_user, m) }, { m -> F(pass, { pass = it }, R.string.f_pass, m, true) })
                "stalker" -> F(user, { user = it }, R.string.f_mac, Modifier.fillMaxWidth())
                "m3u" -> Fx({
                    if (StoragePerm.has(ctx)) browse = true
                    else { (ctx as? android.app.Activity)?.let { StoragePerm.request(it) }; Toast.makeText(ctx, ctx.getString(R.string.perm_text), Toast.LENGTH_LONG).show() }
                }, pad = 8.dp) { Text(stringResource(R.string.f_pick)) }
            }
            if (type == "xtream") {
                Text(stringResource(R.string.stream_format), color = Dim, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("" to R.string.fmt_default, "ts" to R.string.fmt_ts, "m3u8" to R.string.fmt_hls).forEach { (v, r) ->
                        Fx({ fmt = v }, brush = if (fmt == v) Grad else null, pad = 8.dp) { Text(stringResource(r), fontSize = 12.sp, maxLines = 1) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Fx({ if (!busy) submit() }, Modifier.heightIn(min = 46.dp).widthIn(min = 180.dp), brush = Grad, pad = 10.dp) {
                    Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Filled.Save, null, Modifier.size(20.dp))
                        Text(stringResource(if (busy) R.string.connecting else R.string.save_connect), fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                    }
                }
                msg?.let { Text(it, color = if (ok) Ok else Err, fontSize = 13.sp, modifier = Modifier.weight(1f)) }
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 440.dp
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BackBtn(onBack); Text(stringResource(R.string.add_sub), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                types.forEach { TC(it, Modifier.weight(1f).height(50.dp)) }
            }
            Column(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(20.dp)).background(Color.White.copy(.05f))) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) { Form(wide) }
            }
        }
    }
    if (browse) Browser(false, listOf(".m3u", ".m3u8", ".txt"), { f -> url = f.path; browse = false }) { browse = false }
}

@Composable fun GlowAvatar(name: String, size: Dp) {
    Box(Modifier.size(size).shadow(18.dp, CircleShape, ambientColor = Acc, spotColor = Acc)
        .border(4.dp, Brush.linearGradient(listOf(Acc, Sec)), CircleShape).padding(5.dp).clip(CircleShape)
        .background(Brush.linearGradient(listOf(Pri, Sec))), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), fontSize = (size.value / 2.6f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun SideSub(s: Sub?, click: () -> Unit) {
    if (s == null) Spacer(Modifier.width(84.dp))
    else Fx(click, Modifier.width(84.dp), flat = true, pad = 4.dp) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Avatar(s.name, 52.dp)
            Text(s.name, fontSize = 11.sp, maxLines = 1)
            StatusBadge(s.expired(), stringResource(if (s.expired()) R.string.expired else R.string.active))
        }
    }
}

@Composable fun SwitchSub(subs: List<Sub>, active: Long, onSwitch: (Long) -> Unit, onAdd: () -> Unit, onBack: () -> Unit, onDelete: (Sub) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var idx by remember(subs.size) { mutableIntStateOf(subs.indexOfFirst { it.id == active }.coerceAtLeast(0)) }
    var dlg by remember { mutableIntStateOf(0) }
    var browse by remember { mutableIntStateOf(0) }
    var pw by remember { mutableStateOf("") }
    var data by remember { mutableStateOf<ByteArray?>(null) }
    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            data = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }; pw = ""; dlg = 2
        } catch (_: Exception) { Toast.makeText(ctx, ctx.getString(R.string.bk_bad), Toast.LENGTH_LONG).show() }
    }
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val b = pending; pending = null
        if (uri != null && b != null) {
            val ok = try { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(b) }; true } catch (_: Exception) { false }
            Toast.makeText(ctx, ctx.getString(if (ok) R.string.bk_done else R.string.bk_bad), Toast.LENGTH_LONG).show()
        }
    }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy") }
    val cur = subs.getOrNull(idx)
    fun toast(r: Int, vararg a: Any) = Toast.makeText(ctx, ctx.getString(r, *a), Toast.LENGTH_LONG).show()
    fun needPerm(): Boolean {
        if (StoragePerm.has(ctx)) return false
        (ctx as? android.app.Activity)?.let { StoragePerm.request(it) }
        toast(R.string.perm_text)
        return true
    }
    /** With file access: save to Download/RareIptv (survives uninstall). Without: let the user pick a location with the system picker. */
    fun export() {
        scope.launch {
            val bytes = try { withContext(Dispatchers.IO) { Backup.export(ctx, subs, pw.toCharArray()) } } catch (e: Exception) { toast(R.string.bk_bad); return@launch }
            val path = if (StoragePerm.has(ctx)) try { withContext(Dispatchers.IO) { BackupFiles.write(ctx, bytes) } } catch (_: Exception) { null } else null
            if (path != null) { toast(R.string.bk_saved, path); return@launch }
            try {
                pending = bytes
                createDoc.launch("iptv-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(Date()) + ".iptvbk")
            } catch (e: Exception) { pending = null; needPerm() }
        }
    }
    fun doImport(bytes: ByteArray) {
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) { Backup.import(ctx, bytes, pw.toCharArray()) }
                if (active < 0 && r.second > 0) onSwitch(r.second)
                toast(R.string.bk_imported, r.first)
            } catch (e: Exception) { toast(R.string.bk_bad) }
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF130B3D), Bg)))) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn(onBack)
            Text(stringResource(R.string.switch_sub), fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Fx(onAdd, pad = 8.dp) { Text(stringResource(R.string.add_new), fontSize = 12.sp, maxLines = 1) }
            Fx({ cur?.let(onDelete) }, pad = 8.dp) { Text(stringResource(R.string.delete), fontSize = 12.sp, color = Err) }
            Fx({ if (subs.isNotEmpty()) { pw = ""; dlg = 1 } }, pad = 8.dp) { Text(stringResource(R.string.bk_export), fontSize = 12.sp) }
            Fx({
                if (StoragePerm.has(ctx)) browse = 2
                else try { openDoc.launch(arrayOf("*/*")) } catch (_: Exception) { needPerm() }
            }, pad = 8.dp) { Text(stringResource(R.string.bk_import), fontSize = 12.sp) }
        }
        if (cur == null) Text(stringResource(R.string.no_active), Modifier.align(Alignment.Center), color = Dim)
        else {
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Fx({ if (idx > 0) idx -= 1 }, round = true, pad = 10.dp) { Icon(Icons.Filled.KeyboardArrowLeft, null) }
                SideSub(subs.getOrNull(idx - 1)) { idx -= 1 }
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(if (cur.id == active) "👑" else " ", fontSize = 18.sp)
                    GlowAvatar(cur.name, 96.dp)
                    Text(cur.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    StatusBadge(cur.expired(), stringResource(if (cur.expired()) R.string.expired else R.string.active))
                    Text(cur.type.uppercase() + " · " + (if (cur.expTs > 0) stringResource(R.string.expires) + " " + fmt.format(Date(cur.expTs * 1000)) else stringResource(R.string.no_exp)),
                        fontSize = 11.sp, color = Dim)
                }
                SideSub(subs.getOrNull(idx + 1)) { idx += 1 }
                Fx({ if (idx < subs.size - 1) idx += 1 }, round = true, pad = 10.dp) { Icon(Icons.Filled.KeyboardArrowRight, null) }
            }
            Fx({ onSwitch(cur.id) }, Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp), brush = Grad, pad = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.Check, null); Text(stringResource(R.string.switch_btn), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    if (dlg != 0) AlertDialog(
        onDismissRequest = { dlg = 0 },
        title = { Text(stringResource(R.string.bk_pass_title)) },
        text = { OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(stringResource(R.string.bk_pass)) }) },
        confirmButton = {
            TextButton(onClick = {
                if (pw.length >= 4) {
                    val d = dlg
                    dlg = 0
                    if (d == 1) export() else data?.let { doImport(it) }
                }
            }) { Text(stringResource(R.string.accept)) }
        },
        dismissButton = { TextButton(onClick = { dlg = 0 }) { Text(stringResource(R.string.cancel)) } })
    if (browse == 2) Browser(false, listOf(".iptvbk"), { f ->
        browse = 0
        try { data = f.readBytes(); pw = ""; dlg = 2 } catch (_: Exception) { toast(R.string.bk_bad) }
    }) { browse = 0 }
}

@Composable fun Soon() = Box(Modifier.fillMaxSize(), Alignment.Center) { Text(stringResource(R.string.soon), color = Dim, fontSize = 18.sp) }


/** First-launch screen: choose TV or Phone. Phone => Small font + Small top bar; TV => default settings. */
@Composable fun ModeChooser(onPick: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val isTv = remember {
        (ctx.getSystemService(android.content.Context.UI_MODE_SERVICE) as? android.app.UiModeManager)?.currentModeType ==
            android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    }
    val fr = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { if (isTv) try { fr.requestFocus() } catch (_: Exception) {} }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 640.dp).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            BrandTitle(30.sp)
            Text(stringResource(R.string.mode_title), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.mode_sub), fontSize = 12.sp, color = Dim, textAlign = TextAlign.Center)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                @Composable fun ModeCard(m: Modifier, ic: ImageVector, t: Int, d: Int, b: Brush, phone: Boolean) =
                    Fx({ onPick(phone) }, m.height(130.dp), brush = b, pad = 10.dp) {
                        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            FloatIcon(ic, 40.dp)
                            Text(stringResource(t), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(stringResource(d), fontSize = 11.sp, textAlign = TextAlign.Center, color = Color.White.copy(.85f))
                        }
                    }
                ModeCard(Modifier.weight(1f).then(if (isTv) Modifier.focusRequester(fr) else Modifier), Icons.Filled.Tv, R.string.mode_tv, R.string.mode_tv_sub, g(0xFF7925F5, 0xFF4A1CB0), false)
                ModeCard(Modifier.weight(1f), Icons.Filled.PhoneAndroid, R.string.mode_phone, R.string.mode_phone_sub, g(0xFF1264E8, 0xFF0B3F9A), true)
            }
        }
    }
}
