package com.iptv.player.ui

import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.iptv.player.R
import java.io.File

/** Simple in-app browser so files/folders can be chosen with a TV remote (no system picker needed). */
@Composable fun Browser(dirMode: Boolean, exts: List<String>, onPick: (File) -> Unit, onClose: () -> Unit) {
    val ext = remember(exts) { exts.map { it.trimStart('.').lowercase() } }   // File.extension has no leading dot
    var cur by remember {
        val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val rare = File(dl, "Rare_iptv/backup").takeIf { it.isDirectory } ?: File(dl, "RareIptv")
        mutableStateOf(if (ext.contains("iptvbk") && rare.isDirectory) rare else Environment.getExternalStorageDirectory())
    }
    val list = remember(cur) {
        (cur.listFiles()?.toList() ?: emptyList())
            .filter { !it.name.startsWith(".") && (it.isDirectory || (!dirMode && (ext.isEmpty() || it.extension.lowercase() in ext))) }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.85f).fillMaxHeight(0.88f).clip(RoundedCornerShape(20.dp)).background(Side).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(cur.path, fontSize = 12.sp, color = Dim, maxLines = 1)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fx({ cur.parentFile?.let { cur = it } }, pad = 8.dp) { Icon(Icons.Filled.ArrowUpward, null, Modifier.size(18.dp)) }
                if (dirMode) Fx({ onPick(cur) }, brush = Grad, pad = 8.dp) { Text(stringResource(R.string.select_folder), fontSize = 12.sp) }
                Fx(onClose, pad = 8.dp) { Text(stringResource(R.string.close), fontSize = 12.sp) }
            }
            if (list.isEmpty()) Text(stringResource(R.string.no_items), color = Dim, fontSize = 12.sp)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(list) { f ->
                    Fx({ if (f.isDirectory) cur = f else onPick(f) }, Modifier.fillMaxWidth(), pad = 8.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(if (f.isDirectory) Icons.Filled.Folder else Icons.Filled.InsertDriveFile, null, Modifier.size(18.dp), tint = Acc)
                            Text(f.name, maxLines = 1, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
