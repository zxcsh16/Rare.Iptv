package com.iptv.player.ui

import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.iptv.player.R
import java.io.File
import kotlinx.coroutines.delay

/** Simple in-app browser so files/folders can be chosen with a TV remote (no system picker needed). */
@Composable fun Browser(dirMode: Boolean, exts: List<String>, onPick: (File) -> Unit, onClose: () -> Unit) {
    val ext = remember(exts) { exts.map { it.trimStart('.').lowercase() } }   // File.extension has no leading dot
    var cur by remember {
        val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val rare = File(dl, "Rare_iptv/backup").takeIf { it.isDirectory } ?: File(dl, "RareIptv")
        mutableStateOf(if (ext.contains("iptvbk") && rare.isDirectory) rare else Environment.getExternalStorageDirectory())
    }
    val list = remember(cur) {
        (cur.listFiles()?.toList() ?: emptyList())
            .filter { !it.name.startsWith(".") && (it.isDirectory || (!dirMode && (ext.isEmpty() || it.extension.lowercase() in ext))) }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
    // The cursor lands on the first file / folder (not on "up"); after going up it returns to the folder we came out of.
    var focusName by remember { mutableStateOf<String?>(null) }
    val focusIdx = remember(list, focusName) { list.indexOfFirst { it.name == focusName }.takeIf { it >= 0 } ?: 0 }
    val itemFr = rememberFocusReq()
    val upFr = rememberFocusReq()
    val listState = rememberLazyListState()
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        // Lives inside the dialog (its own window): opening the browser, or entering / leaving a folder, puts the cursor on the first
        // file / folder (or on the folder we just came out of) instead of leaving it on the "up" button.
        LaunchedEffect(cur) {
            (if (list.isEmpty()) upFr else itemFr).acquire(first = 250) { if (list.isNotEmpty()) listState.scrollToItem(focusIdx) }
        }
        Column(Modifier.fillMaxWidth(0.85f).fillMaxHeight(0.88f).clip(RoundedCornerShape(20.dp)).background(Side).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(cur.path, fontSize = 12.sp, color = Dim, maxLines = 1)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fx({ cur.parentFile?.let { focusName = cur.name; cur = it } }, Modifier.focusIf(list.isEmpty(), upFr), pad = 8.dp) { Icon(Icons.Filled.ArrowUpward, null, Modifier.size(18.dp)) }
                if (dirMode) Fx({ onPick(cur) }, brush = Grad, pad = 8.dp) { Text(stringResource(R.string.select_folder), fontSize = 12.sp) }
                Fx(onClose, pad = 8.dp) { Text(stringResource(R.string.close), fontSize = 12.sp) }
            }
            if (list.isEmpty()) Text(stringResource(R.string.no_items), color = Dim, fontSize = 12.sp)
            LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                itemsIndexed(list) { i, f ->
                    Fx({ if (f.isDirectory) { focusName = null; cur = f } else onPick(f) }, Modifier.fillMaxWidth().focusIf(i == focusIdx, itemFr), pad = 8.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(if (f.isDirectory) Icons.Filled.Folder else Icons.Filled.InsertDriveFile, null, Modifier.size(18.dp), tint = Acc)
                            Text(f.name, maxLines = 1, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
